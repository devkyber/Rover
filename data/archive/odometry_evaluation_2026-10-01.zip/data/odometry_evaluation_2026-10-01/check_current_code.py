"""Read-only smoke checks and reproductions of current behavior issues.

No serial ports are opened. Fakes below exercise the actual production drivers.
An 'issue reproduced' result describes a defect, not a passing requirement.
"""
from pathlib import Path
import ast
import importlib
import json
import os
import sys

import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / "rover"))
os.environ["PYGAME_HIDE_SUPPORT_PROMPT"] = "1"
import config
import dxl_control
import dxl_reader
import imu_reader
import odometry
import replay_gui
from dynamixel_sdk import COMM_SUCCESS, COMM_TX_FAIL


class FakeWriter:
    def __init__(self, result=COMM_TX_FAIL):
        self.result = result
        self.parameters = {}

    def clearParam(self):
        self.parameters.clear()

    def addParam(self, motor_id, value):
        self.parameters[motor_id] = value
        return True

    def txPacket(self):
        return self.result


class FakeReader:
    def __init__(self, result=COMM_SUCCESS, missing_id=None):
        self.result = result
        self.missing_id = missing_id

    def txRxPacket(self):
        return self.result

    def isAvailable(self, motor_id, address, size):
        return motor_id != self.missing_id

    def getData(self, motor_id, address, size):
        return {config.ADDR_PRESENT_CURRENT: 0xFFFF,
                config.ADDR_PRESENT_VELOCITY: 0xFFFFFFFE,
                config.ADDR_PRESENT_POSITION: 0xFFFFFFFD}[address]


def run_checks():
    files = sorted((ROOT / "rover").glob("*.py")) + sorted((ROOT / "jetson").glob("*.py"))
    for file in files:
        source = file.read_text(encoding="utf-8-sig")
        ast.parse(source, filename=str(file))
        compile(source, str(file), "exec")
    imports = []
    for file in sorted((ROOT / "rover").glob("*.py")):
        importlib.import_module(file.stem)
        imports.append(file.stem)

    decoded = dxl_reader.read_wheels(FakeReader())
    assert len(decoded["wheels"]) == len(config.MOTOR_IDS)
    for wheel in decoded["wheels"]:
        assert np.isclose(wheel["current_A"], -config.CURRENT_TO_AMP)
        assert np.isclose(wheel["velocity_rads"], -2*config.VELOCITY_TO_RADS)
        assert np.isclose(wheel["position_rad"], -3*config.POSITION_TO_RAD)
    assert dxl_reader.read_wheels(FakeReader(result=COMM_TX_FAIL)) is None
    assert dxl_reader.read_wheels(FakeReader(missing_id=config.MOTOR_IDS[-1])) is None

    app = replay_gui.create_app("2026-09-06_4wheel_still.csv")
    with app.test_client() as client:
        assert client.get("/").status_code == 200
        assert len(client.get("/api/logs").get_json()["logs"]) == len(list((ROOT/"logs").glob("*.csv")))
        assert client.get("/api/replay?file=../requirements.txt").status_code == 400
        response = client.get("/api/replay?file=2026-09-06_4wheel_still.csv")
        assert response.status_code == 200
        payload = response.get_json()
        assert payload["summary"]["samples"] == 2000
        assert payload["summary"]["alignment_complete"]
        assert np.array_equal(payload["summary"]["final_position"], np.zeros(3))
        index = len(payload["frames"]) - 1
        trace = client.get(f"/api/trace?file=2026-09-06_4wheel_still.csv&index={index}")
        assert trace.status_code == 200
        assert {s["name"] for s in trace.get_json()["stages"]} >= {
            "predict", "wheel", "nhc", "zupt", "zaru", "gravity"}
        assert client.get("/api/trace?file=2026-09-06_4wheel_still.csv&index=-1").status_code == 400

    failed_writer = FakeWriter()
    tx_result = dxl_control.write_velocities(failed_writer, [0]*len(config.MOTOR_IDS))
    returned_command = dxl_control.drive(failed_writer, 0.2, 0.0)
    failed_tx_hidden = tx_result is False and isinstance(returned_command, list)

    # At 0.01 rad/s the detector calls the readings still after its hold.
    # use_zupt=False should not make the public output claim ZUPT is active.
    odo = odometry.Odometry(use_zupt=False, startup_alignment_s=0)
    wheels = [{"id": mid, "velocity_rads": 0.01 * config.WHEEL_SIGN[i],
               "position_rad": 0., "current_A": 0.}
              for i, mid in enumerate(config.MOTOR_IDS)]
    for _ in range(100):
        odo.step(wheels, gyro=np.zeros(3), accel=np.array([0., 0., config.GRAVITY]), dt=0.01)
    expected_distance = 0.01 * config.WHEEL_RADIUS_M
    disabled_zupt_clamps_output = odo.zupt_cycles == 0 and odo.zupt_active and odo.position[0] < expected_distance/2

    imu = imu_reader.ArduinoIMU.__new__(imu_reader.ArduinoIMU)
    imu._us_prev = None
    imu._us_wraps = 0
    invalid = imu._parse(b"I,1000,nan,0,1,0,0,0\n")
    nonfinite_accepted = invalid is not None and not np.isfinite(invalid["accel"]).all()

    class EmptySerial:
        in_waiting = 0
        def readline(self):
            return b""

    imu.ser = EmptySerial()
    imu.n_parsed = imu.n_bad = imu.n_dropped = imu.n_stale = 0
    imu.last = {"timestamp": 0., "device_t": 12.3, "accel": np.array([0., 0., config.GRAVITY]),
                "gyro": np.zeros(3), "frame": "body"}
    stale = imu.read()
    stale_restamped = stale["timestamp"] > 0 and stale["device_t"] == 12.3 and imu.n_stale == 1

    class FailingTorquePacket:
        def __init__(self):
            self.attempts = []
        def write1ByteTxRx(self, port, motor_id, address, value):
            self.attempts.append(motor_id)
            return COMM_TX_FAIL, 0
        def getTxRxResult(self, code):
            return "simulated transport failure"

    packet = FailingTorquePacket()
    try:
        dxl_control.set_torque(packet, None, False)
    except RuntimeError:
        pass
    torque_cleanup_stops_early = packet.attempts == [config.MOTOR_IDS[0]]
    result = {
        "checks": {
            "application_python_parse_compile": {"passed": True, "files": len(files)},
            "rover_module_imports": {"passed": True, "modules": imports},
            "signed_motor_register_decoding": {"passed": True},
            "failed_or_partial_motor_reads_rejected": {"passed": True},
            "replay_http_page_logs_validation_actual_log_and_trace": {"passed": True, "actual_samples": 2000},
        },
        "issues_reproduced": {
            "drive_hides_failed_transmission": {"reproduced": failed_tx_hidden, "write_success": tx_result,
                                                 "drive_returned": returned_command},
            "disabled_zupt_still_clamps_reported_pose": {
                "reproduced": bool(disabled_zupt_clamps_output), "zupt_cycles": odo.zupt_cycles,
                "public_zupt_active": bool(odo.zupt_active), "expected_x_m": expected_distance,
                "actual_x_m": float(odo.position[0])},
            "imu_parser_accepts_nonfinite_values": {"reproduced": bool(nonfinite_accepted)},
            "imu_reuses_old_sample_with_new_host_timestamp": {"reproduced": bool(stale_restamped)},
            "torque_disable_aborts_after_first_failure": {"reproduced": torque_cleanup_stops_early,
                                                          "motor_ids_attempted": packet.attempts},
        },
        "hardware": "No serial devices were enumerated in this session; all driver probes used fakes.",
        "scope": "Rover modules were imported; Jetson scripts were only parsed/compiled because some open cameras on import.",
    }
    (OUT / "code_checks.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    run_checks()
