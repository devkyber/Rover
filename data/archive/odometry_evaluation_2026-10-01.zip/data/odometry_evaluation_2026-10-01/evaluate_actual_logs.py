"""Evaluate existing floor logs with the current, unmodified production replay.

Run from the repository root:
    python data/odometry_evaluation_2026-10-01/evaluate_actual_logs.py

This script opens no hardware. Measurements come from logs/experiments.json.
It writes derived artifacts beside itself and leaves the raw CSVs untouched.
"""
from pathlib import Path
import csv
import hashlib
import json
import sys
from unittest.mock import patch

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
sys.path.insert(0, str(ROOT / "rover"))
import analyze_drive
import config
import logger
import odometry
import replay


def checkpoint_comparison(history, rows, profile):
    """Use the GUI's existing 1 s stop / 5 cm substantial-leg convention."""
    if profile is None:
        return None
    analysis = [
        (h["t"], h["pos"], h["stopped"],
         np.mean([abs(w["velocity_rads"]) for w in r["wheels"]]))
        for h, r in zip(history, rows)
    ]
    all_legs = analyze_drive.segments(analysis)
    legs = [leg for leg in all_legs
            if np.linalg.norm(leg[1][1][:2] - leg[0][1][:2]) >= 0.05]
    truth = np.array(profile["checkpoints_m"], dtype=float)
    if len(legs) != len(truth) - 1:
        raise RuntimeError(f"Checkpoint matching failed: {len(legs)} legs / "
                           f"{len(truth)-1} expected")
    events = []
    for number, ((start_t, start), (end_t, end)) in enumerate(legs, 1):
        error = end[:2] - truth[number]
        displacement = end[:2] - start[:2]
        true_displacement = truth[number] - truth[number-1]
        events.append({
            "number": number,
            "t_s": float(end_t),
            "truth_xy_m": truth[number].tolist(),
            "estimate_xy_m": end[:2].tolist(),
            "x_error_m": float(error[0]),
            "estimated_y_m": float(end[1]),
            "xy_error_m_assuming_y0": float(np.linalg.norm(error)),
            "estimated_leg_length_m": float(np.linalg.norm(displacement)),
            "true_leg_length_m": float(np.linalg.norm(true_displacement)),
            "leg_x_error_m": float(displacement[0] - true_displacement[0]),
        })
    x_errors = np.array([e["x_error_m"] for e in events])
    return {
        "label": profile["label"],
        "status": "matched",
        "tolerance_m": profile["tolerance_m"],
        "events": events,
        "substantial_legs": len(legs),
        "ignored_small_legs": len(all_legs) - len(legs),
        "max_abs_x_error_m": float(np.max(np.abs(x_errors))),
        "checkpoint_x_rmse_m": float(np.sqrt(np.mean(x_errors**2))),
        "within_x_tolerance": bool(np.all(np.abs(x_errors) <= profile["tolerance_m"])),
        "scope": "Tape-measured longitudinal stops; y=0 is a straight-line assumption. "
                 "These are not continuous external XY or heading measurements.",
    }


def plot_run(name, history, comparison):
    t = np.array([h["t"] for h in history])
    p = np.array([h["pos"] for h in history])
    fp = np.array([h["filter_pos"] for h in history])
    yaw = np.rad2deg(np.unwrap(np.deg2rad([h["rpy"][2] for h in history])))
    ready = np.array([h["ready"] for h in history])
    fig, axes = plt.subplots(2, 2, figsize=(13, 8.5), constrained_layout=True)
    axes[0, 0].plot(p[:, 0], p[:, 1], color="#2465b2", label="Reported wheel + ESKF attitude pose")
    axes[0, 0].scatter(*p[0, :2], color="#26834b", s=55, label="Start", zorder=5)
    axes[0, 0].scatter(*p[-1, :2], color="#bb3e35", marker="x", s=75, label="End", zorder=6)
    if comparison:
        points = np.array([[0., 0.]] + [e["truth_xy_m"] for e in comparison["events"]])
        axes[0, 0].scatter(points[:, 0], points[:, 1], marker="|", s=140,
                           color="#444444", label="Tape stops (y=0 assumed)", zorder=4)
        axes[0, 1].plot(t, 100 * p[:, 1], color="#2465b2")
        axes[0, 1].set(ylabel="Estimated lateral offset [cm]", title="Straight-line lateral estimate")
        for event in comparison["events"]:
            axes[1, 0].scatter(event["t_s"], event["truth_xy_m"][0], marker="x", color="#444444", zorder=5)
    else:
        axes[0, 1].plot(t, p[:, 0], label="x", color="#2465b2")
        axes[0, 1].plot(t, p[:, 1], label="y", color="#26834b")
        axes[0, 1].set(ylabel="Reported position [m]", title="Position over time; no external XY truth")
        axes[0, 1].legend()
    axes[0, 0].set(xlabel="Forward x [m]", ylabel="Left y [m]", title="Actual recorded sensors replayed through current filter")
    axes[0, 0].set_aspect("equal", adjustable="datalim")
    axes[0, 0].legend(fontsize=8)
    axes[1, 0].plot(t, p[:, 0], label="Reported x", color="#2465b2")
    axes[1, 0].plot(t, fp[:, 0], label="Internal ESKF x (diagnostic)", color="#a36b1d", alpha=0.75)
    axes[1, 0].set(xlabel="Log time [s]", ylabel="x [m]", title="Reported pose and internal inertial state")
    axes[1, 0].legend(fontsize=8)
    axes[1, 1].plot(t, yaw, color="#70479c")
    axes[1, 1].set(xlabel="Log time [s]", ylabel="Unwrapped relative yaw [degrees]", title="Filtered heading; no measured angle truth")
    if np.any(ready):
        aligned_t = t[np.flatnonzero(ready)[0]]
        for ax in (axes[0, 1], axes[1, 0], axes[1, 1]):
            ax.axvspan(t[0], aligned_t, color="gray", alpha=0.12)
    for ax in axes.flat:
        ax.grid(alpha=0.23)
    axes[0, 1].set_xlabel("Log time [s]")
    fig.suptitle(name + " | current config, original sample timestamps", fontsize=13)
    fig.savefig(OUT / f"{Path(name).stem}_trajectory.png", dpi=150)
    plt.close(fig)


def evaluate(path, metadata):
    rows = list(logger.replay(str(path)))  # applies the legacy IMU mount rotation once
    production_class = odometry.Odometry

    class ObservedOdometry(production_class):
        """Observe diagnostics after the production step; never mutate its state."""
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.nis_events = []
            self.min_covariance_eigenvalue = float("inf")
            self.max_quaternion_norm_error = 0.0

        def step(self, *args, **kwargs):
            counts = {name: len(values) for name, values in self.nis.items()}
            super().step(*args, **kwargs)
            for name, values in self.nis.items():
                if len(values) > counts.get(name, 0):
                    self.nis_events.append((self.cycles-1, name, values[-1]))
            self.max_quaternion_norm_error = max(self.max_quaternion_norm_error,
                abs(float(np.linalg.norm(self.state['q'])) - 1.0))
            if self.cycles % config.EKF_RATE_HZ == 0:
                P_now = self.state['P']
                self.min_covariance_eigenvalue = min(self.min_covariance_eigenvalue,
                    float(np.linalg.eigvalsh((P_now + P_now.T)/2).min()))
            return self

    # Retain the real replay's dt policy and loop, adding read-only observations.
    with patch.object(replay.odometry, "Odometry", ObservedOdometry):
        odo, history = replay.run(rows)
    t = np.array([r["t"] for r in rows])
    device_t = np.array([r["imu_t"] for r in rows])
    dt = np.diff(t)
    timing_dt = dt[1:] if len(dt) > 1 else dt
    p = np.array([h["pos"] for h in history])
    fp = np.array([h["filter_pos"] for h in history])
    rpy = np.array([h["rpy"] for h in history])
    q = odo.state["q"]
    P = odo.state["P"]
    observed = np.array([
        [r["t"], r["imu_t"], *r["accel"], *r["gyro"],
         *(value for w in r["wheels"] for value in
           (w["position_rad"], w["velocity_rads"], w["current_A"]))]
        for r in rows
    ])
    comparison = checkpoint_comparison(history, rows, metadata.get("ground_truth"))
    ready_indices = [i for i, h in enumerate(history) if h["ready"]]
    unwrapped_yaw = np.rad2deg(np.unwrap(np.deg2rad(rpy[:, 2])))
    contiguous_still = max_contiguous_still = 0.0
    for index, h in enumerate(history):
        elapsed = dt[index-1] if index else 1/config.EKF_RATE_HZ
        contiguous_still = contiguous_still + elapsed if h['stopped'] else 0.0
        max_contiguous_still = max(max_contiguous_still, contiguous_still)
    summary = {
        "file": path.name,
        "input_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "samples": len(rows),
        "duration_s": float(t[-1] - t[0]),
        "rate_hz_excluding_first_gap": float(1 / timing_dt.mean()),
        "first_gap_ms": float(dt[0] * 1000),
        "max_gap_ms_excluding_first": float(timing_dt.max() * 1000),
        "host_nonincreasing_intervals": int(np.sum(dt <= 0)),
        "imu_nonincreasing_intervals": int(np.sum(np.diff(device_t) <= 0)),
        "repeated_imu_samples": int(np.sum(np.diff(device_t) == 0)),
        "nonfinite_input_values": int(np.sum(~np.isfinite(observed))),
        "dt_fallback_intervals": int(np.sum((dt <= 0) | (dt >= 0.5))),
        "legacy_imu_frame_rotated": any(r["source_frame"] == "arduino_sensor_legacy" for r in rows),
        "alignment_complete": odo.ready,
        "alignment_time_s": float(t[ready_indices[0]]) if ready_indices else None,
        "max_contiguous_detector_still_s": max_contiguous_still,
        "moving_samples_before_alignment": int(sum(
            not h["ready"] and any(abs(w["velocity_rads"]) > config.ZUPT_WHEEL_SPEED_MAX for w in r["wheels"])
            for h, r in zip(history, rows))),
        "final_reported_xyz_m": p[-1].tolist(),
        "final_internal_eskf_xyz_m": fp[-1].tolist(),
        "end_distance_from_origin_xy_m": float(np.linalg.norm(p[-1, :2])),
        "reach_xy_m": float(np.max(np.linalg.norm(p[:, :2], axis=1))),
        "reported_xy_path_length_m": float(np.linalg.norm(np.diff(p[:, :2], axis=0), axis=1).sum()),
        "max_abs_estimated_y_m": float(np.max(np.abs(p[:, 1]))),
        "final_relative_yaw_deg": float(rpy[-1, 2]),
        "unwrapped_yaw_min_max_deg": [float(unwrapped_yaw.min()), float(unwrapped_yaw.max())],
        "zupt_fraction": odo.zupt_cycles / odo.cycles,
        "finite_output_history": bool(np.isfinite(p).all() and np.isfinite(fp).all() and np.isfinite(rpy).all()),
        "final_covariance_finite": bool(np.isfinite(P).all()),
        "final_covariance_symmetry_max_error": float(np.max(np.abs(P - P.T))),
        "final_covariance_min_eigenvalue": float(np.linalg.eigvalsh((P + P.T)/2).min()),
        "final_quaternion_norm_error": float(abs(np.linalg.norm(q) - 1)),
        "max_quaternion_norm_error_over_history": odo.max_quaternion_norm_error,
        "min_covariance_eigenvalue_sampled_1hz": odo.min_covariance_eigenvalue,
        "nis": {name: {"count": len(v), "mean": float(np.mean(v)),
                       "dof": config.NIS_DOF[name], "mean_over_dof": float(np.mean(v)/config.NIS_DOF[name])}
                for name, v in odo.nis.items()},
        "checkpoints": comparison,
    }
    summary['replay_health_pass'] = bool(summary['finite_output_history'] and
                                         summary['final_covariance_finite'] and odo.ready)
    summary['status'] = ('completed' if summary['replay_health_pass'] else
                         'alignment incomplete; trajectory is not a motion estimate')
    baseline_file = OUT / f"{path.stem}_metrics.json"
    if baseline_file.exists():
        baseline = json.loads(baseline_file.read_text(encoding='utf-8'))
        summary['read_only_diagnostic_final_pose_difference_m'] = float(np.max(np.abs(
            p[-1] - np.array(baseline['final_reported_xyz_m']))))
        summary['read_only_diagnostic_final_yaw_difference_deg'] = float(abs(
            rpy[-1, 2] - baseline['final_relative_yaw_deg']))
    with (OUT / f"{path.stem}_nis.csv").open('w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['t_s', 'observation', 'nis', 'dof', 'nis_over_dof'])
        for index, name, value in odo.nis_events:
            writer.writerow([t[index], name, value, config.NIS_DOF[name], value/config.NIS_DOF[name]])
    if odo.nis_events:
        fig, axes = plt.subplots(len(config.NIS_DOF), 1, figsize=(12, 9), sharex=True, constrained_layout=True)
        for ax, name in zip(axes, config.NIS_DOF):
            events = [(t[i], v/config.NIS_DOF[name]) for i, n, v in odo.nis_events if n == name]
            if events:
                events = np.array(events)
                ax.plot(events[:, 0], events[:, 1], lw=0.5, color='#2465b2')
            ax.axhline(1, color='#bb3e35', linestyle='--', lw=1)
            ax.set(yscale='symlog', ylabel=f'{name}\nNIS / dof')
            ax.grid(alpha=0.2)
        axes[-1].set_xlabel('Log time [s]')
        fig.suptitle(path.name + ' | sequential innovations (reference mean NIS/dof = 1)')
        fig.savefig(OUT / f'{path.stem}_nis.png', dpi=150)
        plt.close(fig)
    with (OUT / f"{path.stem}_filtered.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["t_s", "x_m", "y_m", "z_m", "roll_deg", "pitch_deg", "yaw_deg",
                         "internal_eskf_x_m", "internal_eskf_y_m", "internal_eskf_z_m", "ready", "stillness_detector"])
        for h in history:
            writer.writerow([h["t"], *h["pos"], *h["rpy"], *h["filter_pos"], h["ready"], h["stopped"]])
    plot_run(path.name, history, comparison)
    (OUT / f"{path.stem}_metrics.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    print(json.dumps({k: summary[k] for k in
                      ("file", "status", "samples", "alignment_time_s", "max_contiguous_detector_still_s",
                       "final_reported_xyz_m", "final_relative_yaw_deg", "checkpoints")}))
    return summary


if __name__ == "__main__":
    metadata = json.loads((ROOT / "logs/experiments.json").read_text(encoding="utf-8"))["runs"]
    names = ["2026-09-06_4wheel_still.csv", "2026-09-06_2334_drive.csv",
             "2026-09-06_2347_drive.csv", "2026-09-06_2351_drive.csv",
             "2026-09-06_2329_drive.csv", "2026-09-06_2323_drive.csv"]
    metrics = []
    for name in names:
        print(f"Replaying {name} ...", flush=True)
        metrics.append(evaluate(ROOT / "logs" / name, metadata.get(name, {})))
    source_hashes = {str(p.relative_to(ROOT)).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted((ROOT / "rover").glob("*.py"))}
    document = {
        "evaluation_date_kst": "2026-10-01",
        "configuration": {k: getattr(config, k) for k in (
            "STARTUP_ALIGNMENT_SECONDS", "WHEEL_RADIUS_M", "WHEELBASE_M", "ARDUINO_IMU_TO_BODY",
            "GYRO_NOISE_DENSITY", "ACCEL_NOISE_DENSITY", "GYRO_BIAS_RANDOM_WALK",
            "ACCEL_BIAS_RANDOM_WALK", "R_WHEEL_VELOCITY", "R_ZUPT", "R_ZARU", "R_GRAVITY")},
        "source_sha256": source_hashes,
        "runs": metrics,
        "excluded": {
            "2026-09-06_2wheel_still.csv": "Historical two-wheel CSV differs from current four-wheel configuration.",
            "2026-09-06_4wheel_airborne*.csv": "Wheels spun off the ground; wheel speed is not vehicle ground speed.",
            "rover/run3.csv": "No experiment metadata establishes floor contact, route or independent truth.",
        },
        "accuracy_scope": "Measured longitudinal stop errors are available only for 2334 and 2347. "
                          "Other trajectories, lateral offsets and yaw are estimates without independent truth. "
                          "2334/2347 were previously used for tuning, so they are not holdout validation.",
    }
    (OUT / "metrics.json").write_text(json.dumps(document, indent=2), encoding="utf-8")
    print(f"Completed {len(metrics)} actual-log replays; artifacts: {OUT}", flush=True)
