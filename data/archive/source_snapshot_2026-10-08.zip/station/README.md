# Station

노트북에서 여는 Rover 조종 화면과 현장 사용 설명서다.

## 현장 운영자: 여기서 시작

**[한국어 현장 사용 설명서](web/manual.html)**가 소프트웨어 조작 절차의 원본이다.
스테이션 위쪽의 **사용 설명서**로 열거나, `station/web/manual.html`을 직접 연다.
인터넷 없이 읽을 수 있고 **인쇄 / PDF 저장** 버튼으로 출력할 수 있다.
연결, 실행 모드, 화면 확인, 조작, 기록 복사, 운영자 인계, 종료와 문제 해결을 담았다.
현장 절차는 이 HTML 한 곳에서 갱신하고 README에 복사하지 않는다.

현재 검증 범위와 운용 제한은 [로드맵](../docs/05_한계와_로드맵.md)이 기준이다.
모터·센서·Pico의 실기 검증과 현장 운용 허용 여부는 설명서가 대신 판정하지 않는다.

## 파일과 개발 진입점

| 파일 | 역할 |
|---|---|
| [station.py](station.py) | 표준 라이브러리만으로 localhost에서 화면 파일을 제공. 기본 포트 8765, `--port`로 변경 가능 |
| [web/index.html](web/index.html) | 조종 화면 |
| [web/manual.html](web/manual.html) | 한국어 소프트웨어 현장 사용 설명서; 자체 스타일과 인쇄 스타일 포함 |
| [web/](web/) | 프레임워크·외부 다운로드 없는 HTML/CSS/JavaScript |
| [link_test.py](link_test.py) | 구동 명령 없이 연결·영상·telemetry·ping을 측정하는 도구 |

화면은 Jetson의 `rover_main.py`에 직접 연결한다. 로컬 Python 서버는 화면 파일만
제공한다. 영상은 브라우저의 WebCodecs를 사용하므로 Chrome/Edge의 localhost 또는
HTTPS 문맥이 필요하다. 모양은 PSI ground station (`postech-psi/Avionics`,
`ground-station`)을 참고했다. 실행 상수와 보정값은 `rover/config.py`가 기준이다.

상세 절차와 기록:

- [실행·분석 가이드](../docs/04_실행_가이드.md): 개발자용 통신 점검, 로그 검사, replay.
- [코드 해설](../docs/02_구현_코드해설.md): 구성 요소와 제어 흐름.
- [Jetson 설치·시험 기록](../docs/11_jetson_bringup.md): 설치, 영상의 60 Hz 조명 설정, 날짜가 있는 실측.
- [현장 네트워크](../docs/12_field_link.md): 공유기, AX210, Wi-Fi 프로필, 범위 측정.
- [Pico 벤치 절차](../firmware/pico/README.md): 펌웨어와 실제 서보·배터리 검증.

배터리 표시 임계값과 servo trim은 설정값이며 해당 배터리/장착 상태의 교정 결과로
간주하지 않는다. 현재 교정·기록 범위는 로드맵의 IO-01이 관리한다.
