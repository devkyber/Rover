"""Exercise range-test verdicts over real local WebSocket connections.

    python -m unittest station.test_link_test -v

No hardware, drive messages, or measurement CSV files are used.
"""
import json
from pathlib import Path
import socketserver
import subprocess
import sys
import threading
import time
import unittest

from rover import websocket


class LinkTestScreen(unittest.TestCase):
    def run_screen(self, fault):
        stopped = threading.Event()
        received = []

        class Handler(socketserver.BaseRequestHandler):
            def handle(self):
                self.request.settimeout(4)
                ws = websocket.accept(self.request)
                if ws is None:
                    return
                started = time.monotonic()

                def stalled():
                    return time.monotonic() - started > 0.25

                def transmit():
                    try:
                        while not stopped.is_set():
                            if ws.path == "/control":
                                if fault != "control_tail" or not stalled():
                                    ws.send(json.dumps({"type": "telemetry", "wifi_dbm": -48,
                                                        "camera": {"fps": 30}}))
                            elif fault != "no_video" and (fault != "video_tail" or not stalled()):
                                ws.send(b"\x01test-frame")
                            stopped.wait(0.04)
                    except OSError:
                        pass

                sender = threading.Thread(target=transmit, daemon=True)
                sender.start()
                try:
                    while not stopped.is_set():
                        payload = ws.recv()
                        if payload is None:
                            break
                        msg = json.loads(payload)
                        received.append(msg)
                        if msg.get("type") == "ping" and not (fault == "control_tail" and stalled()):
                            ws.send(json.dumps({"type": "pong", "id": msg["id"]}))
                except OSError:
                    pass
                finally:
                    ws.close()
                    ws._reader.close()

        class Server(socketserver.ThreadingTCPServer):
            daemon_threads = True

        with Server(("127.0.0.1", 0), Handler) as server:
            worker = threading.Thread(target=server.serve_forever, daemon=True)
            worker.start()
            try:
                result = subprocess.run(
                    [sys.executable, str(Path(__file__).with_name("link_test.py")),
                     "127.0.0.1", "--port", str(server.server_address[1]),
                     "--seconds", "1.4", "--no-csv"],
                    capture_output=True, text=True, timeout=9)
            finally:
                stopped.set()
                server.shutdown()
                worker.join(timeout=2)
        self.assertTrue(received, result.stdout + result.stderr)
        self.assertTrue(all(msg["type"] == "ping" for msg in received), received)
        self.assertNotIn("Traceback", result.stderr)
        return result

    def test_healthy_link_passes_without_drive_messages(self):
        result = self.run_screen(None)
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        self.assertIn("Link screen: PASS", result.stdout)

    def test_silence_until_end_of_control_test_fails(self):
        result = self.run_screen("control_tail")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("Link screen: FAIL", result.stdout)

    def test_silence_until_end_of_video_test_fails(self):
        result = self.run_screen("video_tail")
        self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
        self.assertIn("Link screen: FAIL", result.stdout)

    def test_missing_camera_is_incomplete(self):
        result = self.run_screen("no_video")
        self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
        self.assertIn("Link screen: INCOMPLETE", result.stdout)


if __name__ == "__main__":
    unittest.main()
