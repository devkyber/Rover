"""BMI088 transport faults, FIFO motion preservation and CSV replay tests.

    python -m unittest discover -s rover -p test_imu_reader.py -v
"""
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

import config
import eskf
import imu_reader
import logger
import odometry


class Clock:
    def __init__(self):
        self.now = 100.0

    def __call__(self):
        return self.now

    def sleep(self, seconds):
        self.now += seconds


class Bus:
    """Time-driven SPI emulator, including spidev's destructive TX behavior."""
    def __init__(self):
        self.clock = Clock()
        self.devices = []
        self.accel = [100, -200, 5350]
        self.gyro = [1000, -2000, 3000]
        self.fail_open = False
        self.bad_id = False
        self.frozen_tick = None
        self.acc_ready = True
        self.overrun = False

    def factory(self):
        device = Device(self)
        self.devices.append(device)
        return device

    def reader(self, **kwargs):
        return imu_reader.RealIMU(spi_factory=self.factory,
                                 clock=self.clock, sleep=self.clock.sleep, **kwargs)


class Device:
    def __init__(self, bus):
        self.bus = bus
        self.reg = {}
        self.closed = False
        self.fifo = []
        self.next_sample = None

    def open(self, bus, cs):
        self.cs = cs
        if self.bus.fail_open and cs == 1:
            raise OSError('second chip open failed')
        self.reg = {0: 30 if cs == 0 else 15}

    def close(self):
        self.closed = True

    def xfer2(self, tx):
        command = list(tx)
        self.bus.clock.sleep(0.00001)
        now = self.bus.clock()
        if self.next_sample is not None:
            while now >= self.next_sample:
                self.fifo.append(self.bus.gyro[:])
                self.next_sample += 0.0025
        addr = command[0] & 0x7F
        if not command[0] & 0x80:
            value = command[1]
            if (self.cs, addr) in ((0, 0x7E), (1, 0x14)):
                self.reg = {0: 30 if self.cs == 0 else 15}
            else:
                self.reg[addr] = value
            if self.cs == 1 and addr == 0x3E:
                self.fifo.clear()
                self.next_sample = now + 0.0025
            rx = [0] * len(command)
        else:
            dummy = 2 if self.cs == 0 else 1
            n = len(command) - dummy
            if addr == 0:
                payload = [self.reg.get(i, 0) for i in range(n)]
                payload[0] = 0 if self.bus.bad_id else self.reg[0]
                if self.cs == 1 and n > 0x10:
                    payload[0x10] |= 0x80
            elif self.cs == 0 and addr == 3:
                payload = [0x80 if self.bus.acc_ready else 0]
            elif self.cs == 0 and addr == 0x12:
                tick = self.bus.frozen_tick
                if tick is None:
                    tick = int(now / 39.0625e-6) & 0xFFFFFF
                payload = list(struct.pack('<3h', *self.bus.accel)) + list(tick.to_bytes(3, 'little'))
            elif self.cs == 1 and addr == 0x0E:
                payload = [len(self.fifo) | (0x80 if self.bus.overrun else 0)]
            elif self.cs == 1 and addr == 0x3F:
                frames = self.fifo[:n // 6]
                del self.fifo[:n // 6]
                payload = list(b''.join(struct.pack('<3h', *frame) for frame in frames))
            else:
                payload = [self.reg.get(addr + i, 0) for i in range(n)]
                if self.cs == 1 and addr <= 0x10 < addr + n:
                    payload[0x10 - addr] |= 0x80
            rx = [0] * dummy + payload
        tx[:] = rx  # makes reused TX bugs observable
        return tx


class BMI088Tests(unittest.TestCase):
    def setUp(self):
        self.bus = Bus()

    def test_units_axes_fifo_and_mutating_transport(self):
        imu = self.bus.reader()
        self.bus.clock.sleep(0.010)
        data = imu.read()
        self.assertEqual(data['frame'], 'body')
        self.assertEqual(len(data['gyro_samples']), 4)
        expected = np.array([-2000, -1000, 3000]) * np.deg2rad(500) / 32768
        np.testing.assert_allclose(data['gyro'], expected)
        np.testing.assert_allclose(data['accel'], np.array([-200, -100, 5350]) * 6 * 9.80665 / 32768)
        self.assertEqual(data['temperature_c'], 23.0)
        self.bus.clock.sleep(.010)
        again = imu.read()
        self.assertGreater(again['device_t'], data['device_t'])
        self.assertAlmostEqual(again['dt'], again['timestamp'] - data['timestamp'])
        self.assertGreater(imu.stats()['gyro_frames'], 4)
        imu.close()
        self.assertTrue(all(d.closed for d in self.bus.devices))

    def test_proper_rotation_required_before_hardware_open(self):
        for matrix in (None, np.diag([1, 1, -1]), np.ones((3, 3)), [[float('nan')]*3]*3):
            with self.subTest(matrix=matrix), patch.object(config, 'BMI088_IMU_TO_BODY', matrix):
                with self.assertRaises(ValueError):
                    self.bus.reader()
        self.assertFalse(self.bus.devices)

    def test_sensor_frame_diagnostic_is_explicit(self):
        with patch.object(config, 'BMI088_IMU_TO_BODY', None):
            imu = self.bus.reader(sensor_frame=True)
            self.assertEqual(imu.read()['frame'], 'bmi088_sensor')

    def test_init_failures_close_both_handles(self):
        for failure in ('bad_id', 'fail_open'):
            bus = Bus()
            setattr(bus, failure, True)
            with self.subTest(failure=failure), self.assertRaises((OSError, imu_reader.IMUError)):
                bus.reader()
            self.assertTrue(all(d.closed for d in bus.devices))

    def test_startup_waits_for_stable_ids_but_runtime_does_not_retry(self):
        real_sleep = self.bus.clock.sleep
        self.bus.bad_id = True
        def settling(seconds):
            real_sleep(seconds)
            if self.bus.clock.now > 100.025:
                self.bus.bad_id = False
        self.bus.clock.sleep = settling
        imu = self.bus.reader()
        self.assertGreater(imu.stats()['startup_id_mismatches'], 0)
        self.bus.clock.sleep = real_sleep
        self.bus.bad_id = True
        with self.assertRaises(imu_reader.IMUError):
            imu.read()

    def test_reset_and_range_drift_latch_fault(self):
        for device, address, value in ((0, 0x7D, 0), (1, 0x0F, 0), (1, 0x3E, 8), (0, 2, 4)):
            bus = Bus()
            imu = bus.reader()
            bus.devices[device].reg[address] = value
            with self.subTest(address=address), self.assertRaises(imu_reader.IMUError):
                imu.read()
            self.assertEqual(imu.stats()['bad'], 1)
            with self.assertRaisesRegex(imu_reader.IMUError, 'unavailable'):
                imu.read()

    def test_stale_overflow_gap_and_clipping_rejected(self):
        for failure in ('stale', 'overflow', 'gap', 'gyro_clip', 'accel_clip'):
            bus = Bus()
            imu = bus.reader()
            if failure == 'stale':
                bus.acc_ready = False
            elif failure == 'overflow':
                bus.overrun = True
            elif failure == 'gap':
                imu.read()
                bus.clock.sleep(.060)
            elif failure == 'gyro_clip':
                bus.gyro[0] = -32768
            else:
                bus.accel[0] = 32767
            parsed_before = imu.stats()['parsed']
            with self.subTest(failure=failure), self.assertRaises(imu_reader.IMUError):
                imu.read()
            self.assertEqual(imu.stats()['parsed'], parsed_before)

    def test_tick_wrap_accepted_reset_and_frozen_rejected(self):
        imu = self.bus.reader()
        self.bus.frozen_tick = 0xFFFFC0
        first = imu.read()
        self.bus.clock.sleep(.01)
        self.bus.frozen_tick = 192
        second = imu.read()
        self.assertAlmostEqual(second['device_t'] - first['device_t'], 256 * 39.0625e-6)
        self.bus.clock.sleep(.01)
        with self.assertRaisesRegex(imu_reader.IMUError, 'clock stopped/reset'):
            imu.read()
        for backwards in (0, 100):
            bus = Bus()
            reader = bus.reader()
            bus.frozen_tick = 1000
            reader.read()
            bus.clock.sleep(.01)
            bus.frozen_tick = backwards
            with self.assertRaises(imu_reader.IMUError):
                reader.read()

    def test_delayed_first_read_discards_startup_only(self):
        imu = self.bus.reader()
        self.bus.clock.sleep(.10)
        sample = imu.read()
        self.assertGreater(imu.stats()['startup_fifo_discarded'], 30)
        self.assertLess(sample['dt'], .01)
        self.bus.clock.sleep(.10)
        with self.assertRaisesRegex(imu_reader.IMUError, 'gap'):
            imu.read()

    def test_transport_failure_latches_and_closed_reader_cannot_read(self):
        # Transport failure must never return/reuse an earlier sample.
        imu = self.bus.reader()
        imu.read()
        with patch.object(imu.gyr, 'xfer2', side_effect=OSError('disconnected')):
            with self.assertRaises(imu_reader.IMUError):
                imu.read()
        self.assertIsNone(imu.stats()['dropped'])
        imu.close()
        with self.assertRaises(imu_reader.IMUError):
            imu.read()


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.wheels = [{'position_rad': 0.0, 'velocity_rads': 0.0, 'current_A': 0.0}
                       for _ in config.WHEELS]

    def test_all_ordered_rates_reach_prediction(self):
        rates = np.array([[8., 0, 0], [0, 8., 0], [-8., 0, 0], [0, -8., 0]])
        accel = np.array([0., 0., config.GRAVITY])
        expected = eskf.create_state()
        for rate in rates:
            eskf.predict(expected, rate, accel, .01 / 4)
        odo = odometry.Odometry(startup_alignment_s=0)
        with patch.object(eskf, 'update_wheel_velocity'), patch.object(eskf, 'update_nhc'), patch.object(eskf, 'update_gravity'):
            odo.step(self.wheels, gyro=rates.mean(axis=0), accel=accel, dt=.01, gyro_samples=rates)
        np.testing.assert_allclose(odo.state['q'], expected['q'], atol=1e-14)
        self.assertGreater(np.linalg.norm(odo.state['q'][1:]), 1e-5)  # zero mean still has coning motion

    def test_invalid_batch_rejected_before_filter_mutation(self):
        odo = odometry.Odometry(startup_alignment_s=0)
        for batch in ([], [[float('nan'), 0, 0]], [[1, 2]], [[0, 0, 1]]):
            with self.subTest(batch=batch), self.assertRaises(ValueError):
                odo.step(self.wheels, gyro=[0, 0, 0], accel=[0, 0, 9.8], dt=.01, gyro_samples=batch)
            self.assertEqual(odo.cycles, 0)

    def test_startup_bias_then_fifo_turn(self):
        odo = odometry.Odometry(startup_alignment_s=.1)
        bias = np.array([.002, -.001, .003])
        accel = [0, 0, config.GRAVITY]
        for _ in range(50):
            odo.step(self.wheels, gyro=bias, accel=accel, dt=.01,
                     gyro_samples=np.tile(bias, (4, 1)))
        self.assertTrue(odo.ready)
        np.testing.assert_allclose(odo.gyro_bias, bias, atol=1e-12)
        moving = [dict(w, velocity_rads=.5) for w in self.wheels]
        turn = bias + [0, 0, .8]
        for _ in range(50):
            odo.step(moving, gyro=turn, accel=accel, dt=.01,
                     gyro_samples=np.tile(turn, (4, 1)))
        self.assertAlmostEqual(odo.rpy_deg[2], np.degrees(.8 * .5), places=3)

    def test_csv_replays_fifo_motion_and_preserves_raw_provenance(self):
        bus = Bus()
        imu = bus.reader()
        live = odometry.Odometry(startup_alignment_s=0)
        offline = odometry.Odometry(startup_alignment_s=0)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'imu.csv'
            log = logger.Logger(path, metadata=imu.metadata())
            for i in range(30):
                bus.gyro = [i * 100, -i * 40, 1000]
                bus.clock.sleep(.01)
                sample = imu.read()
                live.step(self.wheels, gyro=sample['gyro'], accel=sample['accel'],
                          dt=sample['dt'], gyro_samples=sample['gyro_samples'])
                log.log(i * .01, self.wheels, sample)
            log.close()
            for row in logger.replay(path):
                offline.step(row['wheels'], gyro=row['gyro'], accel=row['accel'],
                             dt=row['imu_dt'], gyro_samples=row['gyro_samples'])
            np.testing.assert_allclose(live.state['q'], offline.state['q'], atol=1e-6)
            meta = json.loads(Path(str(path) + '.meta.json').read_text(encoding='utf-8'))
            self.assertFalse(meta['bias_removed_in_driver'])
            self.assertIn('sha256', meta['sources']['config.py'])
            with self.assertRaises(FileExistsError):
                logger.Logger(path)


if __name__ == '__main__':
    unittest.main()
