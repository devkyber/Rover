"""Can the station laptop show the camera's H.264 in a browser, with no player installed?

    python h264_view_test.py <jetson-ip> 8086      then open http://localhost:8765

Start the source on the Jetson first (camera H.264 node, sent untouched):

    gst-launch-1.0 -q v4l2src device=/dev/video2 \
        ! video/x-h264,width=1920,height=1080,framerate=30/1 \
        ! h264parse config-interval=-1 ! video/x-h264,stream-format=byte-stream \
        ! tcpserversink host=0.0.0.0 port=8086 sync=false

Runs ON THE LAPTOP. It relays the Jetson's raw H.264 TCP stream to a page
that decodes it with the browser's built-in decoder (WebCodecs). WebCodecs
only works on https or localhost, which is why the page is served from here
and not from the Jetson.

The big counter next to the picture is for measuring delay: point the camera
at this screen and take a screenshot. The counter seen INSIDE the video is
older than the real one by exactly the camera-to-screen delay.
"""
import socket
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

JETSON = (sys.argv[1], int(sys.argv[2]))

PAGE = b"""<!doctype html><meta charset=utf-8><title>H.264 view test</title>
<style>
  body { margin:0; background:#111; color:#dfe6ee; font:14px Consolas,monospace; }
  canvas { display:block; max-width:100%; max-height:78vh; margin:auto; background:#000; }
  #bar { display:flex; gap:24px; align-items:center; padding:8px 14px; }
  #clock { font-size:44px; font-weight:700; color:#ffcc55; letter-spacing:2px; }
</style>
<div id=bar><div id=clock>0</div><div id=stats>connecting...</div></div>
<canvas id=c></canvas>
<script>
const canvas = document.getElementById('c'), ctx = canvas.getContext('2d');
const stats = document.getElementById('stats'), clock = document.getElementById('clock');
(function tick() { clock.textContent = String(Math.floor(performance.now()) % 100000).padStart(5, '0');
                   requestAnimationFrame(tick); })();

let frames = 0, bytes = 0, dropped = 0, note = '';
const dec = new VideoDecoder({
  output: f => {
    if (canvas.width !== f.displayWidth) { canvas.width = f.displayWidth; canvas.height = f.displayHeight; }
    ctx.drawImage(f, 0, 0); f.close(); frames++;
  },
  error: e => { note = 'DECODER ERROR: ' + e.message; },
});

let configured = false, needKey = true, au = [], auKey = false;
const hex = b => b.toString(16).padStart(2, '0');

// One NAL unit, start code included. A frame here is one slice, so a slice
// NAL (type 1 = ordinary, 5 = keyframe) completes the frame.
function nal(b) {
  const type = b[3] & 0x1f;
  if (type === 7 && !configured) {               // SPS: says profile and level
    const codec = 'avc1.' + hex(b[4]) + hex(b[5]) + hex(b[6]);
    dec.configure({ codec, optimizeForLatency: true });
    configured = true; note = codec;
  }
  au.push(b);
  if (type === 5) auKey = true;
  if (type !== 1 && type !== 5) return;
  const parts = au, key = auKey; au = []; auKey = false;
  if (!configured || (needKey && !key)) return;  // cannot start mid-stream
  needKey = false;
  // Never let delay build up: if the decoder falls half a second behind, skip
  // ahead to the next keyframe (at most 1 s away). A lower limit trips on
  // ordinary bursts -- several frames arriving in one read after a brief stall.
  if (dec.decodeQueueSize > 15) { dropped++; needKey = true; return; }
  const data = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let o = 0; for (const p of parts) { data.set(p, o); o += p.length; }
  dec.decode(new EncodedVideoChunk({ type: key ? 'key' : 'delta',
                                     timestamp: performance.now() * 1000, data }));
}

let buf = new Uint8Array(0);
function feed(chunk) {
  const nb = new Uint8Array(buf.length + chunk.length); nb.set(buf); nb.set(chunk, buf.length); buf = nb;
  const starts = [];
  for (let i = 0; i + 2 < buf.length; i++)
    if (buf[i] === 0 && buf[i + 1] === 0 && buf[i + 2] === 1) { starts.push(i); i += 2; }
  for (let k = 0; k + 1 < starts.length; k++) {
    let end = starts[k + 1];
    if (buf[end - 1] === 0) end--;               // next NAL uses a 4-byte start code
    nal(buf.slice(starts[k], end));
  }
  if (starts.length) buf = buf.slice(starts[starts.length - 1]);
}

setInterval(() => {
  stats.textContent = frames + ' fps decoded | ' + (bytes * 8 / 1e6).toFixed(1) + ' Mbit/s | '
    + canvas.width + 'x' + canvas.height + ' | decoder queue ' + dec.decodeQueueSize
    + ' | skipped ' + dropped + ' | reconnects ' + Math.max(reconnects, 0) + ' | ' + note;
  frames = 0; bytes = 0;
}, 1000);

// Reconnect forever. The browser aborts a running download whenever Windows
// reports a network change (seen here: ERR_NETWORK_CHANGED when the Jetson's
// USB-C network adapter flickers), so one fetch is not enough.
let reconnects = -1;
(async () => {
  for (;;) {
    reconnects++;
    buf = new Uint8Array(0); au = []; auKey = false; needKey = true;
    try {
      const r = (await fetch('/stream')).body.getReader();
      for (;;) { const { done, value } = await r.read(); if (done) break; bytes += value.length; feed(value); }
    } catch (e) { /* fall through and retry */ }
    await new Promise(ok => setTimeout(ok, 300));
  }
})();
</script>"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(PAGE)))
            self.end_headers()
            self.wfile.write(PAGE)
        elif self.path == "/stream":
            up = socket.create_connection(JETSON, timeout=5)
            up.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            try:
                while True:
                    data = up.recv(65536)
                    if not data:
                        break
                    self.wfile.write(data)
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError, socket.timeout):
                pass
            finally:
                up.close()
        else:
            self.send_error(404)


print("open http://localhost:8765")
ThreadingHTTPServer(("127.0.0.1", 8765), Handler).serve_forever()
