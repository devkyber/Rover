"""Pull a raw TCP video stream for N seconds and report delivery quality.

    python stream_pull_test.py <jetson-ip> <port> <mjpg|h264> [seconds]

Runs ON THE LAPTOP, against a gst-launch source on the Jetson that ends in
`! tcpserversink host=0.0.0.0 port=<port> sync=false` (full H.264 command in
h264_view_test.py; for MJPEG use /dev/video0 with image/jpeg caps).

Counts frames by their start markers and timestamps each arrival, so a
Wi-Fi stall shows up as a long gap even when the average fps looks fine.
"""
import re
import socket
import sys
import time

host, port, kind = sys.argv[1], int(sys.argv[2]), sys.argv[3]
seconds = float(sys.argv[4]) if len(sys.argv) > 4 else 10.0

# JPEG start-of-image, or an H.264 slice NAL (type 1 = P, type 5 = keyframe).
if kind == "mjpg":
    marker = re.compile(b"\xff\xd8\xff")
else:
    marker = re.compile(b"\x00\x00\x01[\x21\x41\x61\x25\x45\x65]")

s = socket.create_connection((host, port), timeout=5)
s.settimeout(2.0)
total = 0
arrivals = []
tail = b""
t0 = time.perf_counter()
while time.perf_counter() - t0 < seconds:
    try:
        chunk = s.recv(65536)
    except socket.timeout:
        continue
    if not chunk:
        break
    now = time.perf_counter()
    total += len(chunk)
    buf = tail + chunk
    # Only count markers that end inside the new chunk, so one split across
    # two recv() calls is counted once.
    for m in marker.finditer(buf):
        if m.end() > len(tail):
            arrivals.append(now)
    tail = buf[-4:]
s.close()

dur = time.perf_counter() - t0
gaps = sorted(b - a for a, b in zip(arrivals, arrivals[1:]))
n = len(arrivals)
if n < 2:
    print(f"{kind}: only {n} frames in {dur:.1f} s ({total} bytes)")
    sys.exit(1)
print(f"{kind}: {n} frames in {dur:.1f} s -> {n / dur:.1f} fps | "
      f"{total * 8 / dur / 1e6:.1f} Mbit/s | {total / n / 1e3:.0f} kB/frame | "
      f"frame gap median {1e3 * gaps[len(gaps) // 2]:.0f} ms, "
      f"99% {1e3 * gaps[int(len(gaps) * 0.99)]:.0f} ms, max {1e3 * gaps[-1]:.0f} ms")
