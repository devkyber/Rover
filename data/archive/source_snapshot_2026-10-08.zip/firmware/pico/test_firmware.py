"""
Tests for the Pico firmware. No Pico needed.

    python firmware/pico/test_firmware.py

firmware/pico/main.py keeps everything it decides in the Firmware class and
everything that touches a pin in PicoHardware. Here Firmware runs on a
bench made of plain Python: a clock the test advances by hand, three
recorded servo outputs, and an INA226 whose registers the test sets.

The failsafe is the reason this file exists. It is the only thing between
a crashed rover program and a lift servo that winds until something
breaks, and it cannot be tried safely on the real mechanism first.

The last test runs the same firmware behind rover/pico_link.py in real
time, so the two ends of the line protocol are checked against each other.
"""
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "..", "rover"))

import config          # noqa: E402
import pico_link       # noqa: E402

fw = pico_link.load_firmware()


class Bench:
    """Stands in for PicoHardware."""

    def __init__(self):
        self.now = 0
        self.incoming = bytearray()
        self.lines = []                 # everything the firmware sent
        self.pulse_us = [None, None, None]
        self.registers = {fw.REG_MANUFACTURER: fw.MANUFACTURER_TI,
                          fw.REG_CONFIG: 0x4127, fw.REG_BUS: 0, fw.REG_SHUNT: 0}
        self.i2c_dead = False
        self.watchdog_armed = False
        self.watchdog_feeds = 0
        self.led = None

    def ticks_ms(self):
        return self.now

    def read_byte(self):
        if not self.incoming:
            return -1
        byte = self.incoming[0]
        del self.incoming[0]
        return byte

    def write_line(self, text):
        self.lines.append(text)

    def set_pulse(self, index, microseconds):
        self.pulse_us[index] = microseconds

    def set_led(self, on):
        self.led = on

    def ina_read(self, register, signed=False):
        if self.i2c_dead:
            raise OSError("no answer")
        value = self.registers[register] & 0xFFFF
        return value - 0x10000 if signed and value & 0x8000 else value

    def ina_write(self, register, value):
        if self.i2c_dead:
            raise OSError("no answer")
        self.registers[register] = value

    def arm_watchdog(self):
        self.watchdog_armed = True

    def feed_watchdog(self):
        self.watchdog_feeds += 1


def start(**kwargs):
    bench = Bench()
    return bench, fw.Firmware(bench, **kwargs)


def run(bench, firmware, ms, send=b""):
    """Advance the clock one millisecond at a time, as the real loop does."""
    bench.incoming += send
    for _ in range(ms):
        bench.now += 1
        firmware.step()


def last_report(bench):
    """The newest P line, as a dict of ints."""
    line = next(l for l in reversed(bench.lines) if l.startswith("P,"))
    names = "ms bus shunt charge a b pan flags bad".split()
    return dict(zip(names, (int(f) for f in line.split(",")[1:])))


# ── the tests ──────────────────────────────────────────────────────

def test_power_on_is_silent():
    bench, firmware = start()
    assert bench.pulse_us == [0, 0, 0], "outputs must carry no pulses at power-on"
    assert bench.lines[0] == "H,1,500,2500,300"
    run(bench, firmware, 1000)
    r = last_report(bench)
    assert bench.pulse_us == [0, 0, 0], "silence must not turn into pulses by itself"
    assert r["flags"] & fw.FLAG_FAILSAFE and r["flags"] & fw.FLAG_DEFAULT_STOP
    assert not bench.watchdog_armed, "watchdog must stay off until a command arrives"


def test_command_sets_pulses():
    bench, firmware = start()
    run(bench, firmware, 60, b"S,1600,1400,1550\n")
    assert bench.pulse_us == [1600, 1400, 1550]
    r = last_report(bench)
    assert (r["a"], r["b"], r["pan"]) == (1600, 1400, 1550)
    assert not r["flags"] & fw.FLAG_FAILSAFE
    assert bench.watchdog_armed and bench.watchdog_feeds > 0


def test_failsafe_after_300_ms():
    bench, firmware = start()
    run(bench, firmware, 1, b"S,1800,1200,1600\n")
    run(bench, firmware, 299)
    assert bench.pulse_us == [1800, 1200, 1600], "tripped early: 300 ms have not passed"
    run(bench, firmware, 2)
    assert bench.pulse_us == [1500, 1500, 1500], "servos still running 301 ms after the last command"
    run(bench, firmware, 60)
    assert last_report(bench)["flags"] & fw.FLAG_FAILSAFE


def test_steady_commands_hold_off_the_failsafe():
    bench, firmware = start()
    for _ in range(40):                              # 2 s of commands, one every 50 ms
        run(bench, firmware, 50, b"S,1700,1700,1500\n")
        assert bench.pulse_us == [1700, 1700, 1500]
    assert not last_report(bench)["flags"] & fw.FLAG_FAILSAFE


def test_trimmed_stop_pulses():
    bench, firmware = start()
    run(bench, firmware, 10, b"N,1488,1507,1493\nS,1800,1800,1600\n")
    run(bench, firmware, 400)
    assert bench.pulse_us == [1488, 1507, 1493], "failsafe must use the stop pulses from N"
    assert not last_report(bench)["flags"] & fw.FLAG_DEFAULT_STOP
    # A new trim arriving while stopped takes effect at once.
    run(bench, firmware, 10, b"N,1490,1505,1495\n")
    assert bench.pulse_us == [1490, 1505, 1495]


def test_never_driven_stays_silent():
    bench, firmware = start()
    run(bench, firmware, 10, b"N,1490,1505,1495\nS,0,0,0\n")
    run(bench, firmware, 500)
    assert bench.pulse_us == [0, 0, 0], "an output that never carried a pulse must not start one"


def test_restart_after_watchdog_sends_stop():
    bench, firmware = start(start_stopped=True)
    assert bench.pulse_us == [1500, 1500, 1500]
    run(bench, firmware, 10, b"N,1490,1505,1495\n")
    assert bench.pulse_us == [1490, 1505, 1495]


def test_bad_lines_change_nothing():
    bench, firmware = start()
    run(bench, firmware, 10, b"S,1600,1600,1600\n")
    bad = [
        b"S,1600,1600\n",                 # a field missing
        b"S,1600,1600,1600,1600\n",       # one too many
        b"S,1600,1600,16x0\n",            # not a number
        b"S,1600,1600,-1600\n",           # sign
        b"S,1600,1600,499\n",             # below PULSE_MIN_US
        b"S,1600,1600,2501\n",            # above PULSE_MAX_US
        b"S,1600,1600,16000\n",           # five digits
        b"S,1600,1600,\n",                # empty field
        b"S 1600 1600 1600\n",            # wrong separator
        b"X,1,2,3\n",                     # unknown line
        b"AT\r\n",                        # a modem probe
        b"S,1900,1900,\xff1900\n",        # not plain text
        b"S," + b"1" * 60 + b"\n",        # too long
    ]
    for i, line in enumerate(bad, start=1):
        run(bench, firmware, 5, line)
        assert bench.pulse_us == [1600, 1600, 1600], f"acted on {line!r}"
        assert firmware.bad_lines == i, f"{line!r} was not counted as bad"
    run(bench, firmware, 60)
    assert last_report(bench)["bad"] == len(bad)
    # And a bad line must not count as a fresh command.
    run(bench, firmware, 300, b"S,9999,9999,9999\n")
    assert bench.pulse_us == [1500, 1500, 1500]


def test_lines_arriving_in_pieces():
    bench, firmware = start()
    run(bench, firmware, 5, b"S,1600,")
    assert bench.pulse_us == [0, 0, 0], "acted on half a line"
    run(bench, firmware, 5, b"1400,1550\r\nS,17")
    assert bench.pulse_us == [1600, 1400, 1550]
    run(bench, firmware, 5, b"00,1700,1500\n\n\n")
    assert bench.pulse_us == [1700, 1700, 1500]
    assert firmware.bad_lines == 0, "empty lines and \\r are not errors"


def test_twenty_reports_a_second():
    bench, firmware = start()
    run(bench, firmware, 1000)
    assert sum(l.startswith("P,") for l in bench.lines) == 20


def test_battery_counts_and_charge():
    bench, firmware = start()
    assert bench.registers[fw.REG_CONFIG] == fw.INA226_CONFIG, "averaging was not switched on"
    bench.registers[fw.REG_BUS] = 17760        # 22.2 V
    bench.registers[fw.REG_SHUNT] = 4000       # 10 mV = 5 A through 2 mohm
    run(bench, firmware, 1000)
    r = last_report(bench)
    assert (r["bus"], r["shunt"]) == (17760, 4000) and not r["flags"] & fw.FLAG_NO_BATTERY
    assert r["charge"] == 4000 * 1000, r["charge"]
    saved = config.BATTERY_SHUNT_OHM
    try:
        config.BATTERY_SHUNT_OHM = 0.002
        reading = pico_link.battery_reading(r["bus"], r["shunt"], r["charge"])
    finally:
        config.BATTERY_SHUNT_OHM = saved
    assert abs(reading["v"] - 22.2) < 1e-9 and abs(reading["a"] - 5.0) < 1e-9
    assert abs(reading["mah"] - 5.0 * 1000 / 3600) < 0.06, reading   # 5 A for 1 s = 1.39 mAh

    bench.registers[fw.REG_SHUNT] = -400 & 0xFFFF    # charging current reads negative
    run(bench, firmware, 100)
    assert last_report(bench)["shunt"] == -400

    run(bench, firmware, 60, b"Z\n")
    assert abs(last_report(bench)["charge"]) < 400 * 60


def test_battery_unavailable_and_back():
    bench, firmware = start()
    bench.registers[fw.REG_BUS] = 17760
    bench.registers[fw.REG_SHUNT] = 4000
    run(bench, firmware, 500)
    before = last_report(bench)["charge"]

    bench.i2c_dead = True
    run(bench, firmware, 3000, b"S,1600,1600,1600\n")
    r = last_report(bench)
    assert r["flags"] & fw.FLAG_NO_BATTERY and (r["bus"], r["shunt"]) == (0, 0)
    assert r["charge"] == before, "charge must not be counted while there is no reading"
    assert firmware.failsafe, "a dead battery monitor must not disturb the servo failsafe"

    bench.i2c_dead = False
    run(bench, firmware, 1200)
    r = last_report(bench)
    assert not r["flags"] & fw.FLAG_NO_BATTERY and r["bus"] == 17760
    # Counting resumes with the first good reading, at most 1200 ms ago.
    assert 0 < r["charge"] - before <= 4000 * 1200, "the outage itself was counted as charge"


def test_wrong_chip_is_reported_once():
    bench = Bench()
    bench.registers[fw.REG_MANUFACTURER] = 0xFFFF
    firmware = fw.Firmware(bench)
    run(bench, firmware, 5000)
    assert last_report(bench)["flags"] & fw.FLAG_NO_BATTERY
    assert sum(l.startswith("E,") for l in bench.lines) == 1


def test_ina226_reset_is_repaired():
    bench, firmware = start()
    bench.registers[fw.REG_CONFIG] = 0x4127      # brown-out: back to reset settings
    run(bench, firmware, 1100)
    assert bench.registers[fw.REG_CONFIG] == fw.INA226_CONFIG


def test_stop_servos_for_firmware_errors():
    bench, firmware = start()
    run(bench, firmware, 5, b"N,1490,1505,1495\nS,1800,1800,1600\n")
    firmware.stop_servos()
    assert bench.pulse_us == [1490, 1505, 1495]


def test_command_to_pulse_mapping():
    saved = config.SERVOS
    try:
        config.SERVOS = [("lift-a", 1490, 300, +1), ("lift-b", 1507, 300, -1), ("pan", 1500, 100, +1)]
        assert pico_link.servo_pulses(0, 0) == [1490, 1507, 1500]
        assert pico_link.servo_pulses(1, -1) == [1790, 1207, 1400]
        assert pico_link.servo_pulses(5, float("nan")) == [1790, 1207, 1500], "must clip, and treat NaN as zero"
        for lift in (-1, -0.3, 0, 0.3, 1):
            for us in pico_link.servo_pulses(lift, lift):
                assert fw.PULSE_MIN_US <= us <= fw.PULSE_MAX_US
    finally:
        config.SERVOS = saved


def test_through_pico_link_in_real_time():
    """Both ends of the wire: PicoLink on one side, the firmware file on the other."""
    events = []
    pico = pico_link.open_pico("fake", on_event=events.append)
    pico.start()
    try:
        deadline = time.monotonic() + 3
        while pico.state()["status"] != "ok" and time.monotonic() < deadline:
            time.sleep(0.02)
        s = pico.state()
        assert s["status"] == "ok", f"no report from the simulated Pico: {events}"
        assert s["failsafe"] and s["servo_us"] == [0, 0, 0]
        assert 20 < s["battery"]["v"] < 26 and 1.0 < s["battery"]["a"] < 2.0, s

        # The control loop calling every 10 ms.
        t_end = time.monotonic() + 0.6
        while time.monotonic() < t_end:
            pico.set_servos(1.0, -1.0)
            time.sleep(0.01)
        s = pico.state()
        assert s["servo_us"] == pico_link.servo_pulses(1.0, -1.0) and not s["failsafe"], s

        # The control loop hangs: no more calls. The thread is still alive
        # and must NOT keep the servos running on the old command.
        time.sleep(0.2 + 0.3 + 0.3)
        s = pico.state()
        assert s["failsafe"] and s["servo_us"] == pico_link.stop_pulses(), s
        assert any("connected" in e for e in events), events
        assert pico.bad_lines == 0, f"{pico.bad_lines} lines from the firmware did not parse"
    finally:
        pico.close()


if __name__ == "__main__":
    tests = [value for name, value in list(globals().items())
             if name.startswith("test_") and callable(value)]
    failed = 0
    for test in tests:
        try:
            test()
            print(f"  PASS  {test.__name__}")
        except AssertionError as e:
            failed += 1
            print(f"  FAIL  {test.__name__}: {e}")
    print(f"\n{len(tests) - failed} of {len(tests)} passed")
    sys.exit(1 if failed else 0)
