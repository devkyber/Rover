# Pico 2 I/O board

The Raspberry Pi Pico 2 on the PDB drives the three hobby servos (Lift A, Lift B,
camera pan) and reads the battery monitor (INA226). The Jetson talks to it over USB.

| File | Runs on | What |
|---|---|---|
| [`main.py`](main.py) | the Pico (MicroPython) | Firmware. The line format is in its first comment |
| [`test_firmware.py`](test_firmware.py) | laptop or Jetson | 17 tests of the firmware logic, no Pico needed |
| [`../rover/pico_link.py`](../../rover/pico_link.py) | Jetson | The other end, and a bench-check tool |

Settings are in [`rover/config.py`](../../rover/config.py): servo stop pulses, directions,
shunt resistance. The firmware has none to change.

Current verification scope and physical integration status are maintained in
[the roadmap](../../docs/05_한계와_로드맵.md#hw-01). This guide owns flashing and
the bench procedure; simulated checks do not verify pins, PWM, I²C or USB hardware.

---

## 1. Put the firmware on a new Pico

1. **MicroPython.** Download the **Pico 2** build (not "Pico", not "Pico 2 W") from
   [micropython.org/download/RPI_PICO2](https://micropython.org/download/RPI_PICO2/).
   This firmware was written against `RPI_PICO2-20260824-v1.29.0.uf2`.
   Hold **BOOTSEL** while plugging the Pico into USB, copy the `.uf2` onto the drive that
   appears, and the Pico restarts by itself (same page, "Installation instructions").
2. **mpremote** (the official tool for copying files to a MicroPython board):

   ```bash
   pip install mpremote
   ```

3. **Find the Pico's port.** It is the line with `2e8a:0005`.

   ```bash
   mpremote devs
   ```

   Always name the port in the next step. Without one, mpremote takes the first USB
   serial device it finds, which can be the U2D2.
4. **Copy the firmware and restart** (replace `COM9`; on the Jetson use `/dev/pico`):

   ```bash
   mpremote connect COM9 cp firmware/pico/main.py :main.py + reset
   ```

The onboard LED now blinks once a second (no commands arriving). Updating later is step 4
again.

On the Jetson, install the fixed name `/dev/pico` once (asks for the password):

```bash
sudo cp ~/Rover/jetson/99-rover-serial.rules /etc/udev/rules.d/ && sudo udevadm control --reload-rules && sudo udevadm trigger
```

---

## 2. Bench check

Do these with the servos lying loose on the bench, nothing attached to the horns.
`pico_link.py` finds the Pico by its USB ID on Windows and uses `/dev/pico` on the Jetson.

| # | Do | Expect |
|---:|---|---|
| 1 | Unplug the Pico, plug it in again, then `python rover/pico_link.py` | A line every 0.5 s. Without an INA226: `battery reading unavailable`. `servos [0, 0, 0] us  FAILSAFE`. Servos do not move. (Right after a `reset` instead of a re-plug it shows `[1500, 1500, 1500]`: the firmware cannot tell that restart from a watchdog one, so it sends stop pulses) |
| 2 | `python rover/pico_link.py --pulse 1500 1500 1500 --seconds 10` | Each servo still or creeping slowly. Change one number a few µs at a time until it stops; write the three results into `SERVOS` in `config.py` |
| 3 | `python rover/pico_link.py --lift 0.3 --seconds 3` | Both lift servos turn for 3 s, then stop within about 0.3 s. LED steady while turning. Check both wind the string **in**; if not, flip that servo's direction in `SERVOS` |
| 4 | Start test 3 with `--seconds 30`, then end the program the hard way: Task Manager, or `kill -9` | Servos stop about 0.3 s later. This is the failsafe working with no help from the Jetson |
| 5 | Start test 3 again, then pull the USB cable | **Measure and record the installed unit's response.** The Pico loses USB power. Check the current board's signal pull-downs and actual FS90MGR behavior; record the result under [HW-01](../../docs/05_한계와_로드맵.md#hw-01) |
| 6 | Run test 3 to its end and close it. Then `mpremote connect COM9 exec "import time; time.sleep(4); print(time.ticks_ms())"` | After 4 s it prints the milliseconds since the Pico was plugged in (a large number). If mpremote loses the connection instead, the Pico restarted: the watchdog disarm in `PicoHardware` is not working, and updating the firmware will need a re-plug first. Afterwards `mpremote connect COM9 reset` starts the firmware again |
| 7 | With an INA226 wired (SDA GP16, SCL GP17, 3V3, GND) and a supply across it | Voltage within a few 10 mV of a multimeter. Current: bench modules have a **10 mΩ** shunt, so set `BATTERY_SHUNT_OHM = 0.010` first, or current reads 5× high |

Then run the rover program with it: `python rover_main.py --no-motors --imu fake`, and
open the station page ([station/README](../../station/README.md)). The top bar shows the
battery, HEALTH shows SERVOS and BATTERY, and the LIFT and PAN buttons (keys `R` `F` and
`Q` `E`) run the servos while held.

---

## 3. What the firmware does when things go wrong

| Situation | Result |
|---|---|
| Rover program crashes, hangs, or is killed | No `S` line for 300 ms → stop pulse on all three servos |
| Rover's control loop hangs but its Pico thread lives | `pico_link.py` stops sending after 0.2 s → same as above |
| Operator e-stop, or station link lost | `rover_main.py` commands zero → stop pulses |
| A line arrives damaged | Rejected whole, counted, nothing moves |
| INA226 not answering | Battery reported as unavailable; servos unaffected; retried every second |
| Firmware itself freezes | Watchdog restarts the Pico after 2 s; it comes back sending stop pulses |
| USB cable out | Pico has no power. See test 5 |

The firmware does not program the INA226 calibration register. It reads the shunt-voltage
register (2.5 µV per count) and the Jetson divides by the shunt resistance. With the
2 mΩ shunt that is 1.25 mA per count, the range is the same ±41 A, and a different shunt
needs one number changed in `config.py` instead of new firmware.

The current board reference is [the PDB project entry point](../../docs/electronics/PDB_Design_Handover.md).
Software follow-ups are maintained in [IO-01](../../docs/05_한계와_로드맵.md#io-01);
update that entry rather than adding another checklist here.
