# Scout 2 연속 두 점프 — 2026-10-24 KST

사용자가 방금 연속 두 번 점프했다고 보고한 구간을 Jetson 원본과 대조했다.
에이전트는 읽기 전용 파일 복사만 수행했다. 제어 명령·재시작·설치 변경은 없다.

- [비교 플롯](two_jumps.png), [겹쳐 보기](comparison.png)
- [첫 점프 CSV](jump_1_records.csv), [두 번째 점프 CSV](jump_2_records.csv)
- [전체 원본 포함 ZIP](scout_two_jumps_raw.zip), [수치·품질·사건 근거](summary.json)
- 원본 위치·SHA256·고정 byte 범위는 [수집 위치](capture_location.json)의 폴더에 보존했다.

ZIP의 `original/`은 원본 SDK CSV·40-byte record binary·metadata의 그대로 복사본이다.
전체 원본은 약 522초이며, 이전 점프도 포함한다. `jump_1_records.csv`와
`jump_2_records.csv`는 최근 두 점프의 약 2.8초씩을 모든 센서·수신 순서 그대로 해독한 결과다.
`record_slot`은 전체 binary에서의 0-based 위치다. 이 CSV에는 raw counts와 nominal 변환값을 함께 둔다.
원본 binary에는 SDK CSV의 시각 검사에서 제외한 표본도 있으므로 행 수가 다를 수 있다.

같은 ESP session `3990465682`에서 최근 두 `PULL/prepare`의 성공 ACK 시각은
397.059182 s와 516.518158 s다. 해당 요청 ID·ACK는 `summary.json`에 보존했다.
각각 후속 가속도 burst와 일치한다. ACK는 서보 명령 수락이며 실제 이륙 라벨이 아니다.
Jetson UTC는 1970년으로 잘못 설정되어 있어 그래프는 ESP 경과시간으로 표시한다.

`plot.py`는 발사 burst 시작을 각 구간의 첫 ICM magnitude >3 g,
저가속 구간을 ICM magnitude <0.2 g인 가장 긴 연속 수신 구간,
접촉 후보를 그 뒤 첫 ICM >3 g로 정의한다. 독립 사건 정답이 없는 파형 관찰 기준이다.
저가속 구간 길이를 검증된 체공시간으로 해석하지 않는다.

ICM은 raw/2048 g, gyro는 raw/16.4 deg/s, ADXL은 raw×0.049 g인 nominal 값이다.
보정·장착축·충격 전달 검증은 없다. ICM saturation flag는 첫 구간 11개, 둘째 7개다.
두 추출 구간의 record CRC를 모두 검사했고 원래 slot 범위 내부 sequence gap은 0이다.
다만 ICM/ADXL FIFO 추정 시각이 일부 역전되며, 이를 정렬하거나 보간하지 않는다.
플롯은 역전·큰 시각 간격에서 선을 끊고 모든 선택 표본을 표시한다.
물리적 peak 정확도·높이·거리·궤적·무손실 현장 검증을 주장하지 않는다.

재생성: 저장소 루트에서 `python data/scout_two_jumps_2026-10-24/plot.py`.
이 스크립트는 보존된 로컬 원본만 읽는다. `capture.py`와 `package_raw.py`는 당시
원격 경로를 명시한 읽기 전용 수집 방법이며 원격 조회에 로컬 자격 증명이 필요하다.
