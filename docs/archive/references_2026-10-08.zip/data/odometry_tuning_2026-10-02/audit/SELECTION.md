# Frozen selection for the 2026-10-02 odometry comparison

The machine-readable selection is `selection_manifest.json`. It freezes **15 primary corner windows: 9 training corners from 0205 and 6 held-out corners from 0223/0224**. The required training sensitivity set contains all 10 bounded corners from 0205, including corner 5. Two terminal held-out windows are secondary diagnostics only.

This is a retrospective selection based on wheel structure. “Held out” means reserved from fitting; it does not mean blinded or previously unseen. The existing audit contains gyro-angle diagnostics. No parameter-variant scores, distance to 90 degrees, or rectangle closure were consulted to make this selection. The source hashes and selection provenance are recorded in the manifest. `freeze_selection.py` reproduces it from explicit wheel, timing, and quality fields.

## How windows and roles were chosen

1. Correct the encoder signs with `[1,-1,1,-1]` and use the existing 0.055 m nominal radius. Define forward speed as the mean of all four signed wheel speeds and differential speed as right-side mean minus left-side mean.
2. Reuse the existing wheel-only segmentation. Straight legs require forward speed at least 0.03 m/s, smoothed differential magnitude at most 0.01 m/s, duration at least 0.8 s, and encoder travel at least 0.05 m. Short gaps are merged only under the existing wheel-differential condition. Turns use a 150 ms differential boxcar, magnitude at least 0.025 m/s, duration at least 0.3 s, and at most 0.6 s merging gaps.
3. A bounded corner is the **whole interval from the preceding forward-leg end to the next forward-leg start**, with at least one complete wheel-turn core inside it. Reverse or wrong-direction corrections inside that interval are retained with their signs. Individual steering pulses are not assigned separate 90-degree labels.
4. Scope the primary analysis to repeated sequences with at least three bounded corner candidates and a consistent nonzero sign of net wheel differential. This categorical rule selects 0205, 0223, and 0224. It is an analysis choice suited to repeated rectangular driving, not proof that other runs are invalid. In particular, changing direction between actual corners can be legitimate; the operator's general description does not uniquely map those events in the other logs.
5. Apply the existing local criterion: integrated absolute mean forward wheel speed below 0.06 m. The label `strong_stationary_corner` therefore means **low encoder translation**, not proven stationary ground contact, no slip, or a measured right angle.
6. Use the earliest eligible run, 0205, for fitting. Reserve later eligible runs 0223 and 0224 for evaluation. Keep every qualifying corner in those runs.

The segmentation code does not feed gyro integrals, target angles, filter output, or closure into boundaries or structural labels. Gyro/acceleration quietness gates bias-reference stops separately. The 0.06 m local threshold is inherited from the audit, not adjusted for variant scores. Corner 2 of 0205 is near that threshold at 0.058642 m; corner 10 is 0.049414 m, and omitted corner 5 is 0.100878 m. The all-10 sensitivity result must accompany the nine-corner result.

All times below are seconds in the raw host `t` column, with both endpoints included. When integrating on `imu_t`, use the same source rows. Do not substitute a gyro-derived event boundary.

## Frozen bounded windows

| File suffix | Corner | Start | End | Role | Absolute forward wheel travel (m) |
|---|---:|---:|---:|---|---:|
| 0205 | 1 | 31.083808 | 49.803923 | Training | 0.007320 |
| 0205 | 2 | 54.714153 | 65.057729 | Training | 0.058642 |
| 0205 | 3 | 73.068041 | 81.813991 | Training | 0.005748 |
| 0205 | 4 | 86.955189 | 99.585822 | Training | 0.007993 |
| 0205 | 5 | 102.451714 | 109.492212 | All-10 sensitivity only | 0.100878 |
| 0205 | 6 | 112.884914 | 120.052762 | Training | 0.004821 |
| 0205 | 7 | 123.645991 | 143.806436 | Training | 0.005320 |
| 0205 | 8 | 147.075478 | 158.082933 | Training | 0.005142 |
| 0205 | 9 | 161.399035 | 170.750733 | Training | 0.006576 |
| 0205 | 10 | 174.036475 | 184.845275 | Training | 0.049414 |
| 0223 | 1 | 14.386127 | 31.228471 | Held out | 0.006118 |
| 0223 | 2 | 34.888280 | 39.341950 | Held out | 0.005738 |
| 0223 | 3 | 43.762603 | 58.200668 | Held out | 0.006753 |
| 0224 | 1 | 15.727398 | 30.479480 | Held out | 0.005053 |
| 0224 | 2 | 35.083963 | 50.127219 | Held out | 0.005941 |
| 0224 | 3 | 53.478313 | 76.696322 | Held out | 0.007013 |

These windows have positive net wheel differential. The signed nominal target is therefore +90 degrees under the existing sign convention, based on the operator's right-angle description. That is not an independently measured heading reference. Unknown side lengths cannot be used to validate distance scale.

The fifth extracted leg in 0224 is a continuation after a pause, with no detected turn between legs 4 and 5. Requiring a turn at every extracted leg break would incorrectly split its structure.

## Excluded and secondary windows

All **51 bounded candidates** are accounted for in the manifest: 15 primary and 36 excluded from the primary metric. Every exclusion has exact endpoints and its reason. A primary exclusion is not a declaration that the sensor samples are unusable.

| Log suffix | Bounded corners excluded from primary | Reason |
|---|---:|---|
| 0156 | 1 | Single bounded candidate; mixed translation, insufficient repeated-sequence structure. |
| 0158 | 9 | Mixed net directions `−,+,+,+,−,−,−,+,−`; only 4 locally low-translation corners. Keep those 4 as exploratory windows, not silently discarded outliers. |
| 0204 / 0204-2 | 0 | No accepted forward legs or bounded corners; retain for stationary/quality diagnostics. |
| 0205 | 1 | Corner 5 exceeds the existing 0.06 m local threshold; included in the all-10 sensitivity set. |
| 0209 | 4 | Mixed net directions; every candidate exceeds the local translation threshold. |
| 0213 | 21 | Mixed net directions and extensive combined translation/steering; every candidate exceeds the local threshold. |
| 0227 | 0 | No turn enclosed by two consecutive accepted forward legs. No primary corner label can be assigned from wheel structure. |

The four locally low-translation 0158 windows are corners **1 (139.268951–158.865480), 2 (165.383078–176.734909), 4 (193.592728–195.148270), and 6 (238.707933–251.014828)**. They are explicitly retained as `excluded_run_local_strong_4`. The all-10 0205 sensitivity set does not test the separate decision to exclude this mixed-direction run.

The manifest also lists all **12 wheel-turn episodes not enclosed by two accepted forward legs**, including these three terminal cases:

| Log | Start–end (s) | Wheel structure | Use |
|---|---|---|---|
| 0223 | 61.460543–67.518124 | Final turn 7, then reverse repositioning at approximately 65.724–67.096 s; 0.059015 m absolute forward travel. | Secondary held-out diagnostic only. |
| 0224 | 82.783716–90.012513 | Forward run-out through approximately 83.707 s, then final turn 6; 0.070389 m absolute forward travel. | Secondary held-out diagnostic only; also exceeds the local translation threshold. |
| 0205 | 186.365786–190.951907 | Final turn 16 is opposite the prior net-corner direction; later forward/reverse repositioning continues near the log end. | Unlabeled training diagnostic only. |

Each terminal window ends at the first sustained wheel-stop core, including the existing 0.25 s settling margin, after the final turn core. None has a following accepted forward leg. The first two resemble a final rectangle turn but cannot independently certify completion of the fourth corner. A secondary comparison may explicitly assume +90 degrees for those two; it must keep that assumption visible and must not pool them into primary accuracy or parameter fitting. Their manifest `expected_net_angle_deg` remains null; the optional assumption is in a separate field.

## Quality and limits

The ten logs contain **158,564 rows** with no nonfinite numeric values and no nonpositive host or device timestamp increments in the source audit. Source SHA-256 values are verified by the freeze script. Window sample counts, maximum host/device intervals, monotonicity, and acceleration-rail counts are stored per selected window. The isolated near-4g acceleration samples in 0158 (300.605 s) and 0213 (385.295 s) are outside the selected runs. Their handling/rotation interpretation is a separate diagnostic, not the reason for choosing primary corners.

The manifest also supplies `stationary_reference_windows`: all audit wheel-stop cores that pass the existing inertial quietness and gravity checks, plus a separate list of rejected wheel-stop windows. A stop requires every raw wheel speed magnitude at most 0.02 rad/s for at least 1 s, trims 0.25 s at both edges, and retains at least 25 samples. The audit requires every gyro-axis standard deviation below 0.03 rad/s, every acceleration-axis standard deviation below 0.25 m/s², and mean acceleration norm within 0.4 m/s² of 9.81. These are usable quiet-stop references, not external proof of absolute stationarity. Held-out stops can support fixed evaluation diagnostics or a prespecified online bias algorithm; do not use future held-out stops to fit training parameters. Interpolating bias between later stops is an offline oracle diagnostic.

Wheel-based segmentation cannot establish no slip or exact physical heading, and a nominal 90-degree instruction has execution uncertainty. The selection therefore supports a consistent comparison under the operator's labels, not a claim of absolute metrology. The 0227 wheel/gyro mismatch can be investigated separately; no gyro-angle mismatch is used as its selection criterion here.

Membership and endpoints are frozen for the current parameter comparison. Do not replace poor-scoring windows, tighten thresholds, or move boundaries after inspecting results. Any later selection change needs a new version, its reason, and results under this original manifest.
