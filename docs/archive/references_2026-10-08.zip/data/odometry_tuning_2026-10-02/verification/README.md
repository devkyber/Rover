# Offline verification, 2026-10-02 KST

All three commands exited with code 0; no failure lines appeared. The commands used Python 3.13.14 on Windows. Full output, commands, timestamps and durations are retained in this directory.

| Verification | Result | Wall time |
| --- | --- | ---: |
| `python rover/test_filter.py` | 11/11 structural checks; 10/10 scenarios | 68.487 s |
| `python data/odometry_tuning_2026-10-02/methods/experimental_variants.py` | Exact clone parity on 800 samples; 12 gain/covariance probes; 4 ZARU probes; restoration after exception | 0.526 s |
| `python rover/test_pipeline.py --fake --seconds 5 --log <verification/fake_pipeline.csv> --keep` | 10/10 audit checks | 5.257 s |

The structural suite includes five numerical measurement-Jacobian checks. The scenario suite contains nine trajectories with ten seeds each and one gyro-bias recovery check. Its deliberately unaligned, biased-gyro scenario without stops allows 42 degrees of yaw error and produced 40.58 degrees in its worst seed; passing that test does not establish adequate real-world accuracy.

The fake pipeline recorded and replayed 500 rows at 100.0 Hz, with 0.25 ms timing jitter and a maximum replay-value difference of 5.00e-07. Source inspection confirmed that `--fake` selects `FakeIMU` and bypasses motor/serial access.

The experimental clone matched the original baseline with maximum absolute difference 0.0. The 12 gain probes comprise four observations (wheel velocity, NHC, gravity, ZUPT) under each of three variants (baseline, vertical bias protected, all bias protected). All probe covariances met the script's positive-semidefinite tolerance. The largest vertical gyro-bias change under vertical protection was 2.168404344971009e-18 rad/s; all-bias protection left the gyro bias exactly unchanged. ZARU reduced gyro-bias error in all four supported variants. Source inspection confirms that the modified gain is used in both the state correction and the Joseph covariance update.

All 19 current `rover/*.py` files and all 10 raw logs listed in `baseline/manifest.json` matched their baseline SHA256 values before and after the commands. They were unchanged during this verification. See `source_and_input_hashes.json` for each expected and actual hash.

Limits: these are offline checks. They do not verify physical sensor scaling, serial communication, motor motion or ground-truth odometry accuracy. Clone parity covers the first 800 samples of `2026-10-02_0204_drive.csv`. The mathematical probes use one seeded positive definite covariance and one tilted state. The experimental projections are ablations and do not establish a complete observability-constrained filter.

Files: `verification_summary.json` records commands and timing; `*_tests.txt` retain full process output; `experimental_variants_details.json` retains numerical probe results; `fake_pipeline.csv` is the retained synthetic log. Run `python data/odometry_tuning_2026-10-02/verification/verify_current.py` to regenerate these machine-readable outputs.
