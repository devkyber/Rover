# New-recording odometry evaluation — 2026-10-02

The recorded-data pipeline runs successfully, but the new recordings reveal a gyro conversion error that materially distorts turns. Correcting the old Arduino gyro units by **1.14688** reduces mean discrepancy from the operator's nominal 90-degree corners from **9.49° to 3.86°** on six reserved corners. That correction has stronger support than the extra filter changes tested here.

All ten new recordings were audited and replayed through five variants: **158,564 input rows, 50 complete replays**. This work created experimental tools and results under this directory. Production Python files, firmware, installed libraries, configuration, and raw recordings were not changed. No hardware was commanded or flashed.

![Actual replayed trajectories](validation_trajectories.png)

These are actual wheel/IMU replays, with all corrective steering retained. No output is snapped to 90 degrees, forced into a rectangle, or adjusted to close the path. Unequal or unknown side lengths mean endpoint separation is **not** a measured position error. These recordings therefore cannot certify the approximately 5 cm position target. They support a useful heading comparison under the operator's approximate right-angle labels.

## Data worth using

| Recording suffix | Role and observations |
|---|---|
| `0156` | 11,685 rows; isolated mixed maneuvers, insufficient repeated-corner structure. Retain as a diagnostic replay. |
| `0158` | 32,195 rows; mixed turn directions and handling-like motion. Four locally low-translation windows remain exploratory. One acceleration sample reaches the recorded near-4g rail at 300.605 s. |
| `0204_drive-2` | 5,288 rows; mostly stationary with a short movement. Useful for bias/noise checks, insufficient travel for distance calibration. |
| `0204_drive` | 2,335 rows; stationary throughout by encoders. Best short stationary reference; quiet core 0.253–23.168 s. |
| `0205` | 19,642 rows; repeated straight/corner sequence. Nine primary training windows; all ten bounded windows retained in sensitivity results. Startup alignment completes at 19.054 s; selected corners start afterward. |
| `0209` | 6,880 rows; mixed directions and translation during corner candidates. Diagnostic only. |
| `0213` | 55,222 rows; long mixed run, combined translation/rotation and handling-like motion. Near-4g rail sample at 385.295 s. Diagnostic only. |
| `0223` | 7,733 rows; three bounded corners reserved from fitting. Final turn is retained separately because there is no subsequent accepted straight leg. |
| `0224` | 11,160 rows; three bounded corners reserved from fitting. Final turn has forward run-out and no subsequent accepted straight leg. |
| `0227` | 6,424 rows; differential wheel motion around 44–47 s without corresponding bias-corrected gyro rotation. Slip, constraint or loss of ground contact is possible; the recording cannot identify which. No bounded right-angle label. |

The audit found no nonfinite numeric rows or nonpositive host/device timestamp increments. All ten are tagged as body-frame IMU data. Isolated host gaps occur, but the 15 primary windows have maximum host interval 22.841 ms, maximum device interval 29.856 ms, and no acceleration-rail samples.

The [frozen selection](audit/selection_manifest.json) records exact timestamps, source hashes, **108 usable quiet-stop cores**, 12 rejected stop windows, all 51 bounded corner candidates and their disposition. [Selection rationale and interval table](audit/SELECTION.md) explain the thresholds and limitations.

Corner boundaries come from wheel-defined straight legs and turn episodes. A corner covers the whole interval from the preceding leg's end to the following leg's start, including wrong-way steering, reversals and pauses. The operator's clarification is essential: individual steering pulses must not each receive a 90-degree target.

Primary selection is retrospective: repeated sequences with consistently signed net wheel turns, then less than 6 cm integrated absolute mean wheel translation during the corner. This selects `0205`, `0223`, and `0224`; it is an analysis choice, not proof that excluded runs are invalid. Selection did not use proximity to 90 degrees, trajectory closure, or variant scores. “Reserved” means excluded from fitting, not blinded or previously unseen. The locally valid `0158` windows are explicitly retained rather than silently treated as bad measurements.

## Why the gyro correction is justified

The installed `Arduino_LSM6DS3` library identifies as version 1.0.3. Its source configures ±2000 dps and converts counts using `2000 / 32768 = 0.06103515625` dps/count. ST's own LSM6DS3 driver uses **70 mdps/count**, or **0.070 dps/count**, for this range. [ST sensor conversion implementation](https://raw.githubusercontent.com/STMicroelectronics/lsm6ds3-pid/master/lsm6ds3_reg.c)

Consequently, the correction for recordings made with the old conversion is:

`0.070 / (2000 / 32768) = 1.14688`

Every logged value on all three gyro axes in all ten files matches the old library's count spacing within firmware/CSV rounding tolerance. The local library source hash, raw-log hashes, tolerance and per-axis results are preserved in [gyro conversion evidence](methods/gyro_unit_quantization.json). Quantization does not identify the flashed binary by itself, but the installed source, firmware path and all-recording count spacing independently support this conversion explanation.

The Arduino upstream source retrieved during this investigation also uses 0.070 dps/count. This is a source observation, not a claim that every released library or flashed rover has that change. [Arduino source](https://raw.githubusercontent.com/arduino-libraries/Arduino_LSM6DS3/master/src/LSM6DS3.cpp)

In these experiments the factor is applied to **all raw gyro axes before startup alignment, stationary bias estimation and prediction**. Bias is then learned in the corrected units. Multiplying the final yaw would not be equivalent. Noise settings were left fixed to isolate this change. A production correction must be associated with the sensor/firmware encoding so that an upgraded library is not corrected twice; it must not become a universal factor for a future BMI088.

As a cross-check only, a scalar fitted to the nine training raw-gyro integrals is **1.14478**, close to 1.14688. This fit uses offline stop-interpolated bias and is not the causal estimator or the source of the tested correction. Across primary windows, changing host integration to device time changes raw angle by at most 0.209°, and initial versus local stationary bias changes it by at most 0.392°. These do not account for the original roughly 10-degree shortfall.

## Comparison on the same recorded samples

Numbers below are discrepancies from nominal +90°, not surveyed heading errors. Each filter variant runs from the beginning of every original recording; it is not reset at corner boundaries. Timing, wheel geometry, sample order and other configuration match the current production baseline.

| Method | Training mean, 9 corners | Training mean, all 10 | Reserved mean, 6 corners | Reserved worst |
|---|---:|---:|---:|---:|
| Current ESKF | 11.56° | 11.94° | 9.49° | 14.80° |
| ESKF with corrected gyro units | **2.56°** | **2.74°** | **3.86°** | 10.05° |
| Corrected ESKF + vertical gyro-bias protection | 2.65° | 2.82° | 3.48° | 9.92° |
| Corrected ESKF + all-axis gyro-bias protection | 2.62° | 2.80° | 4.22° | 9.91° |
| Corrected causal planar estimator | 2.56° | 2.73° | 3.92° | 10.04° |

The unit correction reduces reserved mean discrepancy by approximately **59%**. Including the omitted mixed-translation training corner preserves the conclusion. Scoring at the middle of the neighboring straight legs gives reserved means of 9.55°, 3.84°, 3.49°, 4.21° and 3.91° respectively. Expanding/contracting corner boundaries by 0.1 s changes an individual reserved result by no more than 0.351° across these variants.

| Reserved corner | Current | Units corrected | Units + vertical bias protection | Planar |
|---|---:|---:|---:|---:|
| `0223` #1 | 79.91° | 91.62° | 91.91° | 91.86° |
| `0223` #2 | 79.25° | 87.95° | 87.95° | 87.96° |
| `0223` #3 | 80.96° | 86.56° | 88.88° | 92.80° |
| `0224` #1 | 80.57° | 91.57° | 91.33° | 92.20° |
| `0224` #2 | 75.20° | 85.55° | 85.43° | 85.43° |
| `0224` #3 | 87.16° | 100.05° | 99.92° | 100.04° |

The difficult `0224` third corner remains close to 100° under every corrected method. No variant reliably resolves that discrepancy. Operator execution uncertainty, residual calibration and physical motion remain possible; the data do not separate them. It would be misleading to tune or snap that individual event until it reads 90°.

The gain-protection experiments address an indirect yaw path: wheel, nonholonomic, gravity and zero-velocity updates can change gyro bias through covariance even when their direct yaw correction is projected away. The vertical variant also removes the world-vertical component of their gyro-bias gain. The all-axis variant removes all gyro-bias gain from those updates. Both retain stationary gyro-bias updates and use the same projected gain in the state and Joseph covariance updates. These are experimental constraints, not a proof of full filter observability consistency. Vertical protection's additional 0.38° reserved improvement is small, and training performance slightly worsens. Six approximate corners are insufficient to select it confidently as a new default.

The planar comparator learns bias only during detected stops: production five-second startup, followed by a trailing one-second 10% trimmed mean. During movement it integrates corrected body `gz` and signed wheel speed. It uses only past samples, with no corner labels. It produces comparable accuracy at much lower conceptual complexity, but assumes level ground and has no tilt, lateral-slip, handling or 3D covariance model. It is a useful baseline, not evidence that replacing the ESKF improves this dataset.

## Additional wheel calibration and next algorithm choices

A separate encoder-only net-angle experiment fits one effective turning width using the nine training corners. It yields **0.3761 m**, compared with the configured physical width of 0.1585 m. Applying that fixed fit to the six reserved corners gives **3.34° mean / 9.43° worst** discrepancy; training mean is 4.47°. Using physical width directly gives 123.31° mean discrepancy, illustrating why naive differential-drive wheel yaw is unsuitable here.

This is a diagnostic based on integrated right-minus-left wheel travel, not a full estimator replay. Effective width represents the current turning behavior, including tire scrub/slip and other wheel-scale effects; it is not a new measurement of physical width. Do not overwrite `WHEELBASE_M` with it. A separately named, uncertainty-weighted wheel-yaw model could be explored later, with speed/surface/reversal validation and disagreement gating. The `0227` mismatch argues against trusting it continuously. It was fitted only on `0205`; no reserved corner entered the fit.

Recommended order:

1. Correct and record the gyro encoding at the firmware/input boundary. Keep the existing ESKF initially; confirm the firmware's actual conversion and prevent double correction.
2. Retain vertical bias protection and the planar implementation as experimental comparators. The present evidence does not establish a worthwhile general accuracy gain from either.
3. Explore effective wheel-turn calibration as an independent, gated heading observation. Preserve the physical geometry and account for direction, surface and slip. The current net-angle result is promising but limited to one training run.
4. Use the stationary cores for sensor-specific noise work, but do not infer a complete bias random-walk model from a roughly 23-second record. Quiet gyro standard deviations are about 0.0017–0.0021 rad/s after unit correction; dynamic residuals need separate modeling. No unvalidated Q/R retuning is promoted here.
5. For a subsequent physical check, record several clockwise and counterclockwise right-angle sequences with brief settled pauses, along with a taped start/end reference and one measured straight distance. Smooth turns are unnecessary: keep corrections in the net corner, as in this analysis. That provides the missing evidence for the 5 cm distance/position target and direction-dependent calibration.

## Verification and reproducibility

Fresh current-code checks passed **11/11 structural tests, 10/10 simulated scenarios and 10/10 fake-pipeline checks**. The fake pipeline recorded 500 samples at 100 Hz and agreed with replay to 5e-7. Gain experiments passed exact unchanged-clone parity on 800 actual stationary samples, 12 covariance/gain probes, four stationary-bias learning probes and restoration after an exception. The planar estimator passed seven synthetic tests including signed correction turns, startup reset, bias freeze while moving, robust stops and causal prefix equivalence.

Every variant finished all ten recordings with finite pose/bias outputs and completed startup. ESKF quaternion norm errors stayed below 2.3e-16; covariance snapshots sampled at approximately 1 Hz remained positive definite. These sampled checks do not prove consistency at every sample or physical accuracy. All 19 production Python hashes and all ten raw-log hashes match the baseline before and after verification. [Verification evidence and limits](verification/README.md)

Artifacts:

- [All ten trajectory comparisons](all_recordings_trajectories.png) and [raw signal overview](audit/signal_overview.png).
- [Per-corner output CSV](corner_comparison.csv): all 51 candidates for every variant, with unselected candidates left without a right-angle target.
- [Summary metrics](comparison_summary.json), including sensitivity checks and the encoder-only calibration.
- [Replay runner](replay_experiments.py), [gain variants](methods/experimental_variants.py), [planar estimator](methods/planar_replay.py), and [common scoring/plots](score_experiments.py).

Each variant directory contains per-recording compressed NPZ trajectories, per-recording diagnostics and a manifest. Run from the repository root:

```powershell
python data/odometry_tuning_2026-10-02/replay_experiments.py --variant baseline
python data/odometry_tuning_2026-10-02/replay_experiments.py --variant baseline --gyro-scale 1.14688
python data/odometry_tuning_2026-10-02/replay_experiments.py --variant vertical_bias_protected --gyro-scale 1.14688
python data/odometry_tuning_2026-10-02/replay_experiments.py --variant all_bias_protected --gyro-scale 1.14688
python data/odometry_tuning_2026-10-02/methods/planar_replay.py
python data/odometry_tuning_2026-10-02/score_experiments.py
```

Use the saved selection manifest for this comparison. Re-running the selection generator writes a new freeze timestamp; changing membership requires explicit versioning and comparison against the original set. The raw-stop interpolation in the audit is an offline diagnostic only; neither production replay nor the planar estimator uses future stop data.
