# data

분석 방법·결과와 재현 근거를 보관한다. `replay.py --plot`으로 만드는 그래프도
여기에 둔다. **이 폴더 전체가 삭제 가능한 캐시는 아니다.** `link_tests.csv`는
원본 측정이고, 보고서·manifest·선택 근거는 실험 이력이다.

| 항목 | 무엇 | 시작점 |
|---|---|---|
| `link_tests.csv` | `station/link_test.py`가 한 줄씩 덧붙이는 링크 실측 기록. **다시 만들 수 없다** | [docs/12](../docs/12_field_link.md) |
| `ax210_bench_2026-10-08/` | AX210 첫 실기 확인: 홈 Wi-Fi, 60초 영상 링크, 드라이버·펌웨어 식별과 GUI 화면 | [REPORT.md](ax210_bench_2026-10-08/REPORT.md) |
| `odometry_evaluation_2026-10-01/` | 2026-09-06 로그(이전 섀시)를 재생해 코드와 궤적을 점검 | [REPORT.md](odometry_evaluation_2026-10-01/REPORT.md) |
| `odometry_reference_review_2026-10-02/` | 로그 16개에서 여러 오도메트리 방법을 비교 | [README.md](odometry_reference_review_2026-10-02/README.md), 본문은 [docs/reviews](../docs/reviews/Odometry_Reference_Review_2026-10-02.md) |
| `odometry_tuning_2026-10-02/` | 2026-10-02 주행 10개 평가. 자이로 단위 환산(1.14688) 발견 | [REPORT.md](odometry_tuning_2026-10-02/REPORT.md) |
| `bmi088_stationary_2026-10-08/` | BMI088 60초 정지 측정: gyro bias/noise, 온도, host/sensor clock 비교 | [REPORT.md](bmi088_stationary_2026-10-08/REPORT.md) |

분석 폴더는 그 날짜의 증거로 보존한다. 스크립트가 `rover/`의 현재 코드와
config를 불러오는 경우, 같은 명령을 다시 실행해도 과거 결과와 같다는 보장은 없다.
기존 결과를 덮어쓰지 말고 입력·방법·코드/설정 식별자를 기록한 새 실험으로 비교한다.

새 근거가 같은 실험에 속하면 기존 보고서에 날짜와 근거를 추가한다. 서로 다른
조건이나 소스 버전의 평가라면 별도 실험으로 구분하고 이 목차에 한 번만 연결한다.
현재 실행할 일은 [로드맵](../docs/05_한계와_로드맵.md)에만 둔다.

샘플별 큰 출력(`*.npz`, `*_filtered.csv`, `*_nis.csv`)은 `.gitignore`로 제외된다.
**git 제외는 삭제 허가가 아니다.** 입력 로그, 생성기, 당시 코드·설정을 보존하고
재현을 확인한 파일만 정리한다. 원본 측정, 실측 라벨, 보고서, 선택 근거와 manifest는
보존한다. 과거 보고서의 PC 절대 경로는 이력으로 남지만 새 문서는 상대 링크를 쓴다.
