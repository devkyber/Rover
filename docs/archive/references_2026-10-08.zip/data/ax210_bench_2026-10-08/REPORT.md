# AX210 first hardware bench test — 2026-10-08

The installed AX210 associated with home Wi-Fi and passed a 60-second camera
link screen. The station also displayed a visible live image. The Wi-Fi
driver/firmware integration succeeded on the existing JetPack 6.2.1 installation;
no JetPack upgrade or replacement of the shared Wi-Fi modules was required.
This establishes basic 5 GHz operation with the built driver; it does not establish 10 m reliability
or superiority to the stock RTL8822CE. Current qualification work belongs to
[FIELD-02](../../docs/05_한계와_로드맵.md#field-02) and
[FIELD-01](../../docs/05_한계와_로드맵.md#field-01).

## Configuration and identity

| Item | Observed configuration |
|---|---|
| Target | Jetson, L4T R36.4.4, kernel `5.15.148-tegra` |
| Card | Intel AX210, PCI `8086:2725`, subsystem `8086:0024`; `iwlwifi` active |
| Firmware | `66.f1c864e0.0 ty-a0-gf-a0-66.ucode`; PNVM `0xe28bb9d7` |
| Network | Home SSID `poweron`; both laptop and Jetson wireless; AX3000Q absent from this path |
| Addresses | Jetson `192.168.50.57`, laptop `192.168.50.181`; DHCP |
| Radio | Channel 36 / 80 MHz, HE (Wi-Fi 6), two spatial streams; power saving off |
| Camera | USB `0c45:6366`, Microdia Webcam Vitade AF identity; 1920 × 1080 H.264 |
| Geometry | Distance, orientation, obstructions and installed antenna assembly not confirmed |
| Actuators/sensors | Motors disabled, Pico disabled, synthetic IMU; no drive commands sent |

[Preflight](preflight.json) retains boot ID, PCI, module/firmware SHA256s and
deployed Python file hashes. Local Git HEAD was
`a2fb41b7607493ac9d789dca9b970f7d90e6bab4` with a dirty working tree; the deployed
Jetson directory had no `.git`. That commit alone does not identify the tested
code. The preflight USB listing preceded camera attachment.

## Method

Started the existing deployed runtime from `/home/taeholee/Rover/rover`:

```bash
/home/taeholee/rover-venv/bin/python -u rover_main.py --no-motors --imu fake --pico off --no-log
```

[Runtime metadata](runtime.json) records its PID, exact command and output path.
On the laptop, with no station browser client connected during the measurement:

```bash
python station/link_test.py 192.168.50.57 --seconds 60 --label "AX210 first hardware test; home Wi-Fi both endpoints wireless; ch36 80MHz; distance and antenna assembly unconfirmed; camera-only"
```

The [raw CSV](../link_tests.csv) row is timestamped `2026-10-08 01:30:51` KST;
[stdout](link_60s.txt) retains the progress samples and summary. An earlier
[idle ICMP run](icmp_idle.json) retained 100 samples, using Windows .NET Ping
with a 1 s timeout and 200 ms pause between requests.

## Results

| Metric | 60-second video run |
|---|---:|
| Received video | 30.4 fps / 10.0 Mbit/s |
| Video arrival gap, p99 / maximum | 63.1 / 72.7 ms |
| Application ping, median / p99 / maximum | 3.3 / 40.6 / 45.8 ms |
| Unanswered application pings | 0 of 299 |
| Reconnects | 0 |
| Telemetry | 20.0 Hz |
| Telemetry gap, p99 / maximum | 69.3 / 90.5 ms |
| Rover RSSI, median / weakest | −48 / −49 dBm |

The idle ICMP run received 100/100 replies: minimum 2 ms, mean 3.73 ms,
maximum 19 ms. ICMP and application ping are different measurements.

After the test, the GUI was opened with:

```bash
python -u station/station.py --rover 192.168.50.57 --port 8766 --no-browser
```

The page at `http://localhost:8766/?rover=192.168.50.57` showed CONNECTED,
live camera video, MOTORS OFF, IMU FAKE and SERVOS OFF.
Port 8766 was used because an unrelated local server occupied 8765.
[The retained screenshot](station_live.png) documents the visible image;
its instantaneous rates are not the 60-second averages.

## Interpretation and limitations

The [postflight record](postflight.json), captured at 01:37 KST on the same boot,
showed continued Wi-Fi association and camera streaming. The filtered kernel log
contained no Intel firmware crash/reset. It did contain the boot warning
`api flags index 2 larger than supported by driver` and the unsigned-module
verification warning. These did not prevent this run.

USB IPv6 SSH worked when discovering the new DHCP address, but later kernel
messages again showed USB NCM `Wrong NTH SIGN`. This is evidence of an unresolved
USB recovery issue; this experiment does not identify its cause. Early kernel
wall-clock dates changed during startup, so use the retained boot ID and
preflight monotonic timestamps when interpreting the boot sequence.

The older home-network stock-card run recorded 29.9 fps, a 53 ms maximum video
gap and 3.6 / 13.3 ms median / maximum ping. Those positions and background
conditions were not controlled against this run. The current result therefore
does not show that AX210 is faster or more reliable. Frame-arrival gaps are not
camera-to-screen latency, and application ping is not drive-command timing.
One boot and 60 seconds cannot qualify reconnect recovery, long-duration use,
the AX3000Q path, antenna placement or the required obstructed 10 m link.
The test also did not exercise 2.4 GHz, 6 GHz or Bluetooth; USB enumeration of
the AX210 Bluetooth device is not a Bluetooth functional test.

## Subsequent AX3000Q association, 2026-10-08

On the owner's request, activated the existing `rover-field` profile through
USB IPv6 SSH. [Association evidence](field_association.json) records `rover-5G`,
`192.168.0.200/24`, channel 36 and a 160 MHz HE transmit rate. The initial RSSI
was −26 dBm. Three Jetson-to-router pings all returned, with 0.842 ms average RTT.
A temporary return-home timer was cancelled after association and USB access were
verified. The laptop remained on home Wi-Fi without its router Ethernet adapter;
the station could not yet be reconnected through the field router. This is an
association/router-reachability check, separate from the home-network video run
above. It does not qualify field video, range or recovery.

**02:01 KST follow-up:** the owner moved the laptop cable from WAN to a numbered
LAN port. Windows Ethernet 7 then obtained `192.168.0.100/24`, and SSH to
`192.168.0.200` succeeded over that path. The router login page at `192.168.0.1`
opened. The station was retargeted to `.200` and displayed live video and telemetry;
[the screenshot](station_ax3000q.png) shows 30 fps, 20 Hz telemetry and a 1 ms
instantaneous link reading. These are GUI observations, not a timed link-screen
result. The same camera-only process remained active with motors disabled and a
fake IMU. This clears the laptop cabling blocker; sustained field-router video,
range and recovery qualification still require the protocol measurements.
