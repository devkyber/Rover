**Rover code and actual-log odometry evaluation — 2026-10-01 (KST)**

The current desktop estimator and replay pipeline execute successfully on the
compatible recordings. The existing test suites pass. This does not establish
live hardware reliability: no serial devices are connected, and reproducible
motor transport, cleanup, IMU validity, and disabled-ZUPT defects remain.
The measured straight runs reveal distance overestimation, including one
checkpoint outside the experiment's 5 cm tolerance. Real turn accuracy is
still unmeasured.

Production code, configuration, original CSVs, and experiment metadata were
left unchanged. All additions are derived artifacts in this directory.
The user's existing README and PDB documentation changes were preserved.

**Fresh software checks**

| Check | Result | Evidence |
|---|---|---|
| Application Python parsing/compilation | 27/27 files | `code_checks.json` |
| Rover module imports | 19/19 modules | `code_checks.json` |
| Filter math and structural checks | 11/11 passed | `filter_tests.txt` |
| Filter scenarios | 10/10 passed; trajectory cases use ten seeds | `filter_tests.txt` |
| Five-second fake acquisition/log/replay audit | 10/10 passed; 500 samples, 100.0 Hz, jitter SD 0.26 ms, CSV round-trip max difference 5.00e-7 | `pipeline_tests.txt` |
| Motor decoding with fakes | Negative signed current, velocity and position decoded correctly; failed/missing reads rejected | `code_checks.json` |
| Replay Flask routes | Page, log listing, invalid path handling, actual 2,000-row stationary replay, trace retrieval, invalid trace index | `code_checks.json` |
| Running replay server, actual 23:47 recording | 21,479 sensor samples; six checkpoints match; API result agrees with independent replay within display rounding | `gui_2347_verification.json` |

Synthetic scenario passes must be read with their limits: the 10% slip case
still has a worst distance error of 0.302 m; the initially unaligned biased-gyro
case without stops allows 42 degrees and produces a worst yaw error of 40.58
degrees. These passes record expected limitations. They do not demonstrate
accurate real driving under slip or without gyro calibration. Jetson scripts
were parsed/compiled, not executed against cameras or JetPack.

**How the actual trajectories were evaluated**

Six existing sensor CSVs were replayed, totaling 64,333 samples. Inputs pass
through `logger.replay()`, which applies the old Arduino sensor-to-body
rotation exactly once. The production `replay.run()` supplies the current
`Odometry.step()` and its original timestamp/fallback policy. The current
five-second stationary startup alignment and all Q, R and geometry settings
were retained.

Reported position is the production wheel/inertial output:

`p[k+1] = p[k] + R(q_ESKF) [mean signed wheel speed, 0, 0] dt`.

It is not the internal ESKF position. Both are exported separately. Read-only
instrumentation collected NIS after production steps and sampled covariance
eigenvalues at 1 Hz. Against the first, uninstrumented replay of all five
aligned recordings, final reported position and yaw differences were exactly
zero. Every output sample was checked for finite position/orientation. The
sampled covariances remained positive and final symmetry errors were below
1.9e-16; this is numerical stability evidence, not proof of calibrated
uncertainty. Source and input SHA-256 values and the evaluated configuration
are recorded in `metrics.json`.

Measured stops were matched using the existing GUI convention: moving
segments separated by at least one second of stopping, excluding displacements
under 5 cm. Each measured run contains one small unmeasured nudge. Four
substantial legs match the 23:34 measurements and six match 23:47.

**Measured straight-run results**

| Recording | Measured route | Maximum longitudinal checkpoint error | Checkpoint x RMSE | Final estimated XY distance from origin | Estimated maximum lateral excursion | Final relative yaw estimate |
|---|---|---:|---:|---:|---:|---:|
| 23:34 | Approximately 1.20 m out/back, twice | 3.98 cm | 2.67 cm | 1.59 cm | 1.18 cm | +0.982 degrees |
| 23:47 | 0.50 m stops to 1.50 m, then reverse return | 5.39 cm | 3.06 cm | 1.14 cm | 0.426 cm | +0.062 degrees |

23:34 meets the metadata's 5 cm longitudinal checkpoint tolerance. 23:47
exceeds it by 3.93 mm at the 1.50 m stop: the reported longitudinal position
is 1.55393 m, a +3.60% error. Five of that run's six checkpoints are within
the tolerance. The small final residual must not conceal this outbound
distance error.

| 23:47 checkpoint | Log time [s] | Measured x [m] | Estimated x [m] | x error [cm] |
|---|---:|---:|---:|---:|
| 1 | 25.588 | 0.500 | 0.507868 | +0.787 |
| 2 | 47.908 | 1.000 | 1.036864 | +3.686 |
| 3 | 76.080 | 1.500 | 1.553928 | +5.393 |
| 4 | 104.710 | 1.000 | 1.030436 | +3.044 |
| 5 | 121.782 | 0.500 | 0.518748 | +1.875 |
| 6 | 138.724 | 0.000 | 0.001302 | +0.130 |

At checkpoint 6 the estimated XY distance from origin is 0.283 cm. The
end-of-file distance is 1.14 cm after the small later nudge, so these are
different evaluation instants. The stop/leg convention also includes tiny
sample-scale timing offsets; the complete filtered CSV preserves every
sample for inspection.

All ten substantial leg lengths are overestimated. Average leg scale is
1.02459 for 23:34 and 1.03529 for 23:47, corresponding to roughly 2.5% and
3.5% distance overestimation. That supports investigating the effective wheel
scale and wheel-to-ground model. The data do not isolate radius error from
slip, floor/load effects or other model error. Increasing wheel measurement
R does not directly remove the encoder distance from this reported pose.
Forward and reverse distance errors can partly cancel at the final return.

Only longitudinal positions at stops were tape measured. Lateral values and
yaw in the table are estimates, not measured error. Treating y=0 as a
reference assumes the rover followed a straight baseline. No continuous XY,
height or heading truth exists. Both measured recordings were previously
used for tuning; these are re-evaluation results, not independent holdout
validation.

**Other recordings and filter consistency**

| Recording | Result |
|---|---|
| Four-wheel stationary, 20 s | Alignment at 7.42 s; reported translation stays exactly zero because the wheels are stationary; final relative yaw +0.0626 degrees. Internal ESKF drift norm is about 0.3 mm. Zero reported translation alone is not evidence of IMU position accuracy. |
| 23:29 driving, 117.52 s | Alignment at 7.27 s; final reported XY is [0.05093, -0.00266] m. Thirteen moving samples occur before alignment and are not integrated. No measured route/closure is established in the metadata. |
| 23:51 free driving with rotation, 91.57 s | Alignment at 5.22 s; reported endpoint [0.87583, 0.15007] m, path about 6.26 m, final relative yaw -14.884 degrees. No independent endpoint or angle measurement, so the endpoint distance and yaw cannot be called errors. |
| 23:23 earlier driving, 46.45 s | Alignment never completes. Motion begins at 0.961 s and the longest continuously detected stationary interval is 3.774 s, below the required 5 s. Every reported pose remains zero and no filter innovations are produced. This old recording is incompatible with the current startup requirement; its frozen path is not successful odometry. |

The stationary log's current NIS means are ZUPT 1.50, ZARU 1.68 and gravity
0.453, each compared with a dimension of 3. Historical README tuning numbers
do not describe this current aligned replay.

The 23:51 run has mean gravity NIS **10.05/3** and ZUPT **31.27/3**, above the
CLI's heuristic mean/dimension >3 band. Mean wheel NIS is 1.19/1, NHC
1.56/2 and ZARU 0.955/3. The gravity 95th percentile is 36.08 and the ZUPT
95th percentile is 172.28; these are not just one isolated extreme. On
23:47, wheel NIS 0.064/1 and ZARU 0.0837/3 are very low. These findings
show that current uncertainty/model assumptions are not consistently
matched across stationary, straight and dynamic conditions. Noise parameters
still use BMI088 values while the recordings came from an LSM6DS3, and bias
random-walk values remain placeholders. NIS mismatch does not by itself
identify which Q/R value or physical assumption should change.

Airborne wheel-spin recordings were excluded from ground-distance evaluation:
their wheel speeds do not represent vehicle motion. The historical two-wheel
stationary CSV does not match the current four-wheel loader. `rover/run3.csv`
has no experiment metadata establishing floor contact, route or measurements
and was excluded from the accuracy claims.

**Behavior defects confirmed without hardware**

These are current defects, not fixed tests. Reproductions are in
`check_current_code.py`, with results in `code_checks.json`.

| Defect | Observed behavior | Production source |
|---|---|---|
| Failed motor transmission hidden by `drive()` | Fake writer returns a failed transmission; `write_velocities()` returns False, but `drive()` still returns [27, -27, 27, -27] without surfacing failure. | `rover/dxl_control.py`, `drive()` |
| Torque cleanup stops at the first failed motor | A failed torque-disable write for ID 1 raises; IDs 2–4 receive no attempts. | `rover/dxl_control.py`, `set_torque()`/`stop()` |
| Disabled ZUPT still clamps public translation | With `use_zupt=False`, zero ZUPT updates occur but `zupt_active` becomes True. A small 0.01 rad/s wheel rate integrates only 0.000175 m instead of 0.000625 m. | `rover/odometry.py`, `zupt_active` and public output |
| IMU accepts nonfinite readings | `_parse()` accepts a CSV line containing `nan` and returns nonfinite acceleration. | `rover/imu_reader.py`, `_parse()` |
| Old IMU sample receives a new host timestamp | On an empty stream, `read()` returns the previous device timestamp/readings with a fresh host timestamp. The driver records staleness, but the estimator receives the old reading as another cycle. | `rover/imu_reader.py`, `read()` |

Source inspection also confirms that teleop motor setup/torque enable,
logger acquisition and Pygame setup precede its cleanup `try/finally`.
Failure during those stages can bypass the intended cleanup. Its IMU read
also precedes the motor write and can block on the serial timeout. These
paths require focused failure-handling checks before relying on live control.
The BMI088 hardware driver is explicitly not implemented.

**Files and reproducibility**

Every recording has a `*_filtered.csv`, `*_metrics.json`, and trajectory PNG.
Aligned recordings additionally have `*_nis.csv` and NIS plots. The empty
23:23 NIS export and zero trajectory are marked incomplete in the metrics.
`metrics.json` collects all results and source/input hashes.

From the repository root:

```powershell
python rover/test_filter.py
python rover/test_pipeline.py --fake --seconds 5 --log data/odometry_evaluation_2026-10-01/new_fake_audit.csv --keep
python data/odometry_evaluation_2026-10-01/check_current_code.py
python data/odometry_evaluation_2026-10-01/evaluate_actual_logs.py
python rover/replay_gui.py logs/2026-09-06_2347_drive.csv --no-browser
```

The replay server started for this evaluation is available at
http://127.0.0.1:5001 and opens only recorded data. Stop that process before
starting another server on the same port. Re-running the artifact scripts
replaces the derived outputs in this directory, using whatever source and
configuration are present at that time.

The next accuracy validation should use fresh, independent measured distances
and independently measured turn angles or a measured square course. The
confirmed driver and ZUPT issues need targeted fixes separately from estimator
calibration. No physical motor/IMU or real turn validation was performed here.
