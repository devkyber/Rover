# BMI088 stationary bench measurement — 2026-10-08

The owner confirmed the board was stationary. The capture ran from approximately
01:10:55 to 01:11:55 KST, with motors left off. **6,001 samples cover 60 seconds.**
Chip IDs and configuration remained valid; all periodic accel error checks were
zero, and no sampled axis reached the near-full-scale threshold.

This is a short stationary baseline. It does not validate turning accuracy,
long-duration drift, operation under motor vibration or temperature compensation.
No calibration constants were installed in the rover runtime.

## Evidence and reproduction

- [Raw capture](../../logs/2026-10-08_011054_bmi088_stationary.json): integer sensor
  data, host read timestamps, accel sensor-time ticks, periodic temperatures and
  health checks, configuration writes/readbacks, capture source and source hash.
- [Analysis](analyze.py): verifies hashes, decoding, configuration and health;
  scales the raw data and computes the statistics and time-split check below.
- [Machine-readable results](summary.json): input/source/analysis hashes, exact
  results and Python/NumPy/Matplotlib versions.
- [Figure](stationary.png): rate stability, acceleration magnitude, temperature,
  withheld-segment residual angle and relative clock drift.

Run from the repository root:

```bash
python data/bmi088_stationary_2026-10-08/analyze.py
```

The analysis uses only this capture and its recorded configuration; it does not
import current rover filter/calibration defaults. Regenerated outputs belong to
this same experiment. Preserve the raw input and method before revising them.

## Configuration and gyro estimate

Mode 3 SPI, requested 1 MHz (wire clock not measured). Accel range +/-6 g,
400 Hz output, normal bandwidth; gyro range +/-500 deg/s, 400 Hz output and
47 Hz bandwidth. Host polling was approximately 100 Hz. Equal sensor output
rates do not establish hardware synchronization.

All axes below are **sensor axes**, with no sensor-to-body rotation applied.
The full-record means estimate offsets under the owner's stationary condition;
subtract a measured mean to compensate a rate in the same frame and units.

| Sensor axis | Mean rate (deg/s) | Mean rate (rad/s) | Sample standard deviation (deg/s) |
|---|---:|---:|---:|
| X | +0.1592625 | +0.002779655 | 0.089705 |
| Y | +0.0532163 | +0.000928800 | 0.137625 |
| Z | +0.0314914 | +0.000549629 | 0.096774 |

Ten-second mean rates stayed within X 0.15617–0.16225, Y 0.04965–0.05702,
and Z 0.02902–0.03452 deg/s. These are sample standard deviations at this
bandwidth/polling arrangement, not noise-density or Allan-deviation estimates.
Do not install them directly as ESKF noise densities or reuse the Arduino's
gyro scale factor. Temperature ranged from 22.875 to 23.250 degC; this narrow
range does not identify a useful bias-versus-temperature model.

## Withheld time segment

The first 3,000 samples estimated bias `[0.15882365, 0.05268860, 0.03159587]`
deg/s. That estimate was subtracted from the remaining 3,001 samples spanning
30.00007 s. Trapezoidal integration used the **gyro host read midpoint times**.
The full-record mean in the table was not used for this test.

Residual integrals in sensor X/Y/Z were `[+0.02622, +0.03358, -0.00754]` deg.
A fixed approximate up direction was estimated from the training accelerometer
mean: `[+0.08431, -0.02887, -0.99602]`. Projecting the residual integral onto
that direction gives **+0.00875 deg at the end**, with maximum absolute value
**0.06290 deg** during the second half.

This is a stationary diagnostic using a withheld portion of the same recording.
It is neither an independent recording nor an externally measured yaw trial.
It does not establish a 0.009-degree turning accuracy. Sensor Z is nearly
opposite the estimated up direction in this pose; do not label sensor `gz`
as rover yaw rate before establishing the mounting transform.

## Timing and accelerometer observations

- Gyro host intervals: median 9.9997 ms, 99th percentile 10.6933 ms, maximum
  11.7713 ms; none exceeded 15 ms. There were no zero accel sensor-time steps.
  Polling at 100 Hz still intentionally omits intermediate 400 Hz sensor updates.
- Accel sensor ticks advanced by **60.6330 nominal seconds during 60.0000 host
  seconds**. An affine fit gives 1.01054654 nominal sensor seconds per host
  second (**+1.05465%**) and residual standard deviation 384.85 us. This relative
  clock measurement must be accounted for when mapping sensor time to host time;
  the nominal tick duration is not a verified gyro integration clock. Do not
  turn this single-run estimate into a permanent gyro scale correction.
- Mean acceleration vector was `[+0.81514, -0.27938, -9.59671]` m/s^2. Mean
  magnitude was **9.63539 m/s^2**, with standard deviation 0.02500 m/s^2,
  about **1.75% below standard gravity**. A single orientation cannot separate
  axis offsets from scale error; a multiple-orientation calibration is needed
  before correcting those terms.

Runtime integration and measured-turn validation remain owned by
[IMU-01](../../docs/05_한계와_로드맵.md#imu-01); implementation principles are in
[the yaw guide](../../docs/09_turn_angle_lesson.md#8-bmi088-yaw--implementation-and-validation-path).

![Stationary measurement plots](stationary.png)
