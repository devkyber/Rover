# Offline odometry comparison — 2026-10-02

[Full research review and hardware recommendation](../../docs/reviews/Odometry_Reference_Review_2026-10-02.md)

Fresh production replay plus explicit kinematic baselines on 16 recordings, 222,897 unique samples. Only two September recordings have independent longitudinal checkpoint distances (ten stops total); no continuous XY, heading, or height truth is available. These two recordings were previously used for tuning.

| File | Contents |
|---|---|
| [compare_odometry.py](compare_odometry.py) | Offline experiment, shared readiness/stillness, integration sanity checks, immutable-input hash checks. |
| [manifest.json](manifest.json) | Source/input/script hashes, software versions, geometry, diagnostics, limitations. |
| [verification.json](verification.json) | Recomputed trajectory/checkpoint statistics and final integrity/link checks. |
| [summary.csv](summary.csv) | Per-run/per-method metrics. |
| [checkpoints.csv](checkpoints.csv) | 70 method/checkpoint rows. Error is longitudinal x only. |
| [gyro_relative_turn_widths.csv](gyro_relative_turn_widths.csv) | Turn parameters fitted against gyro, not independent angle truth. |
| [comparison.png](comparison.png) | Tape-checkpoint errors and selected gyro-relative track widths. |
| [turn_disagreement.png](turn_disagreement.png) | Free-drive trajectory/heading disagreement without fabricated ground truth. |
| `*.npz` | Time, readiness, production and causal gyro bias, and each method's XY/yaw trajectories. |

From `C:\Users\tae06\CODE\Rover`:

```powershell
python data/odometry_reference_review_2026-10-02/compare_odometry.py
```

Requires the existing rover dependencies, NumPy, and Matplotlib. No devices are opened; only this result directory is written. A repeat uses the source/config present at that time, so compare hashes when reproducing old results.

Important interpretation:

- September radius/track (0.0625/0.485 m) are prior evaluation assumptions, not physical dimensions recorded in the logs. October uses current config (0.055/0.1585 m).
- The 1.14688 gyro-scale variant is a unit-conversion sensitivity experiment. It is not a correction validated by independently measured turns.
- Effective-track leave-one-recording-out fitting excludes the evaluated October recording, but learns against the same gyro sensor type; it is a sensor-consistency comparison.
- Planar baselines do not preserve full 3D slope motion. All methods share the production startup/stop masks and time policy.
- RTAB-Map, ORB-SLAM3, OpenVINS, VINS, robot_localization, and LiDAR SLAM were not executed on these wheel/IMU-only recordings.
- No production changes, original CSV edits, firmware updates, or hardware purchases were made.
