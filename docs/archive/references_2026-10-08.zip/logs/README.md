# 로그

`rover/rover_main.py --log <파일>` 또는 `rover/record.py --log <파일>`이 남긴 CSV.
포맷과 컬럼 정의는 [`rover/logger.py`](../rover/logger.py), 해석 방법은
[`docs/03_튜닝과_NIS.md`](../docs/03_튜닝과_NIS.md).

자동 이름 규칙: `YYYY-MM-DD_HHMM_<태그>.csv`. 초기 수동 이름 로그는
`YYYY-MM-DD_<구성>_<상황>.csv` 형태도 남아 있다.

SPI 통신 진단 원본: [`2026-10-07_spi_loopback.json`](2026-10-07_spi_loopback.json).
BMI088을 분리하고 Jetson 물리 핀 19–21을 연결한 외부 loopback의 TX/RX와
시험 코드 SHA-256을 보존한다. 센서 측정 로그가 아니며 CS 파형은 검증하지
않았다. 구성과 해석은 [Jetson 시험 기록](../docs/11_jetson_bringup.md#62-physical-loopback-result)에 있다.
당시 해시와 일치하는 [시험 소스](2026-10-07_spi_loopback.source.py)도 보존한다.

재배선 후 유효한 ID 재시험은
[`2026-10-08_bmi088_fresh_buffer_probe.json`](2026-10-08_bmi088_fresh_buffer_probe.json)에 있다.
TX/RX, BPMP clock, 설정 복원 결과, 실행 소스와 SHA-256을 포함한다.
앞선 [`corrected_wiring_probe`](2026-10-07_bmi088_corrected_wiring_probe.json)와
[`clock_parent_probe`](2026-10-08_bmi088_clock_parent_probe.json)는 TX 버퍼를 재사용한
오류가 있어 반복 ID 읽기 결과로 쓰지 않는다. 원본은 보존하며 해석은
[재시험 기록](../docs/11_jetson_bringup.md#63-corrected-wiring-retest-2026-10-08)을 따른다.

같은 날 00:26–00:30 KST 재시도는
[일반 ID 읽기](2026-10-08_002601_bmi088_id_probe.json),
[낮은 clock 읽기](2026-10-08_002657_bmi088_slow_id_probe.json),
[전송 방식 비교](2026-10-08_003000_bmi088_transfer_probe.json)에 보존했다.
실행 소스와 해시를 포함하며, 소유자가 전원/모드 전압이 예상값이라고 보고한
시점의 통신 진단이다. 가속도·자이로 측정이나 yaw 검증 데이터는 아니다.

JP1 저전압 보고 후 요청한 [00:46 KST 재시험](2026-10-08_004653_bmi088_id_probe.json)은
두 chip 모두 80회 중 유효 ID 0회, 반환 ID는 전부 `0x00`이었다.
당시 JP1 전압 재측정이나 배선 변경 내용은 보고되지 않았다.

핀맵 수정 보고 전후의 00:50–00:55 KST 시험:
[ID 통과](2026-10-08_005002_bmi088_id_probe.json),
[초기화 중 중단](2026-10-08_005228_bmi088_live_probe.json),
[상태 레지스터 재확인](2026-10-08_005343_bmi088_health_probe.json),
[성공한 live capture](2026-10-08_005530_bmi088_live_probe.json).
마지막 파일은 100 Hz host polling으로 수집한 1,000개 raw accel/gyro와
sensor time, 설정, 실행 소스/해시를 포함한다. 회전율 변화가 커서 정지 bias
보정에 쓰지 않는다. [벤치 검증 범위](../docs/11_jetson_bringup.md#65-successful-live-bench-test-2026-10-08)를 따른다.

[01:10 KST 정지 측정](2026-10-08_011054_bmi088_stationary.json)은 소유자가 정지를
확인한 뒤 수집한 60초 / 6,001개 raw sample이다. 주기적 온도·ID·설정 확인과
실행 소스/해시를 포함한다. 첫 30초 bias로 뒤 30초를 평가했으며, 같은 기록의
시간 분할이므로 독립 회전 검증은 아니다. 분석은
[정지 실험 보고서](../data/bmi088_stationary_2026-10-08/REPORT.md)에 있다.

2026-10-08 BMI088 드라이버 통합 기록은 아래 세 쌍의 CSV/metadata다. 모터 없이
느슨하거나 기울어진 보드로 수집했으며, 주행·장착축·회전각 정답은 없다.
원시 counts, FIFO의 모든 gyro frame, host 간격, 온도, 설정/소스 snapshot을 보존한다.
시험 결과와 마지막 통신 실패의 해석은 [Jetson §6.7](../docs/11_jetson_bringup.md#67-runtime-driver-integration-2026-10-08)에 있다.

| 실행 | 원본 | 설정·소스 |
|---|---|---|
| Headless record | [01:35 CSV](2026-10-08_0135_bmi088_integration.csv) | [metadata](2026-10-08_0135_bmi088_integration.csv.meta.json) |
| Main program | [01:39 CSV](2026-10-08_0139_bmi088_main.csv) | [metadata](2026-10-08_0139_bmi088_main.csv.meta.json) |
| SPI burst 최적화 후 | [01:42 CSV](2026-10-08_0142_bmi088_main.csv) | [metadata](2026-10-08_0142_bmi088_main.csv.meta.json) |

[배포/console 기록](2026-10-08_bmi088_driver_deployment.json),
[최종 소스와 14개 테스트](2026-10-08_bmi088_driver_final_verification.json),
[ID 실패로 중단된 lock 시험](2026-10-08_bmi088_driver_lock.json),
[read-only SPI 설정 비교](2026-10-08_bmi088_spi_property_probe.json)를 함께 보존한다.
마지막 두 기록은 성공한 센서/lock 검증이 아니다.

| 파일 | 무엇 | 쓸모 |
|---|---|---|
| `2026-09-06_2wheel_still.csv` | 모터 2개, 20 s 정지 | ZUPT 임계값을 실측으로 잡은 최초 로그 |
| `2026-09-06_4wheel_still.csv` | 모터 4개, 20 s 정지 | **정지 R 튜닝 기준 로그.** 이동하지 않았다는 독립 조건 |
| `2026-09-06_4wheel_airborne.csv` | 4개, 405 s, 바퀴만 공중 회전 | 배선·타이밍·부호 검증용. **튜닝에는 쓸 수 없음** |
| `2026-09-06_4wheel_airborne2.csv` | 위와 같음 (재현) | 〃 |
| `2026-09-06_2323_drive.csv` | 첫 바닥 주행, 46 s | 시작 정지 구간이 3.8 s뿐이라 5 s 정렬이 끝나지 않는다. 현재 코드로는 궤적이 나오지 않음 |
| `2026-09-06_2329_drive.csv` | 직진·정지 | 바닥 주행 동작 확인. 거리 정답 없음 |
| `2026-09-06_2334_drive.csv` | 약 1.20 m 왕복 2회 | 줄자 체크포인트 비교 |
| `2026-09-06_2347_drive.csv` | 0.50 m 간격으로 1.50 m까지 정지 후 복귀 | **6개 줄자 구간 검증** |
| `2026-09-06_2351_drive.csv` | 회전을 포함한 자유 주행 | 회전 동작/NIS 확인. 위치 정답 없음 |

### 2026-10-02 주행 (10개)

외부 위치 정답은 없다. 코너는 조종자가 대략 90°로 돌았다는 것만 안다. 로그별 판정 근거와
구간 선택은 [`data/odometry_tuning_2026-10-02/REPORT.md`](../data/odometry_tuning_2026-10-02/REPORT.md).

| 파일 | 무엇 | 쓸모 |
|---|---|---|
| `2026-10-02_0156_drive.csv` | 여러 기동이 섞인 주행 | 진단용 재생 |
| `2026-10-02_0158_drive.csv` | 회전 방향이 섞인 주행 | 탐색용. 300.6 s에 가속도 포화 샘플 1개 |
| `2026-10-02_0204_drive.csv` | 처음부터 끝까지 정지 | **짧은 정지 기준 로그** |
| `2026-10-02_0204_drive-2.csv` | 거의 정지, 짧은 이동 1회 | 바이어스·노이즈 확인 |
| `2026-10-02_0205_drive.csv` | 직진·코너 반복 | **회전 평가의 맞춤 구간** (코너 9개) |
| `2026-10-02_0209_drive.csv` | 방향이 섞이고 코너 중 전진 | 진단용 |
| `2026-10-02_0213_drive.csv` | 긴 혼합 주행 | 진단용. 385.3 s에 가속도 포화 샘플 1개 |
| `2026-10-02_0223_drive.csv` | 코너 3개 | **회전 평가의 검증 구간** (맞춤에 쓰지 않음) |
| `2026-10-02_0224_drive.csv` | 코너 3개 | 〃 |
| `2026-10-02_0227_drive.csv` | 44–47 s에 좌우 바퀴 차는 있는데 자이로 회전이 없음 | 슬립 또는 접지 상실 의심. 직각 라벨 없음 |

## 로그에는 로버 치수가 들어 있지 않다

재생은 항상 **지금의** `config.WHEEL_RADIUS_M` / `WHEELBASE_M`를 쓴다. 그 사이 섀시가 바뀌었다.
새 BMI088 metadata에는 당시 `config.py` snapshot이 있지만, 재생 시 자동 적용하지는 않는다.

| 로그 | 바퀴 반지름 | 좌우 간격 |
|---|---|---|
| 2026-09-06 | 0.0625 m | 0.485 m |
| 2026-10-02 이후 (현재 config) | 0.055 m | 0.1585 m |

9월 로그를 현재 config로 재생하면 거리가 0.055 / 0.0625 = 0.88배로 짧게 나온다.
9월 로그를 다시 평가할 때는 `config.py`의 두 값을 위 표의 값으로 바꿔서 돌릴 것.

## 정지 로그가 특별한 이유

출발점 = 도착점이므로 **최종 위치가 곧 드리프트**다. 정답(ground truth)을
공짜로 얻는 유일한 상황이라, R 튜닝의 기준으로 쓴다.

```bash
python rover/replay.py logs/2026-09-06_4wheel_still.csv
```

## 공중 회전 로그를 튜닝에 쓸 수 없는 이유

바퀴 속도 관측은 "바퀴가 돌면 로버가 간다"를 가정한다. 공중에서는 그
가정이 거짓이므로 `wheel`·`nhc`의 NIS는 숫자가 예뻐도 의미가 없다.
`R_WHEEL_VELOCITY` 평가는 **바닥에 내려놓고 실제로 굴린 로그**를 사용한다.
이미 있는 직진 줄자 기록의 범위는 아래와 같고, 새 검증은 [ODOM-03](../docs/05_한계와_로드맵.md#odom-03)에 있다.

## 줄자 정답의 범위

`2334`, `2347`에서 실제로 측정한 것은 **정지점의 종방향 거리**다. 정지점 사이
매 순간의 위치와 횡방향 위치는 외부 추적기로 측정하지 않았다. 따라서
`replay_gui.py`는 다음만 정답으로 취급한다.

- 줄자로 표시한 종방향 체크포인트
- 직진 기준선 `y=0` (로버 중심을 선 위로 주행했다는 가정)
- 체크포인트에 도착한 시각은 1초 이상 정지로 구분된 이동 구간의 끝

연속적인 실제 궤적은 이 로그만으로 복원할 수 없다. 모션캡처, 상부 카메라의
AprilTag 추적, 측량기 같은 **외부 위치 기준**이 있어야 한다.

새 시험의 기준점은 [`experiments.json`](experiments.json)에 기록한다.
`checkpoints_m`은 출발점을 포함해 각 장시간 정지점의 실제 `[x, y]`를 순서대로
쓴다. 예를 들어 1 m 정사각형은 다음과 같다.

```json
"ground_truth": {
  "label": "1 m square",
  "checkpoints_m": [[0, 0], [1, 0], [1, 1], [0, 1], [0, 0]],
  "tolerance_m": 0.05
}
```

각 변 끝에서 1초 이상 멈춰야 GUI가 체크포인트와 이동 구간을 자동 매칭한다.

## IMU 좌표계와 구형 로그

2026-09-11 이후 CSV에는 `imu_frame=body` 열이 있다. Arduino 드라이버가
`[x_body,y_body,z_body]=[-y_sensor,+x_sensor,+z_sensor]` 회전을 적용한 뒤 기록한다.
그 이전 로그에는 이 열이 없고 sensor frame 원시축이 들어 있다. 원본 파일은
수정하지 않고 `logger.replay()`가 구형 형식을 감지해 같은 회전을 한 번 적용한다.

따라서 CSV의 `ax,ay,az`를 직접 ESKF에 넣지 말고 반드시 `logger.replay()`를
사용한다. `replay_gui.py` 상단에는 구형 변환 적용 여부가 표시된다.

BMI088는 별도의 `BMI088_IMU_TO_BODY` 회전을 적용하고 `imu_source=bmi088`로
기록한다. `gyro_samples`의 모든 값을 `imu_dt / frame 수` 간격으로 예측에 넣는다.
`imu_t`는 별도 accel clock이므로 gyro 적분 시간으로 사용하지 않는다.

## 새 실험을 추가할 때

원본 CSV를 보존하고 이 목록에 구성·목적·정답 범위를 한 번 기록한다.
실측 기준점은 `experiments.json`에 추가한다. 아직 자동 기록되지 않는 치수,
센서/펌웨어, 보정·코드 버전은 실험 설명에 명시한다. 자동화 작업은
[ODOM-02](../docs/05_한계와_로드맵.md#odom-02), 다음 검증 실험은
[ODOM-03](../docs/05_한계와_로드맵.md#odom-03)에서 관리한다.
