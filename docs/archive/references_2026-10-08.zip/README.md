# Rover — KSRC 2026 달 탐사 로버

4륜 스키드스티어 모함의 소프트웨어다. Jetson 로버 프로그램, 조종 노트북의
스테이션, Pico/Arduino 펌웨어, 엔코더 + IMU 오도메트리와 분석 도구를 함께 관리한다.

**현재 상태와 남은 일은 [05 — 로드맵](docs/05_한계와_로드맵.md) 한 곳에서 갱신한다.**
구현 여부, 시뮬레이션 통과, 실기 검증을 구분하고 각 작업에 근거와 완료 기준을 남긴다.
문서를 고치거나 기능을 추가할 때는 [AGENTS.md](AGENTS.md)의 유지 규칙을 따른다.

## 저장소 지도

```text
rover/      Jetson 프로그램, 위치 추정, 센서 입출력, 기록·재생·시험
station/    조종 노트북의 브라우저 화면과 링크 측정 도구
firmware/   pico/ (서보·배터리), imu_stream/ (임시 Arduino IMU)
jetson/     설치 스크립트, udev 규칙, 영상·링크 진단 도구
logs/       원본 주행 기록과 experiments.json의 실측 기준점
data/       분석 방법·결과·재현 정보, link_tests.csv의 원본 링크 측정
docs/       현재 안내서, 날짜가 붙은 검토 기록, 구형 설계 자료
tools/      문서 구조와 링크 검사
```

`logs/`와 `data/`를 통째로 지우지 않는다. 재생 그래프 같은 생성물도 당시 코드와
설정이 없으면 같은 결과로 재현되지 않는다. 보존 범위는 [data/README](data/README.md),
기록별 치수·정답 범위는 [logs/README](logs/README.md)를 본다.

## 코드의 시작점

| 역할 | 파일 |
|---|---|
| 실행·설정 | [`rover_main.py`](rover/rover_main.py), [`config.py`](rover/config.py) |
| 모터·링크·영상·Pico | `motors.py`, `station_link.py`, `websocket.py`, `camera.py`, `pico_link.py` |
| 위치 추정 | `odometry.py`, `eskf.py` |
| 센서·모터 입출력 | `imu_reader.py`, `dxl_reader.py`, `dxl_control.py`, `sdk_path.py`, `vendor/` |
| 기록·분석 | `logger.py`, `record.py`, `replay.py`, `replay_gui.py`, `analyze_drive.py` |
| 시험·학습 | `test_filter.py`, `test_pipeline.py`, `sim.py`, `dxl_tool.py`, `learn_turn_angle.py` |

파일별 설명은 [02 — 코드 해설](docs/02_구현_코드해설.md), 영어 학습 경로는
[08 — learning guide](docs/08_learning_guide.md)에 있다. 같은 필터를 실시간,
재생, 시뮬레이션에서 재사용한다.

## 실행

저장소 최상위에서, 하드웨어 없이:

```bash
python rover/test_filter.py
python rover/test_pipeline.py --fake --seconds 5
python firmware/pico/test_firmware.py
python -m unittest station.test_link_test
python tools/check_docs.py
```

기록을 보고 싶으면 `python rover/replay_gui.py`.
실제 로버 실행은 [04 — 실행 가이드](docs/04_실행_가이드.md)를 따른다.
시작 후 5초 정렬 동안 로버를 움직이지 않는다. 현재 모터 제어의 검증 범위와
고장 처리 작업은 [SAFE-01](docs/05_한계와_로드맵.md#safe-01)에 있다.

## 목적별 안내

| 목적 | 읽을 곳 |
|---|---|
| 지금 무엇을 할 것인가 | [현재 상태·남은 작업](docs/05_한계와_로드맵.md) |
| 조종 노트북 | [Station](station/README.md) |
| Pico 설치·벤치 시험 | [Pico firmware](firmware/pico/README.md) |
| Jetson 설치 / 현장 통신 | [11 — Jetson](docs/11_jetson_bringup.md), [12 — field link](docs/12_field_link.md) |
| 오도메트리 원리 / 튜닝 | [01 — 이론](docs/01_이론_오도메트리와_ESKF.md), [03 — 튜닝](docs/03_튜닝과_NIS.md) |
| PDB 설계 / 보드 외 구매 기록 | [현행 PCB 프로젝트 연결](docs/electronics/PDB_Design_Handover.md), [구매 기록](docs/electronics/Purchase_List.md) |
| 전체 문서와 기록 | [docs/README](docs/README.md) |

포트·보드레이트·물리 치수·보정 상수는 [`config.py`](rover/config.py)가 기준이다.
과거 로그의 치수는 [로그 목록](logs/README.md)을 따른다. DYNAMIXEL SDK 변경 시
[로컬 패치 기록](rover/vendor/PATCHES.md)을 함께 확인한다.
