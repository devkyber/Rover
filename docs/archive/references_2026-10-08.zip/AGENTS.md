# Working on Rover

## Start with the existing sources

Read [README.md](README.md) for entry points and
[the roadmap](docs/05_한계와_로드맵.md) for current status and open work.
Inspect the working tree before editing; it can contain substantial uncommitted
work. Preserve unrelated edits. Hardware-free checks are the default for a
documentation or offline change.

## One maintained home for each fact

| Information | Maintained source |
|---|---|
| Runtime constants, ports, dimensions, calibration defaults | `rover/config.py` |
| Filter equations and update order | `rover/eskf.py` and `rover/odometry.py`; live, replay and simulation reuse them |
| Current project status, priorities, open tasks and completion evidence | `docs/05_한계와_로드맵.md` |
| Navigation and document ownership | `docs/README.md` |
| Procedures | Existing subject guide: station, Pico, Jetson, field link, or `docs/04_실행_가이드.md` |
| Raw observations and ground-truth annotations | `logs/`, `logs/experiments.json`, and the existing `data/link_tests.csv` |
| Analysis methods, manifests and results | The corresponding experiment folder under `data/` |
| Failure mechanisms and prevention | Existing entries in `docs/07_실패기록.md` |
| PDB CAD, BOM, connector pinout and fabrication decisions | Sibling `../PCB/projects/rover-pdb/`; enter through `docs/electronics/PDB_Design_Handover.md` |
| Off-board inventory and purchase provenance | `docs/electronics/Purchase_List.md` |

Search before creating a file or task. Extend the existing owner document or
module; link to it from other entry points. Do not create parallel TODO, status,
handover, final-v2, session-summary or copied BOM files. Keep short operational
cautions beside the relevant procedure, with a link to the owning task. A
procedure may list steps; its task status belongs only in the roadmap.

## Make improvements accumulate

1. Find the existing task ID. If the issue is new, add one stable ID, its evidence,
   dependencies, and a concrete completion criterion in the roadmap.
2. Make the focused change in the owning code or document. Update related links
   in the same change. Keep existing task anchors and established file paths.
3. Run checks appropriate to the change. Record date, command, configuration and
   evidence where that experiment belongs; link the result from the same task.
   Distinguish implemented, simulated, bench-verified and field-verified. Never
   turn a synthetic pass into a hardware claim.
4. Mark that task complete in place when its criterion is met. Do not copy it to
   another completion list. Reopen the same ID if the same defect returns.
5. If there is a reusable lesson, update the matching failure entry or workflow
   rule. Create a new dated review only for a distinct review or experiment with
   new evidence, not for ordinary progress bookkeeping.

Dated reviews describe their recorded revision. Keep their evidence intact; add
a superseded/scope banner and a current-source link when needed. Archive a
replaced design only when its unique reasoning is still useful, and remove its
authority as an active specification. Do not change historical measurements to
make them agree with today's model. The submitted proposal is a historical
requirements input, not proof that a feature exists.

## Preserve evidence and reproducibility

Never bulk-delete `logs/` or `data/`. Raw measurements, manually annotated truth,
purchase records, manifests, review decisions and source/configuration hashes
are evidence. A generated file is removable only after its inputs, generator
and required code/configuration versions are retained and reproducibility has
been checked. Today's code alone cannot necessarily recreate an old result.
Keep temporary previews and recovery backups outside the repository.

For new runs, record sensor/firmware identity, geometry, calibration, timestamps
and source revision as supported by the logging tools. Until automatic run
metadata exists, record these explicitly with the experiment. Retain a separate
validation dataset; do not relabel tuning data as unseen validation. Never infer
turn accuracy from commanded angles or closure alone.

Keep passwords in ignored `*.local.md` or the configured credential store. Do
not copy them into docs, logs, examples or commit messages. Do not replace the
PDB's current native CAD with values from archived Rover notes.

## Verification

Run `python tools/check_docs.py` after documentation or file-organization changes.
It checks maintained local links, anchors, duplicate task IDs, and stray task
checklists. For behavior changes, use the relevant existing checks:

```text
python rover/test_filter.py
python rover/test_pipeline.py --fake --seconds 5
python firmware/pico/test_firmware.py
python -m unittest station.test_link_test
```

Run only the checks relevant to the change; don't repeat hardware suites for
prose edits. Hardware execution, flashing and deployment need the actual target
and the task's authorization. Report what was checked and what remains unverified.
