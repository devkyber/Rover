# Rover odometry reference review and replay comparison

> **Dated evidence, 2026-10-02.** Preserve the methods, measurements and proposed
> direction below. Current task priorities and completion live in
> [the roadmap](../05_한계와_로드맵.md). The purchase/PDB references describe inputs
> available during this review; current board authority is linked from the
> [electronics entry point](../electronics/PDB_Design_Handover.md).

Reviewed on 2026-10-02. Decision status: proposed direction, with owned hardware first. The purpose is to place soil/CIV and other mission measurements on a map using rover pose. The user has not set an accuracy requirement and wants accuracy to improve as far as practical. Hardware additions are shown separately.

**Verdict.** Wheel encoders, an IMU, and stationary updates are a sound local-odometry foundation for this rover. The literature supports that family of methods. However, accurate straight driving does not establish accurate mapping: skid-steer turns, heading drift, and common wheel slip can move measurements to the wrong map locations. The next useful work is sensor/geometry calibration, independent pose validation, and a fixed-camera experiment using the owned Arducam. A change of Kalman-filter package alone cannot supply the missing environmental reference.

The implemented ESKF is more sophisticated than the displayed trajectory: the latter directly integrates wheel speed using ESKF attitude. This matters when judging whether tuning the filter can correct map position. Keep the current implementation as a reference while validating its turning behavior and the simpler baselines below. No production estimator, original recording, firmware, or purchase list was changed by this review.

**Evidence and artifacts.** I reviewed 36 primary reference entries, covering planetary rovers, four-wheel skid-steer research, maintained robot software, calibration, and the actual sensor interfaces. I also ran fresh offline comparisons on 16 original recordings containing 222,897 unique samples. Only two recordings contain independent longitudinal checkpoint distances; no recording has independently measured continuous XY, heading, or height. Named SLAM packages were assessed from their papers/code/documentation, not run on nonexistent camera or LiDAR recordings.

| Artifact | Purpose |
|---|---|
| [Comparison script](../../data/odometry_reference_review_2026-10-02/compare_odometry.py) | Replays actual production code and explicit kinematic baselines without opening devices. |
| [Manifest](../../data/odometry_reference_review_2026-10-02/manifest.json) | Source/input hashes, geometry assumptions, diagnostic statistics, method limitations. |
| [Verification record](../../data/odometry_reference_review_2026-10-02/verification.json) | Independently recomputed CSV/trajectory statistics, finite arrays, and final source/input/link checks. |
| [Summary CSV](../../data/odometry_reference_review_2026-10-02/summary.csv) | Per-recording and per-method results. |
| [Checkpoint CSV](../../data/odometry_reference_review_2026-10-02/checkpoints.csv) | All 70 method/checkpoint comparisons at identical sample indices. |
| [Turn-width CSV](../../data/odometry_reference_review_2026-10-02/gyro_relative_turn_widths.csv) | Gyro-relative turn diagnostics; these are not measured heading errors. |

**What the repository actually supports**

| Component | Evidence in this workspace | Consequence for odometry |
|---|---|---|
| Locomotion | Four XH430-V350-R drive motors; four-wheel skid steering; signed motor positions, velocities, and currents logged near 100 Hz. | Four-wheel skid-steer/Husky/Pioneer research is closer than copying six-wheel steerable Mars rover kinematics. |
| Current IMU | Arduino Nano 33 IoT, LSM6DS3, approximately 104 Hz. | This is the sensor in the recordings; BMI088 noise assumptions are not measured LSM6DS3 calibration. |
| Planned IMU | Purchased BMI088 shuttle board; `RealIMU` still raises `NotImplementedError`. | A better IMU can reduce inertial noise, but the upgrade has not been evaluated on these logs and cannot observe common steady wheel slip by itself. |
| Current geometry | Radius 0.055 m; `WHEELBASE_M` 0.1585 m is the left-right track, despite its name. | Preserve physical dimensions separately from a fitted skid-steer turning parameter. |
| Historical geometry | Older docs/prior evaluation use radius 0.0625 m and track 0.485 m. Geometry is not embedded in each recording. | September replay uses the prior evaluation assumption. It is not proof of the physical dimensions on the recording date. |
| Camera | Owned Arducam B0201, IMX291, USB 2.0 UVC, nominal 1080p/120 degrees; mounted on a continuous pan servo. No measured pan angle. | Standard camera/IMU or camera/body extrinsics are not constant while panning. Mechanically fix the camera before ordinary VO/VIO experiments. A PWM command is not a measured pan angle. |
| Compute | Latest PDB/purchase documents specify Jetson Orin Nano Super; older camera notes describe the original Jetson Nano/JetPack 4.6. | Verify the actual board and software image before choosing a ROS/Isaac release. No on-rover compute benchmark was performed. |
| Mapping payload | Proposal describes rover hammer/CIV mapping and scout measurements. | Store the measurement location, time, sensor offset, and pose provenance. A rover-center dot is not automatically the hammer contact point or scout landing point. |
| Constraints | Current design documents specify a 3 kg system; no spare expansion current is reserved in the PDB budget. | Optional cameras/LiDAR need measured mass, power, bandwidth, and thermal checks before selection. |

Local evidence: [config.py](../../rover/config.py#L61), [odometry.py](../../rover/odometry.py#L294), [IMU driver](../../rover/imu_reader.py), [purchase list](../electronics/Purchase_List.md), [PDB handover](../electronics/PDB_Design_Handover.md), [mission proposal](../91_KSRC_기술제안서.md), and [older camera notes](../archive/99_카메라_노트.md). Documented requirements are not independently verified competition rules.

The XH430 encoder provides 4096 counts/revolution. With the current 55 mm radius, one count represents approximately 0.084 mm of nominal wheel travel. That fine resolution measures wheel rotation, not ground travel; it does not remove tyre deformation, gearing backlash, or terrain slip. Higher encoder resolution is therefore a lower-priority accuracy improvement than calibration and an independent motion reference. [ROBOTIS XH430 manual](https://emanual.robotis.com/docs/en/dxl/x/xh430-v350/).

**What real rover examples teach us**

| Reference | Similarity and demonstrated approach | What transfers to this rover |
|---|---|---|
| WVU planetary-rover navigation / Husky and Pathfinder | Wheel odometry, inertial navigation, nonholonomic constraints, ZUPT/ZARU, and optional backward smoothing; tested against external positioning. | Strong support for stationary constraints and this estimator family. Their full navigation state/output and validation are not identical to our separately integrated public pose. [Paper](https://arxiv.org/abs/1906.08849), [coreNav implementation](https://github.com/wvu-navLab/corenav). |
| Pioneer P3-AT skid-steer experiments | Four-wheel skid steering; experimentally identifies instantaneous-center-of-rotation parameters using independent motion measurements. | Physical track is not generally the correct yaw denominator on a skid-steer rover. Calibrate on relevant surfaces and validate on separate drives. [Mandow et al., 2007](https://babel.isa.uma.es/_utils/downloads/logdownloads.php?f=downloads%2Fjafma%2Fpapers%2Fmandow2007ekw.pdf&t=pdf&u=jafma). |
| Online ICR estimation | EKF learns skid-steer kinematic parameters while incorporating measured position and heading. | Online adaptation still needs informative measurements. It cannot make unmeasured common slip observable just by adding states. [Pentzer et al., 2014](https://doi.org/10.1002/rob.21509). |
| Camera/wheel/IMU skid-steer estimation | Online kinematic calibration is incorporated into a visual estimator; analyzes what motion/sensors make parameters observable. | Particularly relevant to a future fixed-camera fusion experiment. A calibrated visual reference provides information absent from encoder-only fitting. [Zuo et al.](https://arxiv.org/abs/2006.04335). |
| Spirit and Opportunity | Stereo visual odometry measures terrain-relative motion and supports slip detection; six-wheel steerable platforms. | Transfer the independent visual-motion principle, not their steering model or claimed accuracy. [Maimone et al., 2007](https://robotics.jpl.nasa.gov/media/documents/rob-06-0081.R4.pdf). |
| Curiosity | Wheel/IMU navigation augmented by visual odometry to identify slip and improve navigation. | Mature rover practice adds an environmental observation rather than expecting wheel and inertial sensors to solve every slip condition. [JPL navigation description](https://robotics.jpl.nasa.gov/what-we-do/flight-projects/mars-science-laboratory/surface-system-software-and-rover-navigation/). |
| IDEFIX / DLR NAVDLR | Small planetary rover navigation uses calibrated stereo images to estimate six-dimensional pose, slip, elevation, and obstacle maps. Tests include external motion-capture truth and lighting degradation. | A close mission analogy: navigation, mapping, and image quality are evaluated together. Their 60 mm stereo baseline is a design example, not a prescription for our camera. [DLR paper](https://elib.dlr.de/223724/1/20260330_mmx_nav_radiation_elib_copyright.pdf). |
| Clearpath Husky navigation demonstrations | Practical mobile-robot stack uses odometry fusion and environmental navigation sensors such as laser plus IMU. | A useful integration example; the existence of a navigation demo does not prove wheel-only mapping accuracy. [Clearpath configuration](https://docs.clearpathrobotics.com/docs/ros/tutorials/navigation_demos/configuration/). |
| JPL Open Source Rover | Public hardware/software example for a six-wheel educational rover. | Useful engineering reference, with different locomotion. Do not treat it as a published benchmark for our four-wheel system. [Project](https://github.com/nasa-jpl/open-source-rover). |

A useful reality check: the WVU paper's 34 m concrete-turn test, with seven stops, reports a median horizontal error of 0.49 m and maximum 1.20 m for its combined inertial, zero-type, nonholonomic, and wheel constraints before backward smoothing. This is evidence that the approach helps, not a transferable error forecast or a guarantee of centimeter mapping. The paper's hardware, paths, stop schedule, and metrics differ from our tests. [WVU results table](https://arxiv.org/pdf/1906.08849).

**Actual replay experiment**

All methods share the production startup gate and stop/hold decisions, the same input frame conversion, and the same time-step policy. Startup requires five contiguous stationary seconds; 15 recordings reach alignment and one does not. The methods use only past/current samples during trajectory generation. Effective-track fitting uses other October recordings, as described below. The point is to isolate motion integration and heading choices, not to rank alternative stillness detectors.

| Method in the CSV | What was actually executed |
|---|---|
| `production` | Current production `Odometry` and ESKF; published position, not internal diagnostic position. |
| `gyro_startup_velocity` | Planar integration of mean signed reported wheel velocity; body-z gyro with initial stationary bias subtraction. |
| `gyro_stops_velocity` | Same wheel velocity; causal gyro-bias refresh during production-confirmed stops, one-second low-pass; yaw held during these stops. |
| `gyro_stops_position` | Same causal gyro heading; wheel-position increments for distance; exact SE(2) arc integration per increment. |
| `gyro_stops_position_scale_sensitivity` | Previous method with gyro heading increments multiplied by 1.14688; an input-unit sensitivity experiment, not a calibrated fix. |
| `wheel_position_geometric` | Mean wheel-position increments for distance; right-minus-left travel divided by configured physical track for yaw. |
| `wheel_position_effective_loo` | October only: wheel-only yaw using a fixed effective track learned from other recordings' gyro-relative turns. Leave-one-recording-out sensor consistency, not independent heading validation. |
| `production_current_geometry_on_old_log` | Supplemental check: production replay of the two September measured runs with today's radius/track. |

The production output rotates the body forward velocity using full 3D attitude. Other baselines are planar; they are diagnostic references, not general replacements for slope motion. Raw gyro and wheel readings can also have different acquisition times; sharing host time steps does not repair a synchronization problem. Position-counter jumps over 0.5 rad during active data would stop the comparison; none triggered that guard. Straight/reverse, quarter-circle, and in-place-turn analytic integration checks passed. Source/input SHA-256 hashes matched before and after the run, and in-memory geometry was restored.

The two prior checkpoint runs contain ten longitudinal stops in total. Every method is evaluated at the same stop indices, matched once under the documented historical geometry. September uses radius 0.0625 m and track 0.485 m from the earlier evaluation, with no claim these were independently recorded physical dimensions. Checkpoint distances are from [experiments.json](../../logs/experiments.json). These recordings were previously used for tuning, so they are not a held-out validation set. Lateral position and heading were not independently measured; the metadata's 5 cm tolerance is not a documented measurement-uncertainty estimate.

| Method | 23:34 maximum absolute x error | 23:34 x RMSE | 23:47 maximum absolute x error | 23:47 x RMSE |
|---|---:|---:|---:|---:|
| Production ESKF + wheel output | 3.98 cm | 2.67 cm | 5.39 cm | 3.06 cm |
| Gyro with startup bias + wheel velocity | 3.98 cm | 2.67 cm | 5.39 cm | 3.06 cm |
| Gyro with stop bias + wheel velocity | 3.97 cm | 2.67 cm | 5.39 cm | 3.06 cm |
| Gyro with stop bias + position increments | 5.08 cm | 3.46 cm | 8.13 cm | 4.63 cm |
| Same, gyro scale sensitivity 1.14688 | 5.07 cm | 3.46 cm | 8.13 cm | 4.63 cm |
| Geometric wheel-only position/yaw | 5.08 cm | 3.46 cm | 8.13 cm | 4.63 cm |
| Production with current geometry on old data | 11.67 cm | 8.02 cm | 13.25 cm | 8.02 cm |

The longitudinal result does not show an advantage from the full filter over a basic gyro/wheel-velocity reference on these short straight runs. Counter increments are not automatically better: they performed worse against these checkpoints. The discrepancy needs a fresh, synchronized distance experiment before changing the distance source. Today's smaller radius also changes old results substantially; blindly replaying historical logs with the latest geometry produces a misleading comparison.

![Checkpoint errors and gyro-relative track-width diagnostics](../../data/odometry_reference_review_2026-10-02/comparison.png)

Turning exposes a larger uncertainty. For 161 selected October turn episodes, the inferred effective track from wheel difference divided by causal gyro angle has 10th/50th/90th percentiles of **0.397/0.421/0.441 m**, versus the configured physical track of **0.1585 m**. Selection requires wheel-difference speed above 0.04 m/s, duration at least 0.4 s, gyro angle at least 10 degrees in magnitude, and a positive inferred track between 0.05 and 2 m. The median ratio is 2.66. This supports investigating a skid-steer turn model, but it is a conditional fit against an unvalidated gyro, not a measurement of all turns. If the 1.14688 gyro scale were applied, the median would be about 0.367 m instead. Do not replace the physical geometry with 0.421 m and call it calibrated; keep a separate effective turning parameter and obtain independent angular truth.

The 01:58 recording illustrates disagreement, not accuracy:

| Method | Estimated path length | Final estimated yaw | Final estimated XY |
|---|---:|---:|---:|
| Production | 11.37 m | -30.97 degrees | (2.697, -0.725) m |
| Gyro with stop bias + wheel velocity | 11.84 m | -8.42 degrees | (3.501, 0.001) m |
| Gyro with stop bias + position increments | 12.01 m | -8.42 degrees | (3.517, 0.001) m |
| Geometric wheel-only | 12.01 m | -152.66 degrees | (4.617, -0.220) m |
| Wheel-only with track from other logs | 12.01 m | -57.28 degrees | (3.348, 0.602) m |

Production and the causal gyro/velocity baseline finish about 1.08 m apart and disagree by 22.55 degrees in final yaw. The route and final heading were not surveyed, so the apparently cleaner trajectory cannot be declared correct. A wheel-only turn model based on physical track is particularly inconsistent with the gyro, but neither sensor is independent truth here. Other free-drive recordings also show disagreement; no assumed square, 90-degree turn, or loop endpoint was used as a fabricated reference.

![Turning estimator disagreement without ground truth](../../data/odometry_reference_review_2026-10-02/turn_disagreement.png)

**Calibration and implementation findings that precede a package change**

1. **Confirm the LSM6DS3 gyro conversion.** The locally installed Arduino library is version 1.0.3. Its source configures the 2000 dps range and converts using `2000 / 32768`, approximately 61.035 mdps/count. ST's reference conversion for this range uses 70 mdps/count. Their ratio is 1.14688. October log quantization is consistent with the old conversion, and the earlier unit audit records the same conclusion. This is strong evidence to check the flashed build and sensor registers, but the installed source alone does not identify the flashed binary. Verify with independently measured CW/CCW rotations, then update units and recalibrate bias/noise together. The sensitivity replay was kept separate from production. [Arduino source](https://github.com/arduino-libraries/Arduino_LSM6DS3/blob/1.0.3/src/LSM6DS3.cpp), [ST source](https://github.com/STMicroelectronics/lsm6ds3-pid/blob/master/lsm6ds3_reg.c), [local unit audit](../../data/odometry_tuning_2026-10-02/methods/gyro_unit_quantization.json).
2. **Version geometry and sensor calibration per recording.** Log radius, physical track, wheel signs, firmware/library version, IMU frame/range/rate, calibration ID, and configuration hash. Separate wheel radius/straight-distance scale from terrain-dependent effective track or ICR parameters. Historical data must not silently inherit current values.
3. **Use a coherent published pose and uncertainty.** The present output is `p_next = p + R(q_ESKF) [v_wheel, 0, 0] dt`, while ESKF position is diagnostic only. Increasing wheel-measurement covariance cannot directly reduce wheel-slip distance in that public integrator. Relaxing lateral NHC noise also does not admit lateral slip into the published trajectory: its body-y velocity is still fixed to zero. Likewise, internal ESKF position covariance is not the covariance of the published position. A later implementation should either use a consistent estimated state for local pose or explicitly propagate the separate output's uncertainty and cross-correlations. Adding VO later requires defining exactly which state it corrects.
4. **Validate heading under real turns.** Global heading is unobserved with these sensors. The custom yaw-preserving update protects direct yaw changes, but pseudo-measurements can still change estimated gyro bias and later gyro integration. The planar comparison demonstrates disagreement, not the cause. Inspect trace/bias evolution alongside independent heading before replacing the ESKF with the simpler reference. Preserve 3D attitude support for slopes.
5. **Make freshness part of validity.** The Arduino reader can return the previous IMU sample with a new host timestamp; non-finite float inputs are not rejected by the parser. Use device time/sequence, explicit age, finite-value checks, and an invalid/degraded state. Do not integrate an old turn-rate sample repeatedly as fresh motion. Camera/encoder/IMU time alignment also matters for any fusion experiment. [OpenVINS calibration guidance](https://docs.openvins.com/gs-calibration.html).
6. **Keep stop detection conservative.** Startup and ZUPT depend on shared wheel/IMU evidence. Stable motion, an externally moved rover, or a carried rover can violate wheel and body-motion assumptions. Also, the current `zupt_active` property omits `use_zupt`, so a nominally disabled ZUPT can still clamp published translation; avoid interpreting that switch as a clean ablation until corrected. This comparison used normal production stop behavior throughout.
7. **Treat current as a slip warning, not displacement.** The motor manual's stall torque/current ratio is not a calibrated traction measurement. Current varies with drivetrain friction, load, acceleration, and terrain. It can support anomaly detection and uncertainty inflation; independent motion is needed to establish a reliable slip correction. [NASA path-following/slip work](https://ntrs.nasa.gov/citations/20110015134).

**Alternative odometry evaluated against our hardware and mission**

The judgment below concerns applicability and information supplied. Numerical results exist only for the explicit replay methods above. Published benchmark rankings, successful demo videos, or another rover's drift percentages do not establish accuracy on our rover.

| Option | Owned-hardware fit | Contribution and main limitation | Judgment |
|---|---|---|---|
| Current wheel/IMU ESKF with stops | Direct; already runs | Good high-rate local attitude/motion foundation. Public distance remains directly wheel-derived; no environmental drift correction. | Keep as the reference and improve calibration/output consistency before increasing complexity. |
| Simple planar gyro + wheel velocity | Direct; executed here | Easy to diagnose; essentially same tape accuracy. Heading disagreement and 3D slope limitations remain. | Keep as a benchmark/fallback candidate, not an established more accurate replacement. |
| Wheel-position increments | Direct; executed here | Avoids velocity-time integration for distance but inherits counters, signs, timing, geometry, and slip. Worse on existing tape runs. | Compare in a new controlled test before adopting. |
| Differential-drive yaw from physical track | Direct; executed here | Neglects skid steering's effective turning geometry. Strongly disagrees with gyro on October data. | Poor default heading source for this rover without skid calibration. |
| Effective-track / ICR skid model | Direct sensors; needs calibration truth | Improves the wheel-turn model. ICR/lateral motion can vary with terrain and load. Does not fix common forward slip or provide a map anchor. | Worth calibrating separately; use an uncertainty-aware fallback when gyro/vision degrades. [Skid model](https://arxiv.org/abs/2006.04335). |
| `robot_localization` EKF/UKF | Middleware conversion needed | Standard ROS fusion and frame/covariance handling. Its standard state is not our gyro/accel-bias ESKF. Changing packages supplies no new measurements. Avoid double-counting pose and velocity derived from the same encoders. | Useful if adopting ROS; not the first accuracy improvement. [Configuration](https://github.com/cra-ros-pkg/robot_localization/blob/rolling-devel/doc/configuring_robot_localization.rst). |
| ROS `diff_drive_controller` | Driver adapter needed | Provides position/velocity feedback choices and radius/separation corrections. Its differential-drive model does not independently observe skid or terrain slip. | Integration reference, not a validated skid-steer navigation replacement. [Documentation](https://control.ros.org/rolling/doc/ros2_controllers/diff_drive_controller/doc/userdoc.html). |
| ORB-SLAM3 monocular / monocular-inertial | Existing camera must be fixed, calibrated, and timestamped; IMU available | Visual tracks and loop closure add environmental information. Pure monocular geometry has scale ambiguity; inertial scale needs sufficiently informative motion/calibration. Slow, nearly planar runs can be poorly conditioned. | A useful owned-camera experiment after collecting synchronized data. No claim it will initialize reliably or outperform our baseline yet. [Author implementation](https://github.com/UZ-SLAMLab/ORB_SLAM3). |
| OpenVINS mono + IMU | Same camera/time prerequisites | Filter-based visual-inertial estimator; calibration and zero-velocity tools are relevant. It is primarily a VIO front end, so mapping/loop-correction integration remains separate. | Good second research baseline for diagnosing VIO with existing sensors. [Implementation](https://github.com/rpng/open_vins), [zero-velocity updater](https://github.com/rpng/open_vins/blob/master/ov_msckf/src/update/UpdaterZeroVelocity.cpp). |
| VINS-Fusion | Fixed mono+IMU or stereo; old ROS dependencies | Optimization-based VIO with optional loop fusion and time/extrinsic calibration. Existing code documents Ubuntu 16.04/18.04 and ROS Kinetic/Melodic. | Relevant reference, with meaningful port/integration effort on a newer Orin image. [Author implementation](https://github.com/HKUST-Aerial-Robotics/VINS-Fusion). |
| VIW-Fusion | Fixed mono/stereo + IMU + wheel; port required | Directly fuses wheel measurements, with wheel/extrinsic/time calibration and plane constraints. Wheel constraints need adaptation/relaxation for skid and slopes. Old ROS/Ceres environment. | More mission-relevant than generic VIO in some respects, but not a drop-in package for our four-wheel rover. [Author implementation](https://github.com/TouchDeeper/VIW-Fusion). |
| Ground-Fusion | Current RGB-D sensor absent; wheel/IMU available | Ground-robot RGB-D/IMU/wheel/GNSS fusion, anomaly handling, and dense mapping. Original implementation uses ROS Melodic/Noetic; dense mapping is resource-intensive. | Strong reference for failure handling and future integration, not an executable replacement using our current monocular logs. [Author implementation](https://github.com/SJTU-ViSYS/Ground-Fusion). |
| Surveyed AprilTags with fixed Arducam | Uses owned camera; requires known-size/known-position tags | Can supply metric camera pose against known landmarks without a stereo upgrade. Intrinsics, viewing geometry, tag survey, lever arm, and timestamps determine accuracy. | Best controlled first environmental-reference experiment if markers are permitted in that setting. It is not a natural-terrain planetary navigation solution. [AprilTag pose estimation](https://github.com/AprilRobotics/apriltag). |
| Fixed metric stereo + RTAB-Map | Additional synchronized camera required | Stereo motion plus graph loop closure and geometry mapping; a practical complete mapping prototype. Needs texture, calibration, reliable images, and measured compute performance. | Preferred upgrade experiment if owned-camera trials are inadequate. Start with one clear odometry source and a map backend. [ROS 2 package](https://github.com/introlab/rtabmap_ros/tree/ros2), [stereo workflow](https://github.com/introlab/rtabmap/wiki/Stereo-mapping). |
| ORB-SLAM3 stereo/stereo-inertial | Stereo upgrade | Metric stereo removes the monocular geometric scale ambiguity; visual-inertial and loop-closure capabilities. Sparse landmarks are not a complete soil/elevation map. | Compare as an alternative front end once a common stereo dataset exists. [Author implementation](https://github.com/UZ-SLAMLab/ORB_SLAM3/blob/master/README.md). |
| Isaac ROS Visual SLAM / cuVSLAM | Suitable GPU software image and supported camera needed | GPU visual SLAM is relevant to Orin. Release 3.2 documents Orin, JetPack 6.1/6.2, ROS 2 Humble, and strict image timing. Latest releases have a different compatibility matrix. | Candidate after hardware/image verification; no measured FPS, accuracy, memory, or power result on our rover. [Release 3.2](https://nvidia-isaac-ros.github.io/v/release-3.2/repositories_and_packages/isaac_ros_visual_slam/index.html), [release 5.0](https://nvidia-isaac-ros.github.io/v/release-5.0/repositories_and_packages/isaac_ros_visual_slam/index.html). |
| FAST-LIO / FAST-LIO2 | 3D LiDAR absent | LiDAR/IMU motion estimation works from geometric observations; depends on point timing, extrinsics, and sufficient scene structure. A basic odometry front end still needs a map/loop-closure strategy. | Separate upgrade class; not a first change under our mass/power constraints. [Author implementation](https://github.com/hku-mars/FAST_LIO). |
| `slam_toolbox` | 2D laser absent | Mature 2D pose-graph mapping/localization. A single horizontal scan and planar model have limitations for the proposed uneven terrain. | Relevant for a planar terrestrial prototype with a laser, lower priority for this mission. [Author implementation](https://github.com/SteveMacenski/slam_toolbox). |
| GNSS, UWB, external tracking | Extra infrastructure/sensors | Can provide a terrestrial validation reference or operational anchors where permitted. Infrastructure/coverage differs from planetary operation. | Use as independent test truth where available; do not assume mission or competition authorization. |

For the owned camera, calibration is a prerequisite rather than an optional polish step. Record images with actual acquisition times, camera intrinsics/distortion, rigid camera-to-body and camera-to-IMU transforms, exposure, frame drops, and IMU device timestamps. OpenVINS recommends deliberate translation plus rotations about multiple axes for camera/IMU calibration. Ordinary slow planar driving alone is a poor calibration sequence. Its guidance suggests camera rates around 20–30 Hz and IMU rates around 200–500 Hz; our 104 Hz stream is below that IMU guidance, not automatically incompatible with every VIO implementation. Measure the actual stream before selecting a configuration. [Calibration guidance](https://docs.openvins.com/gs-calibration.html), [Kalibr procedure](https://github.com/ethz-asl/kalibr/wiki/camera-imu-calibration).

If an upgrade is later selected, choose a camera system as a calibrated, synchronized measurement device, not just by nominal resolution. Release 3.2 of NVIDIA's visual SLAM documents a 30 Hz minimum target, frame-rate jitter within ±2 ms, and stereo image offsets within ±100 microseconds. Two unrelated USB cameras are not automatically a qualifying stereo pair. Use the release's tested platform matrix; the original Jetson Nano and an Orin Nano Super are different devices. Vendor KITTI accuracy/FPS numbers from another platform are not our rover's result. [NVIDIA camera/platform requirements](https://nvidia-isaac-ros.github.io/v/release-3.2/repositories_and_packages/isaac_ros_visual_slam/index.html).

**Mapping based on rover position: the architecture consequence**

An arbitrary initial map origin and yaw are acceptable for a local survey. The problem is drift *during* the survey and between revisits, not failure to know geographic north. A map backend needs environmental observations or surveyed landmarks to reduce that relative drift. ZUPT/ZARU makes stopped velocity/rate more reliable; it does not move earlier measurement points back to their true locations. Common wheel slip at approximately constant body speed can be weakly observable or unobservable from wheel encoders and this IMU alone.

Use two pose concepts: continuous local `odom` for motion/control, and corrected `map` for mission data. The map-to-odom transform changes when landmarks or loop closure correct the trajectory. This separation follows established mobile-robot frame conventions and can also be implemented without adopting ROS immediately. [REP-105](https://github.com/ros-infrastructure/rep/blob/master/rep-0105.rst).

```mermaid
flowchart LR
  M["map: corrected survey frame"] -->|"landmark or SLAM correction"| O["odom: continuous local frame"]
  O -->|"wheel + IMU local pose"| B["base_link: rover body"]
  B -->|"measured payload offset"| H["hammer contact point"]
```

For a rigid payload offset, compute the measurement point using

`p_map_contact(t) = p_map_body(t) + R_map_body(t) * lever_arm_body_contact`.

If the mechanism changes the contact offset, use its measured/configured position at that event. Store the raw measurement, timestamp, original local pose/pose ID, calibration ID, contact offset, and quality flags so that later trajectory corrections can reproject it. Do not bake the first uncertain rover coordinates permanently into a raster. Associate each hammer event with a pose at the contact time; mark shock-saturated IMU samples or lost tracking rather than treating them as normal motion. Scout landing coordinates require their own relative-flight/landing uncertainty in addition to the rover launch pose.

The mission can initially store a point map of measurements without building a dense 3D scene. However, a visually tidy point plot is not evidence of accurate placement. Maintain separate uncertainty for the scientific value and the position where it was taken. Pose uncertainty, repeated-measurement spacing, and actual spatial variation should determine the eventual grid resolution.

Simple geometric sensitivity shows why heading validation matters:

| Assumption for a 5 m straight leg | Approximate placement effect |
|---|---:|
| Constant 1 degree heading error | 8.7 cm cross-track offset |
| Constant 3 degree heading error | 26.2 cm cross-track offset |
| Constant 5 degree heading error | 43.6 cm cross-track offset |
| 3% wheel-distance scale/slip error | 15 cm along-track offset |

These are calculations from `L * sin(heading_error)` and `L * distance_fraction`, not measured performance forecasts. Time-varying heading, slip, slopes, and payload offsets change the full error. An IMU datasheet's noise density or a quiet stationary plot is not a heading-drift bound; the BMI088 upgrade must be calibrated and evaluated on moving data. [Bosch BMI088 documentation](https://www.bosch-sensortec.com/en/products/motion-sensors/imus/bmi088).

No fixed accuracy requirement is needed to start. First measure a repeatable placement-error distribution, including failures. As a provisional presentation rule, a map cell should be at least twice the measured 95th-percentile horizontal placement error; for example, a demonstrated 10 cm error might support a 20 cm exploratory cell size. This is a conservative display heuristic, not a mapping standard or a guarantee of cell assignment near boundaries. It must also respect sampling density and soil-feature size. The existing ten longitudinal checkpoints are insufficient to estimate that 95th-percentile XY error for a real mapping mission.

**Owned-hardware plan and the experiment that can decide the next step**

| Order | Concrete work using the owned hardware | Evidence needed before claiming improvement |
|---|---|---|
| 1 | Confirm gyro range/conversion, axis signs, IMU mounting, wheel signs, physical geometry, actual acquisition times, and fresh samples. Create versioned calibration metadata. | Independently measured distance and CW/CCW turns reproduce the calibration across repeated trials; no stale samples silently used. |
| 2 | Run controlled distance/turn tests; compare current ESKF, causal gyro/velocity, position-counter integration, and separately calibrated skid yaw. Retain roll/pitch for slopes. | Held-out XY/heading error improves, including reverse, turning, terrain changes, and stop transitions. |
| 3 | Fix the existing Arducam mechanically for a dataset. Calibrate intrinsics, extrinsics, and timing; record images and raw IMU/wheel telemetry together. | Camera remains rigid, useful textured images have stable measured timing, and hardware/thermal logging confirms real-time feasibility. |
| 4 | Use known landmarks/AprilTags in a controlled test area if permitted. Then test natural-feature monocular or monocular-inertial odometry on the same recordings. | Independent truth shows whether visual heading/position corrections improve placement and how often tracking fails. Report metric scale handling explicitly. |
| 5 | Store CIV/contact events with pose IDs, offsets, timestamps, uncertainty, and tracking quality; reproject after map correction. | Repeated measurements at surveyed locations overlay consistently; loop correction moves historical events correctly. |
| Later | If fixed monocular tests cannot meet useful placement accuracy, evaluate synchronized metric stereo with RTAB-Map first; compare another front end on the same data. LiDAR is a separate mass/power tradeoff. | Same-course held-out accuracy, failure rate, latency, power, memory, and map consistency justify the added hardware. |

This order keeps the current hardware useful. If the pan camera must remain available for operator viewing, take fixed-camera datasets during dedicated experiments first; do not fuse actively panning images through a rigid extrinsic model. For permanent simultaneous navigation and pan viewing, a real pan encoder with a calibrated kinematic model or a separate fixed camera would be a hardware change.

Independent truth can be a calibrated overhead camera observing a rigid AprilTag on the rover, motion capture, or another measured tracker. With an overhead camera, account for tag height/perspective, surveyed control points, tag-to-rover offset, and clock alignment. A tape/turntable/protractor can support short calibration tests, with its measurement uncertainty recorded. A commanded 90-degree turn is not a measured 90-degree turn. Do not validate a fused sensor against the same sensor's pose as if it were independent truth. AprilTag needs calibrated camera intrinsics and the actual tag size; it has no automatic centimeter-accuracy guarantee. [AprilTag pose-estimation API](https://github.com/AprilRobotics/apriltag).

Run at least three repeats per relevant condition, preferably five, with separate calibration and blind validation recordings:

- Forward/reverse 1 m, 3 m, and 5 m legs at more than one speed, with surveyed starts/stops.
- Independently measured CW/CCW 90-, 180-, and 360-degree turns, both in place and on arcs.
- Surveyed squares and figure-eights to expose heading and lateral-slip effects; closure alone is insufficient because errors can cancel.
- Firm floor plus the actual loose/rough test surface, changed payload, and a representative slope.
- Stationary warm-up/noise runs and hammer events, recording saturation and any chassis motion.
- For camera methods, ordinary and difficult lighting, low texture, temporary occlusion, and recovery after tracking loss.

Report horizontal absolute-position error (median, RMSE, 95th percentile, maximum), relative drift over fixed distances, heading error, contact-point placement error, alignment time/failure, tracking uptime, recovery behavior, sample age/drop rate, and actual compute latency/power. ATE/APE and RPE answer different questions. Align only the arbitrary rigid initial frame when necessary; do not use similarity-scale fitting to hide wheel-radius or metric-scale errors. [evo metric definitions](https://github.com/MichaelGrupp/evo/wiki/Metrics).

Public datasets can confirm a build or explore failure modes before rover recordings exist, but they cannot settle the hardware decision. Ground-robot benchmarks such as M3DGR are particularly relevant to sensor degradation and fusion design; EuRoC/KITTI results have different sensors, motion, surfaces, and evaluation conditions. The primary decision must use the rover's own synchronized data and independent truth. [Ground sensor-fusion benchmark](https://arxiv.org/abs/2507.08364).

**Decision record**

Keep wheel/IMU/stationary constraints as the local foundation and a reproducible baseline. Prioritize unit/geometry/time calibration and independently measured turning. Use the owned fixed camera for the first environmental-reference experiment. Keep corrected map poses distinct from continuous local motion, and store mission measurements so corrections remain possible. A fixed stereo system is the leading optional upgrade; package replacement, current-based slip compensation, and LiDAR are conditional later choices.

The benefit is that each stage adds testable information or removes a specific ambiguity. The cost is calibration and a validation dataset before claiming map accuracy. The remaining risk is that the owned monocular camera and current IMU may not provide enough reliable information during slow, planar, low-texture or rough-terrain driving. In that case the experiments, rather than a literature ranking, should trigger the stereo decision.

**Primary reference inventory**

The 36 entries below were inspected through the authors' papers, project code, manufacturer documentation, or official robot documentation. Multiple supporting pages sometimes belong to one entry. Search coverage included planetary wheel/inertial zero constraints, skid-steer ICR calibration, camera/wheel observability, rover visual navigation, ground-robot SLAM failure handling, Jetson compatibility, and sensor conversion. This is a broad practical review, not an exhaustive systematic literature search. Moving repository branches and documentation were checked on 2026-10-02; pin commits and dependency versions for any subsequent executable package comparison.

| ID | Primary source | Why it was included |
|---|---|---|
| 01 | [Kilic et al.: periodic zero-type constraints](https://arxiv.org/abs/1906.08849) | Closest wheel/IMU/stops navigation family; externally validated rover results. |
| 02 | [WVU coreNav](https://github.com/wvu-navLab/corenav) | Authors' implementation, including postprocessing and ROS material. |
| 03 | [Mandow et al.: experimental skid-steer kinematics](https://babel.isa.uma.es/_utils/downloads/logdownloads.php?f=downloads%2Fjafma%2Fpapers%2Fmandow2007ekw.pdf&t=pdf&u=jafma) | Four-wheel Pioneer experimental ICR/kinematic identification. |
| 04 | [Pentzer et al.: online skid-steer ICR estimation](https://doi.org/10.1002/rob.21509) | What online kinematic learning requires as measurements. |
| 05 | [Zuo et al.: skid-steer pose and kinematic parameter estimation](https://arxiv.org/abs/2006.04335) | Camera/wheel/IMU fusion and parameter observability. |
| 06 | [Maimone et al.: two years of MER visual odometry](https://robotics.jpl.nasa.gov/media/documents/rob-06-0081.R4.pdf) | Field experience with terrain-relative stereo motion and slip. |
| 07 | [JPL Curiosity surface navigation](https://robotics.jpl.nasa.gov/what-we-do/flight-projects/mars-science-laboratory/surface-system-software-and-rover-navigation/) | Operational wheel/inertial/visual navigation architecture. |
| 08 | [NASA path following and slip compensation](https://ntrs.nasa.gov/citations/20110015134) | Independent visual motion versus predicted wheel motion for slip. |
| 09 | [DLR IDEFIX/NAVDLR environmental-influence study](https://elib.dlr.de/223724/1/20260330_mmx_nav_radiation_elib_copyright.pdf) | Small planetary rover stereo pose/maps, truth, and image degradation. |
| 10 | [Clearpath navigation configuration](https://docs.clearpathrobotics.com/docs/ros/tutorials/navigation_demos/configuration/) | Practical Husky sensor and navigation integration. |
| 11 | [JPL Open Source Rover](https://github.com/nasa-jpl/open-source-rover) | Public rover engineering example; different steering geometry. |
| 12 | [robot_localization configuration](https://github.com/cra-ros-pkg/robot_localization/blob/rolling-devel/doc/configuring_robot_localization.rst) | Sensor covariance, constraints, and duplicate information. |
| 13 | [ROS 2 differential-drive controller](https://control.ros.org/rolling/doc/ros2_controllers/diff_drive_controller/doc/userdoc.html) | Feedback/integration choices and geometric corrections. |
| 14 | [REP-105 coordinate frames](https://github.com/ros-infrastructure/rep/blob/master/rep-0105.rst) | Continuous odometry versus corrected map frame. |
| 15 | [RTAB-Map ROS 2](https://github.com/introlab/rtabmap_ros/tree/ros2) | Mapping/loop-closure integration option after new image data exists. |
| 16 | [RTAB-Map stereo mapping](https://github.com/introlab/rtabmap/wiki/Stereo-mapping) | Calibrated stereo recording and replay workflow. |
| 17 | [RTAB-Map ROS 2 launch implementation](https://github.com/introlab/rtabmap_ros/blob/ros2/rtabmap_launch/launch/rtabmap.launch.py) | Actual RGB-D/stereo/ICP, synchronization, and frame interfaces. |
| 18 | [ORB-SLAM3](https://github.com/UZ-SLAMLab/ORB_SLAM3) | Mono/stereo/RGB-D and inertial front ends with map/loop support. |
| 19 | [OpenVINS](https://github.com/rpng/open_vins) | Filter-based visual-inertial reference. |
| 20 | [OpenVINS sensor calibration](https://docs.openvins.com/gs-calibration.html) | Intrinsics, extrinsics, time offsets, noise, and excitation. |
| 21 | [OpenVINS zero-velocity implementation](https://github.com/rpng/open_vins/blob/master/ov_msckf/src/update/UpdaterZeroVelocity.cpp) | How another estimator handles stationary visual/inertial evidence. |
| 22 | [VINS-Fusion](https://github.com/HKUST-Aerial-Robotics/VINS-Fusion) | Optimization-based mono/stereo VIO and integration prerequisites. |
| 23 | [VIW-Fusion](https://github.com/TouchDeeper/VIW-Fusion) | Visual/inertial/wheel fusion with spatial, time, and wheel calibration. |
| 24 | [Ground-Fusion](https://github.com/SJTU-ViSYS/Ground-Fusion) | Ground-robot sensor anomalies, wheel fusion, and dense-map costs. |
| 25 | [Ground SLAM benchmark and resilient framework](https://arxiv.org/abs/2507.08364) | M3DGR/Ground-Fusion++ and sensor-degradation evaluation design. |
| 26 | [Isaac ROS Visual SLAM release 3.2](https://nvidia-isaac-ros.github.io/v/release-3.2/repositories_and_packages/isaac_ros_visual_slam/index.html) | Orin/JetPack 6.1–6.2/Humble and concrete camera timing requirements. |
| 27 | [Isaac ROS Visual SLAM release 5.0](https://nvidia-isaac-ros.github.io/v/release-5.0/repositories_and_packages/isaac_ros_visual_slam/index.html) | Confirms newer release documentation differs; avoid an unpinned install recipe. |
| 28 | [FAST-LIO](https://github.com/hku-mars/FAST_LIO) | LiDAR/inertial alternative, required inputs and calibration. |
| 29 | [slam_toolbox](https://github.com/SteveMacenski/slam_toolbox) | 2D laser mapping/localization alternative. |
| 30 | [Kalibr camera/IMU calibration](https://github.com/ethz-asl/kalibr/wiki/camera-imu-calibration) | Reproducible camera/inertial calibration procedure. |
| 31 | [AprilTag](https://github.com/AprilRobotics/apriltag) | Owned monocular-camera metric landmark experiment and controlled tracking. |
| 32 | [evo metrics](https://github.com/MichaelGrupp/evo/wiki/Metrics) | APE/RPE definitions and alignment/scale caveats. |
| 33 | [ROBOTIS XH430-V350](https://emanual.robotis.com/docs/en/dxl/x/xh430-v350/) | Encoder, velocity, current, gearing, and interface units. |
| 34 | [Bosch BMI088](https://www.bosch-sensortec.com/en/products/motion-sensors/imus/bmi088) | Target sensor specifications versus recorded sensor evidence. |
| 35 | [Arduino LSM6DS3 version 1.0.3 source](https://github.com/arduino-libraries/Arduino_LSM6DS3/blob/1.0.3/src/LSM6DS3.cpp) | Actual full-scale register setting and gyro conversion. |
| 36 | [ST LSM6DS3 reference driver](https://github.com/STMicroelectronics/lsm6ds3-pid/blob/master/lsm6ds3_reg.c) | Manufacturer's full-scale engineering-unit conversion. |

**Reproducing the numerical comparison**

From the repository root, run:

```powershell
python data/odometry_reference_review_2026-10-02/compare_odometry.py
```

The script needs NumPy and Matplotlib plus the existing rover dependencies. It writes only the comparison directory, never opens serial devices, and performs scoped geometry overrides in memory. A repeat uses the *current* source/config and original logs; consult the saved hashes before comparing across source changes. The manifest records the inputs used for the reported result. The run took place on the workspace computer, so execution times are not Jetson real-time benchmarks. Full trajectories are saved in one NPZ archive per original recording.


