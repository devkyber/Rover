# 문서 지도

현재 상태와 실행할 작업은 **[05 — 로드맵](05_한계와_로드맵.md)**에서만 갱신한다.
이 페이지는 문서를 찾는 목차다. 문서·코드의 관리 책임과 변경 절차는
[AGENTS.md](../AGENTS.md)에 있다.

## 현재 안내서

| 문서 | 관리하는 내용 |
|---|---|
| [01 — 오도메트리와 ESKF 이론](01_이론_오도메트리와_ESKF.md) | 좌표계, 수식, 관측가능성, 선택한 모델의 설명 |
| [02 — 코드 해설](02_구현_코드해설.md) | 구조, 데이터 흐름, 구현과 수식의 대응 |
| [03 — 튜닝과 NIS](03_튜닝과_NIS.md) | 튜닝 방법과 기록된 보정 근거; 실행 상수는 `rover/config.py` |
| [04 — 실행 가이드](04_실행_가이드.md) | 연결, 실행, 기록, 재생, 문제 해결 절차 |
| [05 — 현재 상태·한계·로드맵](05_한계와_로드맵.md) | 전체 프로젝트의 상태, 유일한 작업 목록, 작업 ID·의존성·완료 근거 |
| [06 — DYNAMIXEL 하드웨어](06_하드웨어.md) | 레지스터, 통신 점검, SDK 패치 설명 |
| [08 — Learn through the mechanics](08_learning_guide.md) | Python 학습 방법과 소스 지도 (English) |
| [09 — Turn-angle lesson](09_turn_angle_lesson.md) | 실행 가능한 각도 예제와 독립 회전시험 방법 (English) |
| [11 — Jetson bring-up](11_jetson_bringup.md) | 설치 절차, Jetson 설정과 날짜가 있는 시험 결과 (English) |
| [12 — Field link](12_field_link.md) | 현장 연결·복구 절차, 측정 방법, Wi-Fi 비교 근거 (English) |
| [Station](../station/README.md) / [현장 사용 설명서](../station/web/manual.html) | 소프트웨어 조작·기록·인계 절차의 원본은 manual.html. README는 개발 진입점 |
| [Pico firmware](../firmware/pico/README.md) | 펌웨어 설치, PWM/배터리 벤치 절차, 고장 시 동작 |
| [PDB 연결 문서](electronics/PDB_Design_Handover.md) | 현행 PCB 저장소의 설계/BOM/배선 문서 연결과 소프트웨어 접점 |
| [구매 기록](electronics/Purchase_List.md) | 보드 외 물품의 구매·보유 근거; PCB BOM은 별도 복사하지 않음 |

## 실험과 학습 기록

| 위치 | 보존하는 내용 |
|---|---|
| [logs/](../logs/README.md) | 원본 주행 CSV, 기록별 구성, 실측 기준점과 정답의 한계 |
| [data/](../data/README.md) | 분석 방법, 결과, manifest와 원본 링크 측정 |
| [07 — 실패 기록](07_실패기록.md) | 원인과 재발 방지. 같은 원인의 새 증거는 기존 항목에 추가 |
| [Odometry review, 2026-10-02](reviews/Odometry_Reference_Review_2026-10-02.md) | 그날의 문헌·16개 로그 비교와 실험 제안 |
| [Code review, 2026-09-17](reviews/code_review_2026-09-17.md) | 이전 구현의 검토·재현·검증 기록 |
| [91 — 제출 기술제안서](91_KSRC_기술제안서.md) | 제출 당시 요구와 계획. 기능 구현·부품 변경의 현재 상태가 아님 |
| [SDK patches](../rover/vendor/PATCHES.md) | 업스트림 업데이트 때 보존할 로컬 변경 |

검토 기록의 “미완료”는 **그 검토 시점**의 판정이다. 현재 처리 여부는 같은
주제의 로드맵 항목에서 확인한다. 예전 수치에 새 모델의 수치를 덮어쓰지 않는다.

## 구형 자료

- [90 — 초기 설계 노트](archive/90_설계노트_아카이브.md)
- [99 — Jetson Nano 카메라 노트](archive/99_카메라_노트.md)
- [이전 PDB 설계안](archive/PDB_Design_Handover_legacy.md)
- [이전 구매 검토와 LM73606 BOM](archive/Purchase_List_legacy.md)

이 자료들은 당시 결정 이유를 보존한다. 현재 배선·구매·작업 목록으로 사용하지 않는다.

## 빠른 참조

| 궁금한 것 | 위치 |
|---|---|
| 다음 작업 | [05 §3](05_한계와_로드맵.md#3-remaining-work--update-these-entries-not-copied-lists) |
| yaw 표류와 위치 한계 | [05 §1](05_한계와_로드맵.md#1-fundamental-limitations), [01 §9](01_이론_오도메트리와_ESKF.md) |
| 모터 정지·고장 처리 | [SAFE-01](05_한계와_로드맵.md#safe-01), [Station](../station/README.md) |
| 회전 정확도 검증 | [ODOM-03](05_한계와_로드맵.md#odom-03), [09](09_turn_angle_lesson.md) |
| 새로운 사실을 어디에 적나 | [유지 규칙](../AGENTS.md), `python tools/check_docs.py` |
