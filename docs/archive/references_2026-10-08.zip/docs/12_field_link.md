# 12 — Field link: router, range test, Wi-Fi card

How the rover and the station laptop are meant to be connected on the field, how to
measure whether that link is good enough, and whether the Wi-Fi card needs changing.
Written 2026-10-05.

Related: [11 — Jetson bring-up](11_jetson_bringup.md) · [Purchase list](electronics/Purchase_List.md)

This guide owns the link setup, measurement procedure and dated results. Active
work is tracked in [FIELD-01](05_한계와_로드맵.md#field-01) and
[FIELD-02](05_한계와_로드맵.md#field-02).

**Later evidence:** the [2026-10-08 AX210 bench report](../data/ax210_bench_2026-10-08/REPORT.md)
records the first test with the Intel card physically installed, on home Wi-Fi.
For using that installation, see [§4.5](#45-using-the-installed-ax210).
The configuration below describes the earlier stock-card session; use the roadmap
links above for current qualification status.

**Recorded configuration and results, 2026-10-05.** The AX3000Q is unboxed and connected to the laptop over a
1 Gbit/s Ethernet link. Firmware: **15.32.6**. Its DHCP pool was applied and verified
as **192.168.0.100–199**; the laptop renewed from `.2` to **`.100`**. The user chose to
keep the current 5 GHz channel/width for the first test (§2). There is still no field
router **10 m** measurement. The first **30 s desk test passed**: 29.8 fps at
10.0 Mbit/s, longest video gap 44.1 ms, ping 1.6 ms median / 13.4 ms worst, and no
unanswered pings or reconnects. Router and rover were close together; distance was
not measured. The CSV contains this result and the earlier home-network baseline.

The Jetson is connected to **`rover-5G` at `192.168.0.200/24`**, using its saved
`rover-field` profile. The stock RTL8822CE negotiated **channel 36 / 80 MHz** while
the router remains configured for **160 MHz**. Power saving is disabled; the profile
has autoconnect enabled at priority 10. **Intel `iwlwifi` and `iwlmvm` modules have
now been built from R36.4.4 source, installed and loaded on `5.15.148-tegra` (§4.4).**
The stock card and original shared Wi-Fi modules remain in use. No AX210 hardware
test or OS upgrade has occurred. A second desk test after installation also passed.

Home profile `poweron` (`192.168.50.243`) is preserved. USB SSH failed during setup
and the Windows USB adapter had a `169.254.*` address. For this switch, a two-minute
NetworkManager return-home timer was armed before leaving home Wi-Fi, then cancelled
after SSH through `.200` succeeded. USB subsequently obtained `192.168.55.100` and
several SSH attempts succeeded, but failures recurred and the Jetson logged USB NCM
`Wrong NTH SIGN` errors. Use a verified wired LAN connection before a card swap;
USB is not yet reliable recovery.

**User requirement:** at least **10 m**, including the rover facing away and occasional
loss of clear line of sight. The exact obstructions still need identifying on site.
Test these conditions directly; neither a card specification nor a short test can
guarantee zero wireless outages.

---

## 1. Measured on the Jetson, 2026-10-05

| Item | Value | How |
|---|---|---|
| Wi-Fi card | Realtek RTL8822CE (Wi-Fi 5, 2 antennas), driver `rtl8822ce` v5.14.0.4 | `lspci -nnk`, `modinfo` |
| Link on the home router | 5180 MHz (channel 36), 80 MHz wide, 702 Mbit/s down, 351 Mbit/s up | `iw dev wlP1p1s0 link` |
| Signal | −46 to −48 dBm | `/proc/net/wireless` |
| Transmit power reported | 13 dBm | `iw dev wlP1p1s0 info` |
| Country setting | `00` (none); the driver's `rtw_country_code` option is unset | `iw reg get`, `/sys/module/rtl8822ce/parameters` |
| Intel Wi-Fi driver | Initially absent (`CONFIG_IWLWIFI` disabled). Two matching external Intel modules subsequently installed and loaded; AX210 hardware remains untested | `/proc/config.gz`, `modinfo`, `lsmod`; §4.4 |
| AX210 firmware files | present (`iwlwifi-ty-a0-gf-a0-59` … `-86.ucode`) | `/lib/firmware` |
| `backport-iwlwifi-dkms` | available from apt (11510-0ubuntu1~22.04.3), not installed | `apt-cache policy` |

---

## 2. Router setup (ipTIME AX3000Q)

The router is the station's side of the link: laptop by cable, rover by 5 GHz Wi-Fi.
It needs no internet. Use its supplied power adapter for the bench setup.
Keep the laptop's home Wi-Fi connected for internet while configuring the field LAN.

### 2.1 Recorded configuration, 2026-10-05

The initial values below come from the user's setup screenshots. The firmware, WAN
disconnection and applied DHCP pool were also checked in the live administration UI.
Passwords and credential-bearing screenshots are not copied into the versioned docs.

| Item | Recorded value / action |
|---|---|
| Model / firmware | ipTIME AX3000Q / 15.32.6 |
| Admin page | `http://192.168.0.1/ui/` |
| Time zone | GMT+09:00 Seoul, Tokyo |
| WAN | Dynamic IP / DHCP; WAN port disconnected, as intended for this field LAN |
| LAN | `192.168.0.1`, mask `255.255.255.0`; HUB/AP Mode Gateway unchecked |
| 5 GHz | On; SSID **`rover-5G`** (case-sensitive); broadcast on; WPA2PSK + AES; Enterprise unchecked; Access: Allow All Network |
| 5 GHz channel / width | Screenshot: primary **36**, **160 MHz**. An initial `Activating (DFS Searching)` countdown completed. **Left unchanged at the user's request**; no 80 MHz or channel-149 change was applied |
| 2.4 GHz | On; SSID **`rover-2G`**; broadcast on; WPA2PSK + AES; Access: Allow All Network; Auto channel, then operating on channel 2 / 40 MHz in the screenshot |
| DHCP | Running; **Manual** pool **192.168.0.100–192.168.0.199**, applied by the assistant and confirmed by the router's Status Summary |
| DHCP options | Collision-stop, allocated-address-only and reserved-address-only boxes unchecked; subnet, gateway and DNS overrides left automatic; lease time 2 hours |
| Laptop | Windows `Ethernet 7`, Realtek USB GbE, 1 Gbit/s. New DHCP address **192.168.0.100** confirmed after renewal |
| Rover | Connected at static **192.168.0.200/24**, outside the DHCP pool; `rover-field` profile, stock RTL8822CE, negotiated channel 36 / 80 MHz |

The user's edited DHCP screenshot initially showed the intended pool, while the live
router summary still showed `.2–.254`. The change was then applied in **Advanced Setup
→ Network → DHCP Server Setup**. Applying it briefly dropped the management session.
`ipconfig /renew "Ethernet 7"` reported a transient Windows error, but a subsequent
address check confirmed `.100` and the router summary confirmed the new pool.

[Screenshot of the applied DHCP range](assets/field_link/dhcp_2026-10-05.jpg).

No changes are needed to timezone, WAN DHCP, LAN subnet, WPA2/AES, or Allow All Network
for this setup. Keep both SSIDs separate. There is no need to enable port forwarding,
DMZ, a guest network, or a reserved-address-only restriction for the local rover link.

**Bandwidth decision:** the DFS startup countdown is temporary, not evidence of an
ongoing failure. A 160 MHz channel with primary 36 spans channels 36–64, including DFS
spectrum; finishing the startup check does not remove later radar-detection behavior.
However, the user explicitly chose to keep the current setting and measure it first.
Treat 80 MHz and channel 149 as later comparison options, not changes already made or
mandatory steps. §2.3 retains the regulatory background.

### 2.2 Setup / recovery procedure

| # | Step | Setting |
|---:|---|---|
| 1 | Laptop → router **LAN** port by cable (ipTIME U1G-C + CAT6). Power the router | Leave WAN empty |
| 2 | Open `http://192.168.0.1` and log in. Set an administrator name and password | Keep them with the other credentials, outside git |
| 3 | Basic Setup → WiFi Setup, 5 GHz | Actual name: **`rover-5G`**. 인증 및 암호화: **WPA2PSK + AES**. Use the configured password |
| 4 | Channel and bandwidth | Current baseline: **36 / 160 MHz**, retained at the user's request. Allow 802.11ac clients; do not select ax-only mode. 149 / 80 MHz is a later comparison option |
| 5 | Same page, 2.4 GHz | Off, or a different name. The rover is pinned to 5 GHz either way |
| 6 | 내부 네트워크 설정 and DHCP 서버 설정 (older UI: under 고급 설정 → 네트워크 관리) | Router `192.168.0.1`, mask `255.255.255.0`. Suggested DHCP pool `.100`–`.199`, so static `.200` stays outside it |
| 7 | Use the main Wi-Fi network | No guest/client isolation: the Wi-Fi rover must be reachable from the wired laptop |
| 8 | On the laptop | `ssh rover-usb` — verify this recovery connection before switching Wi-Fi |
| 9 | In that Jetson shell | `bash ~/Rover/jetson/wifi_field.sh "rover-5G"` (prompts for the password and saves the profile) |
| 10 | In the same USB shell | `sudo nmcli connection up rover-field` — explicitly switches Wi-Fi |
| 11 | Verify | `nmcli -t -f DEVICE,STATE,CONNECTION device` and `iw dev wlP1p1s0 link`; then `ssh taeholee@192.168.0.200` from the cabled laptop |

The rover's address is **192.168.0.200**, set on the Jetson (the reason is in the head of
[`jetson/wifi_field.sh`](../jetson/wifi_field.sh)). The profile is not tied to the
current card's interface name or MAC address. When both networks are available at
boot/reconnection, its higher priority prefers the field router. **An already active
home connection is not replaced automatically** just because the field router appears
([NetworkManager](https://www.networkmanager.dev/docs/api/latest/settings-connection.html)).
After switching, `ssh rover` still names the home address; use `.200` for the field link.
To return home, use the USB shell and `sudo nmcli connection up poweron` (the home
profile name observed on this Jetson; list profiles first if it has changed).

Enter the Wi-Fi key exactly, including any whitespace. The current key includes a
trailing space that is not apparent in the screenshots. The script uses `IFS= read`
to preserve it and `psk-flags 0` to save a system secret that can be used without a
desktop password agent. The exact key was verified after reloading the saved profile;
neither the key nor the administrator password is recorded here. NetworkManager's
[Wi-Fi security settings](https://www.networkmanager.dev/docs/api/latest/settings-802-11-wireless-security.html)
describe its PSK and secret flags.

Sources: ipTIME's [current setup guide](https://www.iptime.com/support/faq/25921),
[channel guide](https://www.iptime.com/support/faq/19429), and
[firmware notes naming the DHCP menus](https://www.iptime.com/support/downloads/27063).
These are manufacturer-wide references. The live 15.32.6 UI confirmed **Basic Setup →
WiFi Setup** and **Advanced Setup → Network → DHCP Server Setup**. The `nmcli` setting names were checked against the Jetson's own
NetworkManager (1.36.6). The script now updates an existing profile in place, without
deleting an active connection.

If Windows loses internet after connecting Ethernet, check its default route: the
offline router may take priority over home Wi-Fi. Keep `192.168.0.0/24` on Ethernet
and prefer home Wi-Fi for the default route. Do not change the home's router settings.

### 2.3 Channel 149 / 80 MHz as a later comparison

[11](11_jetson_bringup.md) planned channels 36–48. The Linux regulatory database
([wireless-regdb](https://kernel.googlesource.com/pub/scm/linux/kernel/git/wens/wireless-regdb/+/refs/heads/master/db.txt),
which cites the Korean notices on law.go.kr) has this for Korea:

```
country KR: DFS-JP
	(5150 - 5230 @ 40), (23), AUTO-BW
	# max. PSD 2.5 mW/MHz in 5230-5250 MHz frequency range
	(5230 - 5250 @ 20), (17), AUTO-BW
	(5250 - 5350 @ 80), (20), DFS, AUTO-BW
	(5470 - 5725 @ 160), (20), DFS
	(5725 - 5850 @ 80), (23)
```

- **Channels 149–161** (5725–5850 MHz): 23 dBm across a full 80 MHz, no radar rule.
- **Channels 36–48** (5150–5250 MHz): the top 20 MHz (channel 48) has a separate 17 dBm
  rule. A lower-band 80 MHz channel spans both regulatory entries.
- **Channels 52–144**: marked DFS. A router there must go silent if it thinks it hears
  radar. Not for a rover.

This 5 GHz excerpt was rechecked against upstream wireless-regdb on 2026-10-05.
It describes Linux's regulatory limits, not measured output or a guaranteed 6 dB
advantage for this router. The Realtek driver currently reports a self-managed `00`
domain and 13 dBm; it does not prove that the router or client uses the database's
maximum. Keep the devices' Korea settings and certified power limits. Channel 149 is
a later comparison candidate; the first test keeps the user's current 36 / 160 MHz.
**Not known:** whether the competition assigns channels to teams. Ask the organisers.

---

## 3. Range test

For a stationary radio test, close other station pages and finish any existing rover
session first. Open `ssh rover-usb`, then run this in the Jetson shell:

```bash
cd ~/Rover/rover
~/rover-venv/bin/python rover_main.py --no-motors --imu fake --pico off --no-log
```

This uses the real camera and radio without opening motors, a real IMU, or the Pico.
Leave it running. On the laptop, from the repository root:

```bash
python station/link_test.py 192.168.0.200 --seconds 30 --label "AX3000Q; RTL8822CE; AP ch36 160MHz; bench distance unmeasured; orientation unrecorded"
```

The example label uses the router's present width; record the **negotiated client
width** from `iw dev wlP1p1s0 link`/`iw dev` as well, since these may differ. Replace
the distance/orientation labels with actual measurements for the 10 m tests.

It opens the same two connections as the station page, listens for 30 s, and adds one
row to [`data/link_tests.csv`](../data/link_tests.csv). It sends application pings, no
drive commands. That alone would not stop a different connected station from driving;
the `--no-motors --pico off` test setup avoids that. Move the rover, change the label,
run again. Press Ctrl+C in the Jetson shell when done.

**Screening result:** `PASS` requires telemetry, video and ping replies; no reconnects;
no telemetry/video gap or ping round trip above 500 ms; and no ping still unanswered
after 500 ms. `INCOMPLETE` means a required stream/reply was missing or had too few
samples. Exit codes are 0 for pass, 1 for incomplete, 2 for fail. Every completed test
is saved, including failures, unless `--no-csv` is used.

The 500 ms threshold borrows the value of `COMMAND_TIMEOUT_S`; it is a conservative
link screen, **not a motor-deadman test**. Round-trip ping cannot establish one-way
command delay, and incoming H.264 frames do not establish decoded-picture latency.
Startup waiting for the first message/keyframe is excluded from gap statistics.
Silence after the last message, up to the test end, is included (fixed 2026-10-05).
Expect roughly 30 fps and 10 Mbit/s with this camera, as well as 20 Hz telemetry.
Inspect the picture separately with the station page after the numeric test; opening
both together adds a second video stream and changes the load.

Baseline, so later rows have something to be compared with:

| Where | Wi-Fi at rover | Telemetry | Longest telemetry gap | Ping median / longest | Video | Longest video gap |
|---|---:|---:|---:|---:|---:|---:|
| Home router, channel 36, 80 MHz, stock card (2026-10-05) | −48 dBm | 20.0 /s | 58 ms | 3.6 / 13.3 ms | 29.9 fps, 10.0 Mbit/s | 53 ms |
| AX3000Q, close together on desk, AP channel 36 / 160 MHz, stock card at 80 MHz (2026-10-05 02:02 KST) | −26 dBm | 20.0 /s | 66 ms | 1.6 / 13.4 ms | 29.8 fps, 10.0 Mbit/s | 44 ms |

The field-router desk row passed the 30 s link screen with **0/150 unanswered pings**
and **0 reconnects**. Weakest reported signal was −28 dBm. The real camera supplied
1920×1080 H.264 with motors disabled, fake IMU and Pico off. This establishes that
the wired-laptop → router → Wi-Fi-rover setup works under camera load at the desk;
it does not establish the required 10 m reliability or motor-stop behavior.

After the numeric test, the station page at
`http://localhost:8765/?rover=192.168.0.200` connected and reported 30 decoded fps,
20 Hz telemetry, motors OFF and servos OFF. The preview was black with no browser
errors; checking whether the lens is covered or faces the desk is still pending.
Do not count this as a verified usable camera picture.
[Station status screenshot](assets/field_link/station_desk_2026-10-05.jpg).

Field measurement protocol (completion is tracked in FIELD-01):

1. Establish a close-range baseline for 30 s at full camera throughput, recording
   distance and configuration. The 2026-10-05 desk result above has no measured distance.
2. **10 m**, 60 s each at 0°, 90°, 180° and 270°. Repeat at the actual obstructed
   positions; record what blocks the path. Put antennas where they will sit on the
   finished chassis, rather than evaluating a bare board alone.
3. If the current baseline is weak, compare 80 MHz at channel 36, channel 149 / 80 MHz,
   and then 40 MHz, changing one setting at a
   time. Place the router above ground with a clear path where possible; keep rover
   antennas clear of metal, battery and electronics.
4. At the worst 10 m position, repeat three times and run a **15-minute** check
   (`--seconds 900`), including the expected turns/obstructions. Check 15–20 m as
   additional margin where space allows. A single 30 s success is not a range guarantee.
5. Separately verify the visible picture and deliberate link-loss/stop/reconnection
   behavior in a controlled driving test. The passive screen does not certify that.

`wifi dBm` is how well the **rover hears the router**. The video travels the other way,
and the Jetson reports only 13 dBm of transmit power, so video can fail while this
number still looks fine. The video columns are the test of that direction.

Not tried, listed so it is not forgotten: the Realtek driver has a country option
(`rtw_country_code`), currently unset. Whether setting `KR` raises its transmit power is
unknown.

### 3.1 Estimating 10 m while portable power is unavailable

At the 2026-10-05 desk test, portable power was unavailable. A stationary alternative is to
leave the Jetson on its normal desk supply and move the **router and laptop** to
another outlet 10 m away, keeping their Ethernet connection. An AC extension for
the normal router adapter is another option. The 15–20 m CAT6 cable listed in the
purchase plan could let the laptop stay at the desk. This tests radio separation;
the final chassis, antenna orientation and moving/obstructed cases still need testing.

**Engineering estimate, not a measured range:** free-space loss at channel 36
(5.18 GHz) and 10 m is about **66.7 dB**. Using the Jetson's reported 13 dBm transmit
power and assuming zero net antenna gain/cable loss gives about **−53.7 dBm at the
router** for the video uplink. This ideal calculation excludes obstructions,
antenna nulls, ground reflections, interference and driver interruptions; reported
transmit power has not been checked with RF equipment. It supports treating 10 m
with clear visibility as plausible, not promising uninterrupted 10 m operation.
The desk separation was unmeasured, so its −26 dBm is not a calibrated range model.
Formula reference: [Cisco's free-space propagation explanation](https://www.cisco.com/c/dam/m/cs_cz/training-events/webinars/tech-club-webinars/techclub-en-cisco-live-fy22q4.pdf).

Online evidence for the stock **RTL8822CE**, checked 2026-10-05:

| First-hand report | Relevance to this rover |
|---|---|
| [NVIDIA forum, May 2026](https://forums.developer.nvidia.com/t/slow-wi-fi-on-orin-nano-devkit-rtl8822ce-802-11ac/368697): user measured ~120 Mbit/s in 5 GHz AP mode; NVIDIA staff reproduced AP-mode slowness but reported good throughput in client mode | Our Jetson is already a client of the AX3000Q. This report gives no controlled range or latency result |
| [Robot builder, August 2026](https://forums.developer.nvidia.com/t/my-experience-with-wifi-adapters-on-orin-nano-rtl8822ce-vs-qcnfa765/381849): reported 15 Mbit/s video freezes even at 1 m on JetPack 7.2; replacing RTL8822CE with QCNFA765 resolved their problem | A real caution about that setup, not a distance limit or an AX210 comparison. Our 10 Mbit/s desk test did not show those freezes |

No comparable controlled **10 m, obstructed, Orin Nano + AX3000Q** result was found.
Forum reports establish possible failure modes, not failure rates. Our result is
evidence for this individual setup, but neither stock nor AX210 has been established
as reliable at the required distance.

---

## 4. AX210: driver preparation and hardware comparison

**Decision for this setup: keep the stock card for the router baseline.** There is no
AX210 installation validated on this particular Jetson yet. The original JetPack
kernel configuration did not supply the Intel driver; matching external modules
were subsequently installed and loaded (§4.4). Hardware initialization and radio
performance still require the card. The earlier route investigation follows:

| Route | Report | Outcome |
|---|---|---|
| `sudo apt install backport-iwlwifi-dkms` | [NVIDIA forum, JetPack 6.0, June 2024](https://forums.developer.nvidia.com/t/jetpack-6-wifi-slow-startup-with-backport-iwlwifi-dkms/297967) | Works, but Wi-Fi comes up 73 s after boot. Others in the thread got ~10 s by building a newer backport from source and adding `iwlwifi` to the initramfs |
| `iwlwifi-modules` from apt | [Seeed forum, JetPack 6.2, March 2025](https://forum.seeedstudio.com/t/no-iwlwifi-intel-wifi-support-on-jetpack-6-2/291415) | Failed: `cfg80211: Unknown symbol rfkill_…`. The moderator's fix did not work |
| Several routes including a kernel rebuild | [NVIDIA forum, JetPack 6.0, Sept 2025](https://forums.developer.nvidia.com/t/ax210-iwlwifi-not-working-microcode-sw-error-detected-restarting-0x0/346168) | Never worked: `Microcode SW error detected`. No resolution in the thread |
| Build `iwlwifi` from NVIDIA's kernel source | [NVIDIA forum, JetPack 6.2.1, Aug–Sept 2025](https://forums.developer.nvidia.com/t/ax210-on-orin-nano-jetpack-6-2-1-kernel-5-15-iwlwifi-loads-but-802-11k-v-r-fast-roaming-capabilities-are-missing/341173) | Author reports basic Wi-Fi working on 5.15.148, with unresolved roaming concerns. A second user in another thread reports success with a custom kernel |

NVIDIA staff answer each of these the same way: enable the driver and rebuild the kernel
yourself ([example](https://forums.developer.nvidia.com/t/unable-to-setup-intel-ax210-with-jetpack-6-2/336368)).
The table includes a same-release basic-connectivity success report using NVIDIA's
kernel source; it is not validation of this rover or proof of better range. A roaming
problem with several access points does not by itself block this one-router setup.
The matching-source modules have now been built, installed and loaded on this
Jetson (§4.4); operation with the AX210 card remains untested.

### 4.1 Does this require a newer JetPack?

Not merely to obtain AX210 support: upstream
[iwlwifi lists AX210 support since Linux 5.10](https://wireless.docs.kernel.org/en/latest/en/users/drivers/iwlwifi.html).
The observed problem on our 5.15 kernel is that the driver was not enabled. That does
not guarantee a successful build or reliable operation, but it makes a matching
R36.4.4 module build a reasonable first experiment if an AX210 trial becomes useful.
[NVIDIA's R36.4.4 kernel guide](https://docs.nvidia.com/jetson/archives/r36.4.4/DeveloperGuide/SD/Kernel/KernelCustomization.html)
is the source/build reference, not an AX210 installation recipe.

Do not change the OS for the first router test. A JetPack migration is a separate
decision requiring verification of the target release, installation method, backups,
and camera/control-stack compatibility. Earlier notes about a specific JetPack 7
reinstall route were not tested on this machine and are not prerequisites here.

### 4.2 What building the driver on this JetPack needs

Pre-build inventory on the Jetson, 2026-10-05; subsequent work is recorded in §4.4:

| Needed | State |
|---|---|
| Compiler and build tools | present (`gcc` 11.4, `make`, `bc`, `flex`, `bison`) |
| Kernel headers and symbol table for the running kernel | present (`nvidia-l4t-kernel-headers`, `Module.symvers`) |
| Wi-Fi base modules the driver plugs into | present (`cfg80211`, `mac80211`) |
| Card firmware | present |
| The driver's source code | Initially absent from the headers package. Both Ubuntu's backport source and NVIDIA's R36.4.4 `public_sources.tbz2` (226 MB) were subsequently downloaded for isolated builds; see §4.4 |
| Disk space | 199 GB free |

A build in a separate directory can run without root. Installation needs root and
must be planned after checking the built modules, matching kernel version/symbols,
firmware and dependencies. Do not describe it as a guaranteed one-command fix.
Prefer adding only the required Intel modules to the existing kernel; replacing
shared Wi-Fi modules or installing backports also needs a tested rollback plan.

**What the swap would and would not buy** (my assessment, not from a source):

- The stock card already links at 351–702 Mbit/s; video needs 10. Speed is not the limit.
- Both cards use two antenna connections. Actual usable range also depends on radio
  sensitivity, interference, antennas and placement; Wi-Fi 6 alone does not guarantee
  improvement. Use the same compatible antennas and placement for a card-only A/B
  test, or label an antenna change as a separate variable.
- The AX210's extra band (6 GHz) needs a 6 GHz router, which the AX3000Q is not, and
  is marked indoor-only for Korea in the database above.

**Decide by measurement.** No source found compares the two cards' range or transmit
power on this rover, so compare [`link_test.py`](../station/link_test.py) at the same
spot, orientation, channel, width and camera load with each card. First establish the
stock card's result with the AX3000Q. If it passes repeatedly at the required distance,
keep it for operation. If it fails, compare placement/channel/width before attributing
the problem to the card. An AX210 trial becomes useful if performance remains
insufficient, or if there is time for a controlled comparison. Require repeatable
video/control results and reliable reconnection/cold boots before adopting it.

**Two things to plan for before a card swap:**

1. The Jetson has no Wi-Fi from the moment the card comes out until the driver works.
   First verify an independent wired/USB SSH connection. USB SSH has been
   intermittent during this session; plugging in the cable alone is not sufficient.
2. The backport package installs its own copies of the kernel's shared Wi-Fi modules.
   The compiled Ubuntu 11510 package was checked against this Realtek module:
   three required symbols are missing and 27 have different version CRCs (§4.4).
   If that package is used, restoring the original shared modules is necessary
   before returning to the stock card. The Intel-only NVIDIA-source build avoids
   that replacement.

### 4.3 AX210 feasibility and stability work, checked 2026-10-05

The user's later "AX120" reference is interpreted as the **AX210NGW** in the purchase
list. The task would be building and integrating the existing Intel Linux driver,
not writing a new radio driver. Equal or better stability is possible, but compiling
a driver does not establish it; an AX210 hardware test is still required. A short
desk result also does not establish long-term stock-card stability.

Read-only checks on the running Jetson confirmed:

- `5.15.148-tegra`, R36.4.4; `CONFIG_IWLWIFI` disabled.
- `cfg80211`, `mac80211` and `libarc4` module files present; RFKILL and device-coredump
  support built in. `mac80211` is available, though the Realtek driver does not
  currently load it.
- Matching headers and `Module.symvers` present; `CONFIG_MODVERSIONS=y`. Runtime
  module signature enforcement reports `N`.
- AX210 `ty-a0-gf-a0-*.ucode` firmware and `iwlwifi-ty-a0-gf-a0.pnvm` present.
  This checks availability, not successful firmware loading on the absent card.
- GCC 11.4 available; the running kernel identifies its build compiler as GCC 11.3.
  Intel source files are absent from the headers package.
- `rover-field` is independent of interface name/MAC, uses static `.200`, 5 GHz and
  disabled NetworkManager power saving, so those settings can survive a card swap.

| Possible problem | Evidence / response |
|---|---|
| Driver cannot load: wrong kernel version or symbol CRC | Build `iwlwifi` and `iwlmvm` against the exact R36.4.4 configuration/headers and symbol table. Check dependencies and version information before installation. `modules_prepare` alone does not generate `Module.symvers` ([kernel build documentation](https://docs.kernel.org/kbuild/modules.html)) |
| A backport replaces shared wireless modules and breaks stock-card rollback | First attempt a build of the Intel modules that uses the existing wireless core. Install into a separate, recorded location only after compatibility checks; preserve stock modules and package versions. If a newer shared stack becomes necessary, treat that as a separate change |
| Firmware fails, crashes or repeatedly resets | Record requested/loaded firmware and PNVM plus kernel errors. Use the versions supported by that driver. A [JetPack 6.0 report](https://forums.developer.nvidia.com/t/ax210-iwlwifi-not-working-microcode-sw-error-detected-restarting-0x0/346168) failed despite several approaches. The same-release success report is encouraging but not a guarantee |
| Wi-Fi appears late at boot | A [JetPack 6 backport report](https://forums.developer.nvidia.com/t/jetpack-6-wifi-slow-startup-with-backport-iwlwifi-dkms/297967) took 73 s; other users reduced it with different builds/early loading. Measure boot logs, firmware availability and module loading before applying an initramfs change |
| Idle/power-saving stalls | Preserve the profile's disabled power saving. If logs and repeatable tests implicate Intel power management, investigate `iwlmvm`'s `power_scheme=1`; do not apply a blanket PCIe setting based on an unrelated report. [Intel driver documentation](https://wireless.docs.kernel.org/en/latest/en/users/drivers/iwlwifi.html#about-platform-noise) describes this diagnostic option |
| Association changes after swap | Verify the new interface uses `rover-field`, the exact saved PSK and `.200`; the profile is already free of the old card's name/MAC. Keep a working wired or USB SSH path during setup |
| Good desk behavior but poor field link | Inspect both compatible antenna connections and placement. Compare the same channel, actual bandwidth, antennas where compatible, and camera load. Software cannot remove physical shadowing or guarantee a clear channel |
| A later kernel update leaves the custom modules behind | Keep source/config/build logs and an install/removal manifest; rebuild and repeat validation for the new kernel before adopting it |

After checking the Ubuntu backport, the narrower build uses NVIDIA's **matching
release source** and the existing kernel, with the Intel MVM driver enabled; AX210
does not need the older DVM driver. Build results are recorded in §4.4.
See [NVIDIA's build reference](https://docs.nvidia.com/jetson/archives/r36.4.4/DeveloperGuide/SD/Kernel/KernelCustomization.html)
and [upstream 5.15 Intel configuration](https://raw.githubusercontent.com/torvalds/linux/v5.15/drivers/net/wireless/intel/iwlwifi/Kconfig).
Review the generated configuration and unresolved symbols before deciding whether
the Intel modules alone are sufficient. Do not replace the boot kernel merely to
get past a build error.

An `api flags ... larger than supported` warning alone does not prove a fatal
firmware mismatch: working reports also contain it. Repeated firmware resets,
failed initialization and measured dropouts are the actionable evidence. Likewise,
the roaming report is not a controlled demonstration of which layer lacks each
802.11k/v/r feature. This rover currently uses one access point, so multi-AP roaming
is not an acceptance requirement. Neither 6 GHz nor Bluetooth is required here.

**Proposed acceptance:** compare stock and AX210 under the same sustained camera
load for at least 30–60 minutes, recording latency tails, gaps, reconnects and kernel
errors; repeat cold boots and deliberate AP-loss/recovery with wired access ready.
An initial target is ten successful boot/reconnection cycles and no unexplained
firmware resets or link-screen failures. Then repeat the 10 m orientation and
obstruction tests in §3. These are practical qualification checks, not proof of
zero future failures. Desk driver work can proceed before portable power is ready;
range and final adoption still depend on physical testing.

### 4.4 Existing repositories and the driver trial, 2026-10-05

**Historical build record:** the firmware/hardware checks below describe
2026-10-05, before the card swap. The [2026-10-08 hardware report](../data/ax210_bench_2026-10-08/REPORT.md)
records successful firmware loading, association and video with AX210 installed.

There is an [official Intel integration repository](https://github.com/intel/Intel-wireless).
Its [Jetson guide](https://intel.github.io/Intel-wireless/platforms/jetson/) recommends
Ubuntu's `backport-iwlwifi-dkms` for JetPack 5/6, and links to the upstream driver
source as an alternative. The [Ubuntu guide](https://intel.github.io/Intel-wireless/platforms/canonical-ubuntu/)
explains DKMS rebuilding after kernel updates. This is an existing driver integration
task; neither writing a radio driver nor upgrading JetPack is required to attempt it.
On this Jetson, use the existing **Tegra** headers and symbol table, rather than
blindly installing the guide's generic Ubuntu kernel headers.

Other repository instructions are not interchangeable: the
[Seeed JetPack 7.2 guide](https://github.com/Seeed-Studio/wiki-documents/blob/docusaurus-version/sites/en/docs/Edge/NVIDIA_Jetson/FAQs/JetPack72_AX210_AX200_WiFi_Setup_Guide.md)
targets a different kernel, while
[jetsonhacks/buildJetsonModules](https://github.com/jetsonhacks/buildJetsonModules)
is an archived TK1-era project. Their prebuilt modules are not candidates for this
`5.15.148-tegra` kernel.

**Ubuntu backport experiment — built, not installed.** Downloaded the official
Jammy package `backport-iwlwifi-dkms_11510-0ubuntu1~22.04.3_all.deb`, verified its
SHA-256 against the Jetson's apt metadata, extracted it without installing, and
compiled it with two jobs at reduced priority. The build succeeded. Its DKMS
manifest includes replacement `cfg80211` and `mac80211` modules, alongside the
Intel modules. Comparing its exports with the installed Realtek driver's imports
found **3 missing symbols and 27 different CRCs among 31 shared-core imports**.
That Realtek binary cannot use this replacement core normally. The package was
therefore left in its isolated build directory; no DKMS package or backport module
was installed. This does not establish whether the package would work well with
AX210, only that returning to the stock card would require restoring the original
Wi-Fi core. [Recorded checks](assets/field_link/ax210_backport_verification_2026-10-05.json).

**Matching NVIDIA source — built, installed and loaded.** Downloaded
[`public_sources.tbz2` for R36.4.4](https://developer.nvidia.com/embedded/jetson-linux-r3644),
verified its embedded `kernel_src.tbz2` checksum, and extracted only the Intel
driver source. The source identifies Linux 5.15.148. Built `iwlwifi` and `iwlmvm`
as external modules against the installed Tegra headers and `Module.symvers`,
with MVM, modular opmode and debug support enabled. The external build supplies
the Intel configuration defines and include path; installed headers and driver
source files were not patched. No full kernel rebuild was needed because the
matching headers already include the symbol table.

| Check | Result |
|---|---|
| Build | Successful; only `iwlwifi.ko` and `iwlmvm.ko` selected for installation |
| Kernel version / architecture | Both: `5.15.148-tegra SMP preempt mod_unload modversions aarch64` |
| Imported symbol checks | 172 for `iwlwifi`, 263 for `iwlmvm`; none missing or with mismatched CRCs |
| AX210 firmware | Driver advertises `iwlwifi-ty-a0-gf-a0-66.ucode`; this file and the PNVM file are present. Actual firmware loading awaits the card |
| Installation | `/lib/modules/5.15.148-tegra/extra/rover-ax210-r36.4.4/`; two modules only, followed by `depmod` |
| Loader | `modprobe iwlmvm` succeeded and loaded both Intel modules using the original shared core |
| Original files | SHA-256 checks confirmed `cfg80211.ko`, `mac80211.ko` and `rtl8822ce.ko` unchanged |
| Signature | Locally built modules are unsigned; the kernel permits loading and records the expected signature/taint message |
| Hardware | PCI still shows the RTL8822CE. No AX210 association, firmware initialization or reliability test has happened |

[Build command, source checksums and verification](assets/field_link/ax210_native_verification_2026-10-05.json).
The native source, logs, `build.sh`, `install.sh`, and a syntax-checked `remove.sh`
are retained on the Jetson at
`/home/taeholee/ax210-native-r36.4.4-1791135235640/`.
The rejected backport build is at
`/home/taeholee/ax210-build-5.15.148-11510-1791134783411/`.
The removal script checks the installed file hashes and removes only these two
Intel modules; it has **not** been executed. No shared module replacement,
Realtek blacklist, initramfs update, firmware replacement or kernel upgrade was
performed. This manual installation will need rebuilding for a future kernel.

**Stock-card check after installation:** another 30 s camera-only test passed:
30.0 fps at 9.9 Mbit/s, longest video gap 42.5 ms, median ping 1.7 ms / worst
7.9 ms, **0/149 unanswered pings and 0 reconnects**. The row is in
[`data/link_tests.csv`](../data/link_tests.csv). This verifies that the existing
desk link still works after loading the Intel modules; it does not test AX210.

The recorded stock-card desk baseline permits a bench hardware trial after wired
recovery is established; the full field comparison is required for the adoption
decision, not for the first PCI/firmware check. Update [FIELD-02](05_한계와_로드맵.md#field-02)
with the result instead of starting another Wi-Fi task list.

**Antennas for the first AX210 trial:** reuse both antenna assemblies from the stock
RTL8822CE module for the existing 5 GHz link, with the same placement. The
[AzureWave AW-CB375NF datasheet, p. 9](https://jetwaycomputer.com/spec/expansion/AW-CB375NF.pdf)
identifies MHF4 antenna sockets and the same PCI/subsystem IDs recorded for this
card. [Intel's connector specification](https://www.intel.com/content/www/us/en/support/articles/000027956/wireless.html)
describes the matching M.2 RF connector dimensions. This supports reusing the
existing leads; actual plug condition and seating still need checking during the
swap. A 5 GHz antenna does not require replacement just because the radio changes
from Wi-Fi 5 to Wi-Fi 6. Do not assume these antennas are suitable for 6 GHz.
Connect both leads, centre each plug before pressing straight down, and do not
force a misaligned connector or pull on the coax cable. Keeping the same antennas
and placement isolates the card change in the comparison.

**Card-swap procedure (FIELD-02):** connect the Jetson's Ethernet port to a spare **LAN** port
on the AX3000Q and verify SSH through its wired address. The laptop's router cable
stays connected. Then shut the Jetson down, disconnect power, swap the card and
attach both compatible antenna leads. On the next boot, check PCI detection,
loaded firmware, `rover-field` association and `.200` before the camera tests in
§4.3. Do not count on USB for recovery yet: several USB SSH attempts worked, then
failed again; the kernel logged USB NCM `Wrong NTH SIGN` errors. The exact USB
failure cause has not been established. If the AX210 trial fails, power off and
return the original card; its driver and Wi-Fi core remain installed.

### 4.5 Using the installed AX210

The [bench report](../data/ax210_bench_2026-10-08/REPORT.md) identifies the working
R36.4.4 / `5.15.148-tegra` installation and retains its source, module and firmware
hashes. Continue with that installed driver for this kernel. Do not repeat the
installation or replace JetPack just to use the card. For a future kernel change,
follow the matching-build and rollback notes in §4.4 and repeat validation.

After a restart, check the actual Wi-Fi address from the router's client list or
`ip -br address` on the Jetson. The first AX210 home-network lease was
`192.168.50.57`; the stock card's `.243` lease is not the AX210 address, and DHCP
may assign another address later. The field profile's `192.168.0.200` applies
when connected to the AX3000Q. Do not use that address for the home-network test.

The saved `rover-field` profile has autoconnect enabled with priority 10; the
home profile `poweron` has priority 0 (verified 2026-10-08). When NetworkManager
chooses a connection at boot or after a disconnect, it prefers the available
field profile. Priority does not switch an already active home connection.
Run these commands **on the Jetson**, using SSH or its local terminal:

```bash
# Switch now to rover-5G using the saved credentials and static address.
sudo nmcli connection up rover-field

# Show the active profile and assigned address.
nmcli -f NAME,DEVICE connection show --active
ip -4 -br address

# Return to the saved home Wi-Fi profile when needed.
sudo nmcli connection up poweron
```

Switching Wi-Fi drops an SSH session carried over that Wi-Fi link. Use a verified
independent connection, or reconnect through the destination network afterward.
The profile name is `rover-field`; its broadcast SSID is `rover-5G`.

The AX3000Q settings website is `http://192.168.0.1`. Connect the laptop to a
numbered **LAN** port (not WAN/Internet), or to the router's Wi-Fi, to reach it.
For the wired station arrangement, retain home Wi-Fi for internet and use the
router LAN connection for `.200`. A `169.254.*` Ethernet address means that the
laptop has not obtained the expected `192.168.0.*` lease; check the LAN port and
DHCP before diagnosing a rover failure.

On the Jetson, confirm the kernel, driver and connected radio before a run:

```bash
uname -r
lspci -nnk
iw dev
iw dev wlP1p1s0 link
iw dev wlP1p1s0 get power_save
```

Use the interface reported by `iw dev` if its name differs. For the recorded
home-network setup, launch the laptop GUI from the repository root with:

```bash
python station/station.py --rover 192.168.50.57 --port 8766
```

Replace the address with the current lease. Port 8766 was selected because an
unrelated server occupied 8765. The Jetson runtime must also be running;
[the station guide](../station/README.md) owns runtime and connection procedures.
The camera-only test's wheel/attitude values came from disabled motors and a fake
IMU, not measurements of rover motion. Its exact command is in the bench report.

Record new comparisons using §3 and keep qualification decisions in
[FIELD-02](05_한계와_로드맵.md#field-02). Keep the original card for recovery;
the installed Intel modules use the original shared Wi-Fi core. USB recovery
still needs qualification as recorded in the same task.
