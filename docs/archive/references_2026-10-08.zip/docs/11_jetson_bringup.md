# 11 — Jetson Orin Nano Super bring-up record

How the rover's Jetson was set up from a bare board using **only a Windows laptop**
(no Ubuntu PC, no monitor, no microSD), what went wrong, and why. Written 2026-10-04.

Related: [Purchase list](electronics/Purchase_List.md) · [99 — camera / Jetson notes](archive/99_카메라_노트.md)

This document owns setup procedures and dated test evidence. Current project
status and task completion are maintained in [the roadmap](05_한계와_로드맵.md).

---

## 1. Result

| Item | Value |
|---|---|
| Board | NVIDIA Jetson Orin Nano **Super** Developer Kit |
| OS | JetPack **6.2.1** (L4T R36.4.4, Ubuntu 22.04), booting from the NVMe SSD |
| Storage | 256 GB NVMe (M.2 2280 slot), no microSD |
| Hostname | `rover` |
| Full name / username | `taeholee` / `taeholee` |
| Password | Not in this repo. See `docs/jetson_credentials.local.md` (git-ignored, stays on this laptop) |
| USB-C link (intermittent in later tests) | Jetson = `192.168.55.1`, serial console on a COM port (was `COM6`), 115200 baud. Later USB networking errors are recorded in [12](12_field_link.md); verify wired LAN recovery before relying on it |
| Bootloader firmware | JetPack 6-compatible as shipped (proved by JetPack 6.2.1 booting; exact version not read) |

The USB-C login used during initial setup (subject to the later link limitation):

```bash
ssh taeholee@192.168.55.1
```

---

## 2. The procedure that worked

1. **Download** the JetPack 6.2.1 SD-card image
   (`jetson-orin-nano-devkit-super-SD-image_JP6.2.1.zip`, 10.9 GB) from
   [NVIDIA's JetPack 6.2.1 page](https://developer.nvidia.com/embedded/jetpack-sdk-621).
2. **Flash it to the SSD** in a USB-C NVMe enclosure with balenaEtcher (under 2 min on a
   10 Gbps enclosure). Cancel every Windows "format this disk" pop-up.
3. **Edit one line on the SSD** — this is the step that is easy to miss (see §3.1).
   From an **admin** PowerShell, with the SSD still in the enclosure:

   ```powershell
   Get-Disk                                   # find the SSD's number N and check it is the 232.9 GB one
   wsl --mount \\.\PHYSICALDRIVEN --partition 1 --type ext4
   ```

   Then inside WSL (as root), replace the SD-card root with the SSD partition's PARTUUID:

   ```bash
   f=/mnt/wsl/PHYSICALDRIVENp1/boot/extlinux/extlinux.conf
   cp -p $f $f.sdcard-original
   uuid=$(lsblk -no PARTUUID /dev/sdX1)       # the 21G ext4 partition
   sed -i "s#root=/dev/mmcblk0p1#root=PARTUUID=$uuid#" $f
   sync
   ```

   ```powershell
   wsl --unmount \\.\PHYSICALDRIVEN
   ```

4. **Install the SSD** in the Jetson's 2280 slot. Connect a **data-capable** USB cable
   from the Jetson's USB-C to the laptop, then the 19 V adapter.
5. After ~1–2 min Windows shows NVIDIA device `0955:7020`: a COM port, a USB network
   adapter, and a small USB drive. Open the COM port in PuTTY (serial, 115200) and
   complete the first-boot wizard (licence, language, time zone, user, hostname).
6. Log in with SSH at `192.168.55.1`, grow the root partition if it is still ~21 GB (§4),
   then run [`jetson/setup_jetson.sh`](../jetson/setup_jetson.sh).

---

## 3. What went wrong, and why

### 3.1 SD-card image on an NVMe does not boot as-is (cost: ~2 hours, 4 flashes)

**Symptom.** Board powers on, fan and LED look normal, but the laptop never sees any USB
device from it. Same with the JetPack 6.2.1 and the JetPack 5.1.3 image.

**Cause.** The SD-card image's `/boot/extlinux/extlinux.conf` hard-codes the SD card:

```
APPEND ${cbootargs} root=/dev/mmcblk0p1 rw rootwait ...
```

The firmware finds the SSD and loads the kernel from it, but the kernel then waits
(`rootwait`) for an SD card that is not there. Linux never reaches the point where it
starts the USB device mode, so nothing appears on the laptop.

**Fix.** Point `root=` at the SSD partition (§2 step 3). `/etc/fstab` needs no change —
it uses `/dev/root`.

**Why it looked like something else.** "Nothing on USB" also matches a charge-only
cable, old bootloader firmware, and a badly seated SSD. All three were suspected first.

Sources:
- [NVIDIA forum: same failure with the JP513 image on an SSD](https://forums.developer.nvidia.com/t/boot-failure-when-attempting-to-start-jetson-orin-nano-developer-kit-from-an-ssd-instead-of-a-microsd-card/367132)
- [NVIDIA forum: Etcher to SSD works after the extlinux edit](https://forums.developer.nvidia.com/t/can-i-create-a-bootable-jetpack-ssd-with-balena-etcher/371188)
- [NVIDIA forum: staff give the `root=` edit](https://forums.developer.nvidia.com/t/jetson-orin-nano-flash-microsd-image-to-nvme-ssd/287300)
- [Community guide using PARTUUID](https://forums.developer.nvidia.com/t/blog-boot-from-nvme-without-using-sdkmanager-or-external-ubuntu-pc-a-solution-that-works/252757)

### 3.2 Charge-only USB-C cable

The first cable had no data wires. Test any cable by plugging a phone into the laptop
with it: Windows must log a new USB device (Android still says "charging" until you pick
File transfer, but the device is detected).

### 3.3 `wsl --mount` and USB drives

[Microsoft's documentation](https://learn.microsoft.com/en-us/windows/wsl/wsl2-mount-disk)
says `wsl --mount` does not support USB drives. It **did work** with this enclosure
(JMicron bridge, UAS) on WSL 2.7.10. It needs an admin shell. If it fails on another
enclosure, the fallback is a microSD boot (NVIDIA's documented method).

### 3.4 Things that turned out not to be needed

- **JetPack 5.1.3 firmware stepping stone.** Only needed for boards with old (35.x)
  firmware. This Super kit shipped with JetPack 6-compatible firmware.
- **Ubuntu PC + SDK Manager.** NVIDIA staff
  [state](https://forums.developer.nvidia.com/t/sdk-manager-2-3-0-now-supports-windows11/340202)
  it cannot flash an Orin Nano from Windows; the route above avoids it.
- **Monitor and keyboard.** The first-boot wizard runs over the USB-C serial console when
  no display is connected. Note the board has **DisplayPort only, no HDMI**.

---

## 4. State after setup (2026-10-04)

| Item | Result |
|---|---|
| Root partition | 228 GB, grown automatically by the first-boot wizard (no manual resize needed) |
| `jetson/setup_jetson.sh` | Run; packages, `dialout`/`video` groups, udev rule, venv all verified |
| Python env | `~/rover-venv` (system site packages): numpy 1.21.5, OpenCV 4.8.0 with GStreamer, GStreamer Python bindings (python3-gi 3.42.1), pyserial 3.5. Flask and pygame are installed but no longer used on the rover |
| Code | `~/Rover` — a plain copy from the laptop, **not a git clone yet** |
| Wi-Fi | Stock RTL8822CE card, home network, 5 GHz ch 36 |
| Wi-Fi power save | Off. Ping from the laptop went from 2–238 ms to **2–5 ms** (30/30 replies) |
| Power mode | 25 W (not yet MAXN SUPER) |
| Kernel drivers | `ftdi_sio` (U2D2), `cdc_acm` (Arduino IMU), `uvcvideo` (camera) all available |

SSH aliases on the laptop (`~/.ssh/config`): `ssh rover` (Wi-Fi, address from the home
router, may change) and `ssh rover-usb` (USB-C cable, `192.168.55.1`, always the same).

**Teleop test without hardware** (2026-10-04, with the earlier `teleop.py`, since replaced —
see §4.3) — `teleop.py --no-motors --imu fake --headless --no-log` on the Jetson, opened
from the laptop over Wi-Fi:

- `/`, `/panel`, both `/static/*.js` files and the Socket.IO handshake all returned 200.
- Panel showed live telemetry at 100.0 Hz, 0 dropped cycles.
- A joystick command sent from the phone page (`forward 0.5, turn -0.25`) appeared on the
  panel and returned to zero when it stopped.

### 4.1 Problems found during setup

- **USB-C network link is flaky from Windows.** The Jetson exposes two USB network
  adapters (RNDIS and NCM); Windows moves the `192.168.55.100` address between them and
  SSH sometimes fails with "Connection refused" on the first try. Use Wi-Fi for normal
  work; keep USB as the fallback.
- **Stale SSH host key.** `192.168.55.1` is the same address for every Jetson, so after a
  reinstall SSH refuses to connect until `ssh-keygen -R 192.168.55.1` is run.
- **Jetson clock.** No clock battery: it boots ~1.6 years in the past until it reaches the
  internet. `apt`/`pip` can fail with certificate errors before that.
- **Live panel charts blank on scaled displays.** Canvas height was multiplied by the
  display scale factor on every frame. The station page sizes every canvas from the page
  layout instead (`station/web/util.js`, `fitCanvas`).
- **Never run `pkill -f rover_main.py` over SSH** — it matches and kills its own SSH
  command. Use `pkill -f "[r]over_main.py"`. The brackets protect only the pattern: if
  the same SSH command also starts the program again, that text matches and the shell
  dies before the restart (happened 2026-10-05). Stop in one SSH command, start in the next.
- **A program started in the background over SSH can hang the SSH command.** Redirect all
  three streams of the whole command, as in §4.3.

### 4.2 Video test (2026-10-04)

Arducam B0201 (`0c45:6366`) on a Jetson USB-A port. JetPack 6 shows four nodes:
`/dev/video0` = MJPG / YUYV, `/dev/video2` = **H.264**; `video1` and `video3` carry no
picture. The camera compresses H.264 itself. The Jetson Nano notes in
[the archived camera note](archive/99_카메라_노트.md) say it cannot — that older kernel only did not show the node.

1280×720 at 30 fps, Jetson → laptop over the home Wi-Fi (5 GHz channel 36, −48 dBm),
12 s per run. The picture was also checked by eye in a browser at `http://<jetson>:8080`.

| Path | Frames/s at the laptop | Bitrate | Jetson CPU (100% = one of 6 cores) | Longest gap between frames |
|---|---:|---:|---:|---:|
| `cam_stream.py`, the Jetson Nano preview script since removed (decode, then re-compress as JPEG quality 80) | ≈29 | 23.9 Mbit/s | 60–68% | not measured |
| MJPEG passed through untouched | 30.6 | 37.3 Mbit/s | ≈7% | 47 ms |
| H.264 from the camera, passed through | 30.6 | 10.1 Mbit/s | ≈5% | 38 ms |

**Chosen: 1920×1080 H.264 from the camera** — the sensor's full resolution, at the same
bitrate as 720p. Tested for 60 s each at 1080p, with a ping running alongside:

| 1080p path | Frames/s | Bitrate | Longest gap between frames | Ping during the stream |
|---|---:|---:|---:|---|
| **H.264 from the camera** | 30.5 | **10.2 Mbit/s** | 42 ms | 2 ms average, 7 ms worst, 0 of 60 lost |
| MJPEG passed through | 30.6 | 41.9 Mbit/s | 57 ms | 3 ms average, 11 ms worst, 0 of 60 lost |

- **Link capacity** on this network was 191 Mbit/s (plain TCP, Jetson → laptop), so the
  H.264 stream uses about 5% of it and MJPEG about 22%. The field router and distance
  will lower the capacity; repeat this measurement there.
- **The camera's H.264 bitrate is fixed** near 10 Mbit/s at every resolution (measured
  10.0 at 640×360 and 640×480, 10.1 at 720p, 10.2 at 1080p), so a smaller picture saves
  nothing. It is Main profile, level 4.1, one keyframe per second. The standard V4L2
  controls have no bitrate setting, and Arducam
  [says](https://forum.arducam.com/t/linux-equivalent-for-amcap-exe-for-any-arducam-uvc-webcam-need-to-set-on-camera-h264-bitrate/5606)
  the bitrate is set through a vendor-specific channel with no standard Linux tool.
  The proposal budgeted 8 Mbit/s for video; this is 2 Mbit/s over.
- The Orin Nano has **no hardware video encoder**: `nvv4l2h264enc` is absent on this
  board, and [NVIDIA documents](https://docs.nvidia.com/jetson/archives/r36.5/DeveloperGuide/SD/Multimedia/SoftwareEncodeInOrinNano.html)
  software encoding as the only option. A lower bitrate would mean re-compressing on
  the CPU (`x264enc`), not tested.
- **Playback on the laptop works in a browser with nothing installed**:
  [`jetson/h264_view_test.py`](../jetson/h264_view_test.py) decoded 1080p at a steady
  30 frames/s with no skipped frames (40 s and 25 s runs). The browser's decoder only
  works on a page served from `localhost` or https, so the station page must be served
  from the laptop, not from the Jetson.
- The browser cancels a running download when Windows reports a network change
  (`ERR_NETWORK_CHANGED`, seen once with the Jetson's USB-C cable also plugged in). The
  test page reconnects by itself; the station GUI must do the same.
- **Not measured yet:** delay from camera to screen. The test page shows a millisecond
  counter for this: point the camera at the screen and take a screenshot.

To repeat: start the source on the Jetson (command in the docstring of
`h264_view_test.py`), then on the laptop run
`python jetson/stream_pull_test.py <jetson-ip> 8086 h264 60` for the numbers or
`python jetson/h264_view_test.py <jetson-ip> 8086` for the picture. Stop
`rover_main.py` first: only one program can read the camera's H.264 at a time.

#### Moving light and dark bands (fixed 2026-10-05)

**Symptom.** Faint light and dark horizontal bands drifting slowly through the picture
under room lights.

**Cause.** The camera's flicker filter (`power_line_frequency`) was at its 50 Hz default.
Korea's mains is 60 Hz, so lights flicker 120 times a second. The sensor reads its rows
one after another; unless the exposure time is a whole number of flicker periods, each
row catches a different part of the flicker. The filter makes auto-exposure pick such
times, but only for the mains frequency it is told.

**Measured** on the station's picture (row brightness compared across 60 frames, same
scene, twice each):

| Filter | Bands per frame | Band strength (share of brightness) | Movement |
|---|---:|---:|---|
| 50 Hz (default) | 4 (= 120 Hz ÷ 30 frames/s) | 2.8% | about 22 rows per frame |
| 60 Hz | none found | 0.02% | — |

**Fix.** The camera forgets the setting when it loses power, so `rover/camera.py` sets it
every time it opens the stream, from `config.CAMERA_MAINS_HZ` (60). If that fails, the
station's system log says so when the camera starts. Exposure stays automatic and the
frame rate is unchanged. By hand:

```bash
v4l2-ctl -d /dev/video0 -c power_line_frequency=2    # 1 = 50 Hz, 2 = 60 Hz
```

Verified by setting the camera back to 50 Hz and starting the camera reader: it came up
at 60 Hz. **Not yet run through a full `rover_main.py` restart.** If bands appear at the
venue anyway, the light is flickering at some other rate (a dimmed LED, a screen in
view); this filter cannot remove that.

### 4.3 Rover program and station (2026-10-05)

`teleop.py` and `live_panel.py` were replaced by one rover program,
[`rover/rover_main.py`](../rover/rover_main.py) (no screen), and a station page served on
the laptop, [`station/`](../station/). How they work: [02](02_구현_코드해설.md). How to
use them: [04 §3](04_실행_가이드.md).

Start the rover program over SSH and leave it running, then open the station:

```bash
ssh rover '( cd ~/Rover/rover && exec nohup setsid ~/rover-venv/bin/python -u rover_main.py ) >/tmp/rover_main.log 2>&1 </dev/null &'
python station/station.py --rover <jetson address>
```

Stop it with `ssh rover 'pkill -f "[r]over_main.py"'`; its output is in `/tmp/rover_main.log`.

Tested with the camera attached and **no motors or IMU** (`--no-motors --imu fake`),
Jetson and laptop on the home Wi-Fi:

| Check | Result |
|---|---|
| Control loop, with the camera running and a station connected | 100.0 Hz over 186 s (18,615 cycles) |
| Telemetry arriving at the station | 20 per second |
| Video at the station | 1920×1080, 30–31 frames/s, about 10 Mbit/s, decoded in the browser |
| Round trip on the control channel | 3–5 ms |
| Deadman | Rover reports "no signal" 0.54 s after the last drive message (0.5 s timeout plus one telemetry period) |
| E-STOP | Latches on Space; released with RELEASE |
| NEW RUN, STOP LOG | New log opened under the typed name, 5 s alignment ran again, 100 rows per second; closed on STOP LOG |
| Rover program restarted | Station reconnected by itself; video returned without a click |
| `kill` (SIGTERM) | Went through the normal shutdown path |
| Invalid data on the control channel | That one connection was closed; the rover and the other station were unaffected |

**Not tested: anything with real motors or the real IMU.** `rover/motors.py` only passes
calls to the existing `dxl_reader` / `dxl_control` functions, but it has not turned a wheel
yet. The page's drive keys were checked by calling the input code directly: the test
browser window was hidden, and a hidden station sends no drive messages by design.

Found while testing:

- **The browser cancels downloads when Windows reports a network change** — also
  downloads from `localhost`. Once, the station page did not start because one of its
  script files was cancelled this way. The page now reloads itself when a script fails to
  download. The cause here is the Jetson's USB-C network adapter reconnecting (§4.1);
  unplug the USB-C cable when working over Wi-Fi.
- **`rover.local` points at the USB-C address** (`192.168.55.1`) while that cable is
  plugged in. Give the station the Wi-Fi address.

## 5. Follow-up work

The active checklist moved to the roadmap so setup notes cannot become a second
status list: [motor failures](05_한계와_로드맵.md#safe-01),
[hardware integration](05_한계와_로드맵.md#hw-01),
[field/video validation](05_한계와_로드맵.md#field-01),
[deployment and startup](05_한계와_로드맵.md#ops-01), and
[conditional AX210 comparison](05_한계와_로드맵.md#field-02).

For the physical bench sequence, use a current-limited supply and start with
`dxl_tool.py scan`, then `test_pipeline.py`, then `rover_main.py` with wheels
clear of the bench. The [Pico guide](../firmware/pico/README.md) owns flashing,
`/dev/pico` installation and servo/battery checks. Save each result with its
configuration and update the corresponding roadmap entry.

## 6. BMI088 SPI bring-up (2026-10-07)

The owner connected the BMI088 through headers and requested an IMU-only test.
**Connector-label correction:** the assistant's earlier map reversed P1 and P2.
The [schematic supplied by the owner](assets/bmi088_shuttle_connector_schematic.png)
shows **P1 = seven-pin power/interrupt connector; P2 = nine-pin SPI connector**.
The corrected map below follows that schematic. Cross-check the connector names,
pin counts and pin-1 markings on the actual board before applying power.
Jetson numbers are physical positions on the 40-pin header. Turn off power before
changing connections; do not infer connector orientation from the table alone.

| BMI088 Shuttle Board 3.0 | Jetson physical pin |
|---|---|
| P1-1 VDD | 1, 3.3 V |
| P1-2 VDDIO | 17, 3.3 V |
| P1-3 GND | 6, GND |
| P2-2 SCK | 23, SPI clock |
| P2-4 SDI | 19, MOSI |
| P2-3 SDO | 21, MISO |
| P2-1 CS | 24, accelerometer CS0 |
| P2-5 GPIO4 | 26, gyroscope CS1 |
| P2-6 GPIO5 | 9, GND; gyroscope SPI selection |

Pins 1 and 17 are both 3.3 V; pins 6 and 9 are both ground. Using separate pins
avoids putting two jumper leads on one header pin. GPIO5 must stay grounded;
it is not an interrupt wire. Remove the 19-21 loopback jumper before connecting
the sensor. The connector-label mistake is recorded as [F-34](07_실패기록.md#f-34).

This is a header-to-header map. The full flyer also shows power jumpers and an
unresolved accelerometer SDO connection discrepancy; see [the source comparison](#64-full-schematic-and-driver-cross-check).
The map does not establish that both sensor outputs reach the header on the
actual board.
The [later live bench test](#65-successful-live-bench-test-2026-10-08) verifies
communication with both sensor dies in the owner's corrected setup; the
flyer discrepancy alone is not a reason to modify that working board.

The failed ID reads below predate this correction. The originally reported
wiring named P2 as power and P1 as SPI, and the assistant repeated that error.
The actual harness was not independently inspected. Tests after the owner
reported rewiring are recorded in [section 6.3](#63-corrected-wiring-retest-2026-10-08);
the previous failures do not establish a Jetson driver fault.

Both home Wi-Fi SSH and USB SSH reached `rover`, running kernel
`5.15.148-tegra`. `/dev/spidev0.0` and `.1` existed, but Jetson-IO initially
reported no functions enabled on the 40-pin header. Initial reads were all zero.
Installed `spidev==3.8` in `/home/taeholee/rover-venv` and enabled the header with
NVIDIA's [Jetson-IO procedure](https://docs.nvidia.com/jetson/archives/r36.4.3/DeveloperGuide/HR/ConfiguringTheJetsonExpansionHeaders.html):

```bash
sudo python3 /opt/nvidia/jetson-io/config-by-function.py -o dt spi1
sudo systemctl reboot
sudo python3 /opt/nvidia/jetson-io/config-by-function.py -l enabled
```

The original boot configuration was preserved at
`/home/taeholee/bmi088-bringup-20261007/extlinux.before-spi.conf` on the Jetson.
Jetson-IO retained the original `primary` boot entry and added the `JetsonIO`
entry with `/boot/jetson-io-hdr40-user-custom.dtbo`. After reboot, Jetson-IO and
kernel pinctrl both reported SPI1 on 19/21/23/24/26. Linux names this controller
`spi0`, mapped to `3210000.spi`; accelerometer CS0 and gyro CS1 use
`/dev/spidev0.0` and `/dev/spidev0.1` respectively.

Read-only chip-ID probes used SPI modes 0 and 3 with requested speeds of
100 kHz, 1 MHz and 5 MHz; the on-wire clock was not measured.
Responses varied rather than yielding stable IDs. The final repeated check used
mode 3, requested 1 MHz, 8 bits, MSB first, active-low CS requested, both devices open,
5 ms between reads, and an initial dummy accelerometer read:

| Register 0x00 check | Expected | Matches in 100 reads |
|---|---|---|
| Accelerometer, discard address response and one dummy byte | `0x1E` | 0 |
| Gyroscope, discard address response only | `0x0F` | 0 |

Retry requested by the owner at 21:51 KST on the same day: the Jetson was
reachable after an initial connection timeout, and SPI1 remained enabled.
At mode 3 / requested 1 MHz, both sensors again gave 0 valid IDs in 100 reads each.
At requested 100 kHz, modes 0 and 3 each gave 0 valid IDs in 20 reads per sensor.
Responses still varied; no live measurement test was attempted with invalid IDs.

This is a failed communication test, not evidence of gyro drift or a defective
sensor. Jetson driver/CS timing and board power/contact/signal integrity still
require verification; software pinmux status does not prove correct waveforms.
The requested next measurements are VDD, VDDIO and GPIO5 relative to board GND:
approximately 3.3 V, 3.3 V and 0 V. No acceleration, angular rate or yaw accuracy
was validated. No motor program was started; `RealIMU` was a stub at this
probe date. Later integration is recorded in §6.7. Follow-up belongs to [IMU-01](05_한계와_로드맵.md#imu-01).

### 6.1 Community evidence and isolation procedure

On 2026-10-07, remote package inspection confirmed L4T
`36.4.4-20250616085344`, kernel `5.15.148-tegra`, and the installed
`kernel/drivers/spi/spi-tegra114.ko`. Its patch state has not been established.
These NVIDIA community reports describe possible software failure modes. They
were investigated before the P1/P2 map error was identified; retest with the
corrected wiring before treating a driver patch as the next intervention:

- An [Orin Nano / JetPack 6.2 IMU report](https://forums.developer.nvidia.com/t/jetson-orin-nano-spi-strange-signals/341569)
  passed loopback but failed an LSM6DSL ID read with Python `xfer2`; a logic
  analyzer showed incorrect CS behavior. NVIDIA support pointed to a driver patch.
- Another [JetPack 6.2 report](https://forums.developer.nvidia.com/t/spi-bus-chip-select-on-jetpack-6-2-with-device-tree/324085)
  confirmed that the [CS patch](https://forums.developer.nvidia.com/t/jetson-orin-nano-spi-speed-not-changing/311083/9)
  corrected CS relative to the clock. This is evidence of a known failure mode,
  not proof that this rover has the same fault.
- A [clock-frequency report](https://forums.developer.nvidia.com/t/jetson-orin-nano-spi-speed-not-changing/311083)
  measured about 3.18 MHz despite lower requested speeds. Our requested 100 kHz
  tests therefore do not establish an actual slow-clock test.
- A separate [JetPack 6.2.1 GPIO report](https://forums.developer.nvidia.com/t/unable-to-reliably-control-a-gpio-on-jetson-orin-nano-jetpack-6-2-1/357557)
  concerns manual GPIO/CS control and pinmux state after GPIO operations. The
  current probes used spidev CS, so this is not by itself a diagnosis here.

To repeat the isolation test, follow NVIDIA's [SPI loopback procedure](https://forums.developer.nvidia.com/t/nvidia-orin-nano-spi-loopback-test-not-receiving-data/310660/5):

1. Shut down and remove Jetson power. Disconnect the BMI088 wiring.
2. Bridge only physical pin 19 (MOSI) to physical pin 21 (MISO). Leave clock and
   CS unconnected to external devices. Power on and confirm the setup before
   sending loopback patterns, which could otherwise write sensor registers.
3. Compare transmitted and received bytes on `/dev/spidev0.0`, including short
   two/three-byte and longer patterns in modes 0 and 3.
4. A failure with a verified jumper focuses investigation on the Jetson SPI
   path. A pass verifies the data loop but does not validate CS timing, actual
   clock frequency, or sensor communication. Examine CS/clock with a logic
   analyzer or scope and compare the installed driver with the applicable fix.

### 6.2 Physical loopback result

On 2026-10-07 at 23:33 KST, after the owner confirmed the BMI088 was disconnected
and physical pins 19 and 21 were bridged, all **1,200/1,200 transfers passed**.
The comparison was exact byte equality, including response length. Hardware
internal-loopback mode was not enabled: the test used the external jumper.

| Configuration | Coverage |
|---|---|
| Device paths | `/dev/spidev0.0` and `/dev/spidev0.1` |
| SPI modes | 0 and 3, 8 bits, MSB first, active-low CS requested |
| Requested speeds | 100 kHz, 1 MHz, 5 MHz; actual clock not measured |
| Patterns | Four one-byte patterns (`00`, `FF`, `55`, `AA`); lengths 2, 3, 4, 16, 64, 257 |
| Repetition | 10 transfers per pattern and configuration; 120 cases |
| Runtime | 1.760 s; `spidev` 3.8, kernel `5.15.148-tegra` |

The reusable [loopback test](../jetson/spi_loopback_test.py) records all TX/RX
bytes and its source SHA-256 in the [raw JSON result](../logs/2026-10-07_spi_loopback.json).
The downloaded record was independently checked against the source hash and
every TX/RX pair. The [original source](../logs/2026-10-07_spi_loopback.source.py)
preserves the exact version matching that hash. Run only with the sensor
disconnected and the jumper confirmed:

```bash
~/rover-venv/bin/python jetson/spi_loopback_test.py --loopback-wired --output /tmp/spi-loopback-new.json
```

The output must be a new file so earlier evidence cannot be overwritten.
This validates the tested transmit/receive data path and makes a complete SPI
data-path failure unlikely. CS0/CS1 pins were not observed by loopback, so this
does not prove correct chip-select timing, actual clock frequency or BMI088
power/wiring. The installed module is stripped and no matching SPI source was
found in the earlier AX210 build directories; its specific CS patch state
remains unverified. No kernel or SPI driver patch was applied.

Before returning to sensor ID tests, shut down, remove power, remove the 19-21
jumper, and restore the BMI088 connections in section 6. Do not send loopback
patterns after reconnecting a sensor.

### 6.3 Corrected-wiring retest (2026-10-08)

The owner reported completing the rewire using P1 for power and P2 for SPI.
Physical connector orientation, board-side voltages and CS waveforms were not
independently inspected. The definitive retry at **00:04 KST on 2026-10-08**
still returned only zero bytes:

| Chip | Expected ID | Valid IDs | Returned ID |
|---|---|---|---|
| Accelerometer, CS0 | `0x1E` | 0 / 120 | `0x00` |
| Gyroscope, CS1 | `0x0F` | 0 / 120 | `0x00` |

This covered modes 0 and 3, three requested speeds, and 20 reads per chip per
configuration. Every transfer used a fresh TX buffer: `[0x80, 0, 0]` for accel
and `[0x80, 0]` for gyro. An initial accel dummy read selected SPI before ID reads.
The [raw result](../logs/2026-10-08_bmi088_fresh_buffer_probe.json) includes every
response, the executed Python source, its SHA-256, timestamps and clock state.
It contains no live acceleration or angular-rate measurements.

**Clock isolation.** With parent `pllp_out0`, BPMP reported 3,187,500 Hz after
100 kHz and 1 MHz requests, and 4,975,610 Hz after a 5 MHz request. Following
the [NVIDIA community clock-parent workaround](https://forums.developer.nvidia.com/t/jetson-orin-nano-devkit-spi-speed/332616),
the retry temporarily selected `clk_m`:

| Requested rate | BPMP-reported rate during reads |
|---|---|
| 100,000 Hz | 150,000 Hz |
| 500,000 Hz | 492,308 Hz |
| 1,000,000 Hz | 960,000 Hz |

These are software-reported controller clocks, not measured wire frequencies.
Both IDs remained invalid at every setting. A `finally` block restored the
original parent `pllp_out0` and rate 4,975,610 Hz; readback verified both.
No persistent clock setting, device-tree change or kernel patch was made in
this retry. The [official matching-release SPI source](https://gitlab.com/nvidia/nv-tegra/3rdparty/canonical/linux-jammy/-/raw/jetson_36.4.4/drivers/spi/spi-tegra114.c)
already selects hardware CS for a single transfer without `cs_change`.
That makes an older unconditional hardware-CS patch an unproven intervention
for this case; the installed binary and physical CS waveform remain unverified.

**Probe correction.** The earlier
[23:56 KST probe](../logs/2026-10-07_bmi088_corrected_wiring_probe.json) and
[00:03 KST clock probe](../logs/2026-10-08_bmi088_clock_parent_probe.json)
reused a TX list that `spidev` overwrote with received bytes. Consequently,
later transfers were not guaranteed to send the read command, and their
repeated-ID counts are invalid. Those records remain intact; the fresh-buffer
retry above supersedes that conclusion. Register 0 is the read-only chip-ID
register, but these older runs must not be described as exclusively read commands.

The loopback tool had the same comparison hazard. It now passes a copy into
`xfer2`, preserving the expected pattern. The old loopback result was separately
rechecked against all original intended patterns and recorded RX bytes:
all 1,200 comparisons still match, independently of its recorded pass flags.
Offline checks with an input-mutating SPI stand-in verify that the corrected
tool accepts exact echoes and rejects corrupted replies. No new loopback
patterns were sent to the reconnected BMI088.

The physical check requested after that run was: black multimeter probe on **P1-3 (GND)**; measure
**P1-1 (VDD)** and **P1-2 (VDDIO)** at approximately 3.3 V, and **P2-6 (GPIO5)**
at approximately 0 V. If those are correct, verify MISO continuity and observe
CS0/CS1 together with clock at the sensor connector. An all-zero response alone
does not identify a damaged Jetson or BMI088. Current follow-up remains in
[IMU-01](05_한계와_로드맵.md#imu-01).

**00:26–00:30 KST retry, after the owner said “IMU ready.”** The response changed
from all zero to all `0xFF`; neither chip returned a valid ID. The owner then
reported that P1-1, P1-2 and P2-6 relative to P1-3 were all at the expected
values (3.3 V, 3.3 V and 0 V). These are owner-reported measurements, without
meter precision or photographs. The particular physical change before this
retry was not specified.

| Probe | Reads per chip | Result |
|---|---|---|
| [Normal ID reads](../logs/2026-10-08_002601_bmi088_id_probe.json), modes 3/0, requested 1/5 MHz | 80 | All IDs `0xFF` |
| [Lower-clock ID reads](../logs/2026-10-08_002657_bmi088_slow_id_probe.json), modes 0/3, BPMP 150,000/492,308/960,000 Hz | 120 | All IDs `0xFF` |
| [Transfer layout comparison](../logs/2026-10-08_003000_bmi088_transfer_probe.json), modes 3/0, requested 1 MHz | 80 | All IDs `0xFF` |

Every probe preserves its executed source, SHA-256 and raw responses. The
lower-clock test restored and verified the original `pllp_out0` parent and
4,975,610 Hz rate. The later layout comparison used the ordinary clock parent;
its requested speed is not a wire-frequency measurement. It compared normal
two/three-byte `xfer2` reads, eight-byte burst reads, a single raw ioctl transfer,
and a two-transfer ioctl message requesting continuous CS with a 10 us gap
between address and response. Each read used a fresh command buffer. No
sensor initialization writes, driver patches or motor commands were issued.

A consistent `0xFF` means the controller sampled ones during the response;
it does not establish that the sensor drove MISO or identify a failed component.
The owner subsequently reported **3.3 V on both P2-1 (accel CS) and P2-5
(gyro CS)** relative to P1-3 while tests were stopped. Those are expected
inactive levels; they do not show whether either CS asserts during a transfer.
No further sensor transfers were issued in response to this voltage report.

The next check is continuity with the Jetson shut down and external power/USB
disconnected. Touch the BMI088 connector's solder pad and the corresponding
Jetson header contact so the measurement includes the header joint and cable:

| BMI088 pad | Jetson physical pin |
|---|---|
| P2-3 SDO / MISO | 21 |
| P2-4 SDI / MOSI | 19 |
| P2-2 SCK | 23 |
| P2-1 accel CS | 24 |
| P2-5 gyro CS | 26 |

Each direct connection should have low resistance, close to the meter's
shorted-probe reading. A meter checks static levels/continuity; CS/clock timing
requires a scope or logic analyzer. Supply and idle-CS voltage readings alone
do not establish that the sensor is communicating or damaged.

### 6.4 Full schematic and driver cross-check

On 2026-10-08 the owner supplied the
[Bosch Shuttle Board 3.0 flyer](https://www.bosch-sensortec.com/media/boschsensortec/downloads/shuttle_board_flyer/application_board_3_1/bst-bmi088-sf000.pdf)
and [Bolder Flight's Arduino driver](https://github.com/bolderflight/bmi088-arduino).
Both flyer pages were rendered and visually inspected. Page 2 of
`BST-BMI088-SF000-01`, version 1.1 (2024-02), confirms P1 power and P2 SPI;
text extraction interleaves its two side-by-side connector tables.

Two board details require verification beyond header voltages:

- **JP1 and JP2:** JP1 connects the VDD header net to U1 VDD (pin 3), and JP2
  connects the VDDIO header net to U1 VDDIO (pin 11). Measure both pads of each
  jumper relative to P1-3; all should be approximately 3.3 V with this supply.
  Header-side voltage alone does not prove sensor-side power. The drawing does
  not establish the actual jumpers' condition; no bridging or cutting is
  justified without inspecting the board.
- **Accelerometer MISO discrepancy:** the flyer draws U1 pin 15 (SDO1) with
  a no-connect marker, and routes only pin 10 (SDO2) to the SDO header net.
  Bosch's [BMI088 datasheet](https://www.bosch-sensortec.com/media/boschsensortec/downloads/datasheets/bst-bmi088-ds001.pdf),
  revision 1.9 (2024-01), page 44 / table 10 identifies SDO1 as accel SPI
  output and SDO2 as gyro SPI output. The Arduino library's SPI wiring section
  calls for both outputs to reach MISO. If the flyer reflects the actual board,
  P2-3 alone does not provide the accel SPI output. A drawing error or board
  revision difference remains possible; this is not a verified physical fault
  and does not explain the missing gyro ID by itself. Inspect the actual board
  or obtain manufacturer clarification before modifying it.

The Arduino source was checked at commit
`a3b136f69f1f4ff6434d8a3f7cdc6d953549e471`.
[Its SPI reads](https://github.com/bolderflight/bmi088-arduino/blob/a3b136f69f1f4ff6434d8a3f7cdc6d953549e471/src/BMI088.cpp)
use mode 0, MSB first, active-low CS, address bit 7 for reads, one extra dummy
byte for accel and no extra dummy byte for gyro. These match our fresh-buffer
ID command format. Its configured SPI clock is 10 MHz; that does not establish
our Jetson wire frequency. Each separate sensor's `begin()` checks its ID
before reset, power configuration and range/ODR setup. Consequently, missing
those later initialization writes is not established as the cause of the
invalid IDs. The library uses Arduino `SPIClass` and GPIO APIs, so using it on
the Jetson would require a transport adaptation; it was reviewed, not installed
or flashed. The existing Jetson results remain the latest hardware evidence.

**Power follow-up, 2026-10-08:** the owner first reported JP1 about 0.3 V and
JP2 3.3 V. Asked for the two JP1 pad voltages relative to P1-3 and a fresh
P1-1 reading, the owner answered “0.3v 0.2v”; these are provisionally taken as
the two JP1 pad readings. The owner then rechecked P1-1 directly on the
board's header solder pad relative to P1-3 and reported **3.3 V**.
Both reported JP1 values are below the datasheet's 2.4–3.6 V VDD operating
range (page 7). If the identified pads and reference are correct, inadequate
VDD is now a concrete explanation to investigate for the failed communication.
The reported header and JP1 voltages are inconsistent with an intact direct
connection between P1-1 and JP1's header-side pad. Pad identification and that
connection have not yet been independently verified.

Do not bridge JP1 on this evidence: with both pads low, an open jumper alone
does not explain the result. With the Jetson shut down and power/USB removed,
measure resistance from P1-1 to each JP1 pad. At least the header-side pad
should be near the shorted-probe resistance. If neither has continuity,
verify the actual board and pad locations against a close-up photograph
before diagnosing a broken PCB connection. Sensor damage has not been
established, and no SPI retries were issued during this power diagnosis.

**Owner-requested retry at 00:46 KST, 2026-10-08:** SSH and both spidev nodes
were available. Reusing the source-hash-verified fresh-buffer ID probe, modes
3/0 at requested 1/5 MHz produced **0 valid IDs out of 80 reads per chip**;
all returned IDs were `0x00`, rather than the earlier `0xFF`.
The [raw result](../logs/2026-10-08_004653_bmi088_id_probe.json) retains every
response, the executed source and its hash. Subsequent physical changes and
current JP1 voltages were not reported. No initialization writes or live-data
tests followed the invalid IDs; no motor commands were issued. A change from
all ones to all zeros does not establish that sensor power or communication
has recovered.

After that retry the owner reported JP1 still at **about 0.4 V**, without
separate new values for both pads. The VDD concern therefore remains unresolved.
No additional SPI test was run for this report. The next discriminating check
remains unpowered continuity from P1-1 to the identified JP1 pads, together
with a close-up view of the actual board; voltage alone does not identify
whether a contact/trace is open, a measurement point is misidentified, or the
sensor-side supply is being loaded down.

### 6.5 Successful live bench test (2026-10-08)

The owner requested another check and subsequently stated that the issue was
the pin map. The exact changed connections and new JP1 voltages were not
provided. This test supersedes the earlier communication blockage; those
earlier measurements do not establish the voltage at the sensor during this
successful run. No further wiring changes are required on the basis of the
earlier failed probes alone.

At **00:50 KST**, the [ID probe](../logs/2026-10-08_005002_bmi088_id_probe.json)
returned **80/80 `0x1E` accel IDs and 80/80 `0x0F` gyro IDs**, covering modes
3/0 and requested 1/5 MHz. A [first initialization attempt](../logs/2026-10-08_005228_bmi088_live_probe.json)
passed ID and configuration readbacks but stopped before capture when the
accel error register returned `0xFF`. Subsequent [health reads](../logs/2026-10-08_005343_bmi088_health_probe.json)
found valid IDs, accel error zero, accel power-enable zero and changing gyro
data. The reason settings changed was not established. After the owner's
pin-map clarification, initialization and capture were repeated successfully.

The [00:55 KST live result](../logs/2026-10-08_005530_bmi088_live_probe.json)
contains all 1,000 raw samples, host timestamps bracketing each read, accel
sensor-time ticks, configuration writes/readbacks, executed source and SHA-256.

| Check | Result |
|---|---|
| Interface | spidev 3.8, mode 3, 8-bit MSB first, requested 1 MHz; wire clock not measured |
| Setup | Reset each die; accel active, +/-6 g, 400 Hz; gyro normal, +/-500 deg/s, 400 Hz |
| Configuration | All seven readbacks match; gyro bandwidth's fixed bit 7 masked |
| IDs | `0x1E` / `0x0F` before reset, after reset and after capture |
| Capture | 1,000 samples; 9.9901 s between first/last host accel midpoints |
| Host polling | Mean interval 10.0001 ms; maximum 10.4366 ms |
| Data | 1,000 distinct accel triplets and 1,000 distinct gyro triplets |
| Accel sensor time | Advanced on every poll; no zero tick increments |
| Accel magnitude | Mean 9.611 m/s^2; range 8.818–11.167 m/s^2 |
| Gyro magnitude | Peak 151.04 deg/s; capture unsuitable for stationary bias estimation |
| Temperature | 26.625 degC before, 27.875 degC after |
| Error/saturation | Accel error register zero before/after; no near-full-scale samples |

This verifies live communication and a short host-polled capture. It is not
a Bosch built-in self-test, stationary noise/bias characterization, axis/sign
validation, sensor synchronization, sustained reliability test or ground-truth
yaw evaluation. Readings are uncalibrated sensor axes. No gyro bias was saved
from this moving/noisy capture. The sensor remains configured as above after
the test; all SPI handles were closed. No motor commands were issued.
`RealIMU` was not implemented at this capture time; subsequent integration is
recorded in §6.7. Installed-sensor validation continues under [IMU-01](05_한계와_로드맵.md#imu-01).

### 6.6 Stationary baseline (2026-10-08)

At the owner's “ready stationary” confirmation, a 60-second bench run collected
6,001 samples with temperature and health monitoring. All monitored IDs, accel
error checks and power-enable checks passed; configuration readback also passed
after capture. No motor commands were issued. The existing bench configuration
(+/-6 g, +/-500 deg/s, 400 Hz sensor outputs, 100 Hz host polling) was retained.
Raw data and the source are in [the stationary log](../logs/2026-10-08_011054_bmi088_stationary.json).
Bias/noise estimates, the first-half/second-half check, clock comparison and
single-orientation limitations are maintained in [the experiment report](../data/bmi088_stationary_2026-10-08/REPORT.md).
No offsets or timing corrections were applied to rover runtime settings.

### 6.7 Runtime driver integration (2026-10-08)

`RealIMU` now supports the existing `--imu bmi088` choice in `record.py` and
`rover_main.py`. Settings and mounting rotation belong in `rover/config.py`.
The owner described sensor +Y forward and +X right, so body vectors are
`[sensor Y, -sensor X, sensor Z]`. The owner confirmed the board was loose/tilted
during these tests; this description still needs an installed gravity/turn-sign check.

The driver uses SPI mode 3, requested 1 MHz, +/-6 g and +/-500 deg/s. Both
dies run at 400 Hz; accel uses OSR4 / 40 Hz bandwidth and gyro uses 47 Hz
bandwidth. This differs from the earlier stationary test's 145 Hz accel filter.
The six-byte XYZ gyro FIFO retains intermediate readings. `Odometry.step`
predicts each ordered rate before applying wheel/stationary/gravity observations
once per control cycle. Accelerometer data is the latest filtered reading, held
over that interval. No accel FIFO or Bosch interrupt-based synchronization is enabled.

FIFO frames contain no timestamps. The driver distributes each batch uniformly
over the measured host interval between FIFO-count snapshots; this is an estimated
timeline with roughly one gyro period of phase uncertainty plus bus/scheduling delay,
not measured per-sample timestamps. Accel sensor time is unwrapped and logged
separately; its previously measured +1.05% nominal clock difference is not applied
to gyro integration. Sensor/encoder delay and motion accuracy remain unmeasured.

Startup requires consecutive valid chip-ID pairs, resets/configures both dies and
reads settings back. The bounded startup check records mismatched ID pairs and
still fails when responses stay invalid. Every delivered batch has checks for
identity/configuration, accel error/freshness, clock continuity, FIFO overflow,
near-full-scale data, read latency and gaps. Runtime errors latch a fault and raise;
there is no automatic recovery into the existing filter state. SPI locks prevent
cooperating driver instances from sharing the devices; arbitrary probe scripts
must also be kept separate. The hardware two-reader lock test was blocked by
invalid startup IDs and is not counted as verified.

CSV records include raw counts, ordered body-frame rates, actual host batch interval,
accel ticks, host read times and temperature. `*.csv.meta.json` retains configuration,
mounting and source snapshots/hashes. Replay, replay GUI and drive analysis pass the
same batches and intervals into odometry. Existing CSVs remain readable. New log
creation refuses to overwrite an existing file. Replay still uses today's general
filter/geometry settings; automatic restoration of all per-run settings remains
[ODOM-02](05_한계와_로드맵.md#odom-02). Bias stays in the samples for startup/ZARU;
neither the stationary mean nor the old Arduino scale factor is subtracted here.

Motor-free capture evidence (board loose; no independent orientation truth):

| Capture | Logged cycles / gyro frames | Measured rates | Largest interval after first |
|---|---:|---|---:|
| [01:35 record.py](../logs/2026-10-08_0135_bmi088_integration.csv) | 1,200 / 4,798 | 100.03 / 399.94 Hz | 12.02 ms |
| [01:39 rover_main.py](../logs/2026-10-08_0139_bmi088_main.csv) | 1,380 / 5,749 | 96.02 / 400.03 Hz | 16.06 ms |
| [01:42 optimized rover_main.py](../logs/2026-10-08_0142_bmi088_main.csv) | 1,432 / 5,745 | 99.71 / 400.00 Hz | 14.64 ms |

Rates use summed logged IMU intervals. The optimized run's first interval was
48.34 ms during setup; its console cycle timer reported 99.9 Hz. Adjacent health
registers were combined into burst reads to reduce SPI transaction overhead.
The 01:39 console counted one final four-frame read that SIGTERM interrupted before
logging; the table counts only saved data. The 01:42 run stopped cleanly with all
delivered frames logged and zero reported runtime faults. Both main runs used
`--no-motors --pico off --no-camera --port 18766`; an existing fake-IMU program was
left running. The headless recording contained motion and did not finish stationary
alignment; these are acquisition/integration tests, not yaw-calibration results.
All three logs passed raw-to-SI, rotation, FIFO-count, host-interval, advancing-tick
and embedded-source-hash checks.

**Latest limitation:** subsequent opens again produced invalid IDs. The
[read-only SPI property probe](../logs/2026-10-08_bmi088_spi_property_probe.json)
reproduced this with both minimal and explicit SPI settings. Its cause is unresolved;
the bounded readiness check did not restore communication. Do not interpret the
successful captures as proof of reliable wiring or repeatable startup. Restore
communication, mount the board and verify +g up / positive CCW yaw before driving.
The failed [lock attempt](../logs/2026-10-08_bmi088_driver_lock.json) and earlier
startup failure are retained rather than counted as passes.

The tested files were deployed to `/home/taeholee/Rover/rover` after checking target
contents against a backup at
`/home/taeholee/bmi088-driver-20261008-013419/target-before.zip`.
[Deployment evidence](../logs/2026-10-08_bmi088_driver_deployment.json) preserves
initial hashes and full-program stdout. The later startup-readiness change and
[final source snapshots/test output](../logs/2026-10-08_bmi088_driver_final_verification.json)
are separate: **14/14 driver tests passed locally and on Jetson**, but no final
live pass occurred after that change because IDs remained invalid. The existing
filter suite passed 11 structural checks and 10 scenarios; the fake pipeline passed
10/10. Wi-Fi was observed at `192.168.50.57`; the saved `.243` alias was stale.

After communication and mounting are verified, from the Jetson checkout:

```bash
source ~/rover-venv/bin/activate
cd ~/Rover
python rover/imu_reader.py bmi088 --sensor-frame  # bench axes only
python rover/record.py --imu bmi088 --fake-motors --seconds 20 --tag bmi088_still
python rover/rover_main.py --imu bmi088 --no-motors --pico off --no-camera
```

Run one sensor reader at a time. Omit `--sensor-frame` to inspect the configured
body axes. Leave the mounted rover stationary through the five-second alignment.
Driver tests need no hardware:
`python -m unittest discover -s rover -p test_imu_reader.py -v`.
The default CLI sensor remains Arduino; select BMI088 explicitly.
Remaining validation stays in [IMU-01](05_한계와_로드맵.md#imu-01), with the
independent-turn procedure in [the yaw guide](09_turn_angle_lesson.md#8-bmi088-yaw--implementation-and-validation-path).
