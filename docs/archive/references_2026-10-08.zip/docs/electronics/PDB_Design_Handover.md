# Rover electronics — current design and software interfaces

The owner reported the Rover PDB design finished on **2026-10-07**. Its maintained
home is **`PCB/projects/rover-pdb`**, in the sibling PCB repository. This existing
link is retained as the Rover-side entry point; it is no longer a second circuit
specification or BOM.

## Where to make or verify a board decision

| Need | Authoritative source in the PCB project |
|---|---|
| Current project and native CAD | [rover-pdb/README.md](../../../PCB/projects/rover-pdb/README.md) |
| Circuit assumptions and interfaces | [DESIGN_BASIS.md](../../../PCB/projects/rover-pdb/DESIGN_BASIS.md) and native schematic linked by the project README |
| Component selection and purchase package | [BOM notes](../../../PCB/projects/rover-pdb/docs/design/BOM_NOTES.md), [JLCPCB workflow](../../../PCB/projects/rover-pdb/docs/design/JLCPCB.md) |
| Recorded verification and physical limitations | [PCB verification](../../../PCB/projects/rover-pdb/docs/review/PCB_VERIFICATION.md) |
| Board editing and review workflow | [PCB project instructions](../../../PCB/projects/rover-pdb/AGENTS.md) |

These links assume the checkouts are siblings, as in `CODE/Rover` and `CODE/PCB`.
On a machine with only Rover, obtain the current PCB project through its owner;
do not recover a pinout or purchase list from the old design notes.

The superseded **LM73606** plan and its component list are retained in
[the design archive](../archive/PDB_Design_Handover_legacy.md) and
[the purchase archive](../archive/Purchase_List_legacy.md). They contain obsolete
converter, fuse, enable-network and connector assumptions. Current native CAD
and its revision-specific verification determine those facts.

## Software integration

| Interface | Maintained implementation or procedure |
|---|---|
| Wheel IDs, baud rate, signs and geometry | [`rover/config.py`](../../rover/config.py), [DYNAMIXEL guide](../06_하드웨어.md) |
| Pico PWM and INA226 acquisition | [Pico firmware and bench procedure](../../firmware/pico/README.md), [`rover/pico_link.py`](../../rover/pico_link.py) |
| Servo trims/directions, shunt resistance and battery display | [`rover/config.py`](../../rover/config.py) |
| Stable USB device names | [`99-rover-serial.rules`](../../jetson/99-rover-serial.rules) |
| IMU acquisition | [`imu_reader.py`](../../rover/imu_reader.py) |
| Operator behavior | [Station](../../station/README.md) |
| Off-board equipment and recorded purchases | [Purchase record](Purchase_List.md) |

Read the installed board revision before wiring or matching firmware pins. Code
currently describes three servos; extra board channels do not become controlled
outputs merely because a connector exists. Bench measurements belong with the
run records; board electrical verification stays with the PCB project.

Current integration work is tracked only in [HW-01](../05_한계와_로드맵.md#hw-01),
[IO-01](../05_한계와_로드맵.md#io-01), [IMU-01](../05_한계와_로드맵.md#imu-01),
and [MISSION-01](../05_한계와_로드맵.md#mission-01).
