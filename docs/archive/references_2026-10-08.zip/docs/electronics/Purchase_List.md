# Rover — off-board inventory and purchase record

Reconciled **2026-10-07** from the existing September purchase record and October
bring-up records. “Recorded bought” preserves that record; it does not assert
that every item is now on the bench. Add receipt/arrival dates or corrections to
the same row when confirmed.

**PCB components are ordered from the current [PCB BOM and purchase workflow](PDB_Design_Handover.md).**
The obsolete LM73606 BOM, old prices/stock and rejected-option reasoning remain
in the [historical purchase record](../archive/Purchase_List_legacy.md). Those
stock counts, performance estimates and selection assumptions are not current
procurement advice.

## Recorded equipment

| Item | Recorded status / quantity | Role or evidence |
|---|---|---|
| Jetson Orin Nano Super | Owned, 1 | [Installed and exercised](../11_jetson_bringup.md) |
| DYNAMIXEL XH430-V350-R | Owned, 5 | Four wheels and planned hammer; wheel bus recordings are in [logs](../../logs/README.md) |
| FEETECH FS90MGR | Owned, 3 | Two lift servos and camera pan; installed-unit calibration belongs to HW-01 |
| Arducam B0201 | Owned, 1 | [Camera integration record](../11_jetson_bringup.md) |
| ROBOTIS U2D2 | Used in earlier bus tests | Confirm the unit/harness on the assembled rover during HW-01 |
| U2D2 Power Hub | Recorded owned, 1 | Retained as bench spare; current power distribution comes from the PDB design |
| 6S 2,800 mAh LiPo | Recorded bought, 1 | Runtime and warning calibration require measurements on this pack |
| Intel AX210NGW and antennas | Recorded bought, 1 | Adoption is conditional: [FIELD-02](../05_한계와_로드맵.md#field-02) |
| 256 GB NVMe SSD | Bought and installed, 1 | Jetson boot storage |
| ipTIME AX3000Q | Bought and configured, 1 | [Router record](../12_field_link.md) |
| Bosch Shuttle Board 3.0 BMI088 | Recorded bought; spare not confirmed | Intended replacement IMU; [IMU-01](../05_한계와_로드맵.md#imu-01) |
| Raspberry Pi Pico 2 H | Recorded bought | Servo/battery I/O board |
| ipTIME U1G-C | Recorded bought | Laptop-to-router Ethernet |
| CAT.6 cable, 15–20 m | Recorded bought | Router placement flexibility |
| USB-A to micro-USB data cable | Recorded bought; final quantity/fit unconfirmed | Pico and U2D2 USB |
| INA226 modules | Recorded bought, 4 | Bench/fallback units; read the actual shunt marking and configure it accordingly |
| 5.5×2.5 mm DC plug cable | Recorded bought | Jetson power harness; match the current board output |
| ADXL375 | Order/arrival unconfirmed in the record | Hammer impact acquisition; [MISSION-01](../05_한계와_로드맵.md#mission-01) |

## Assembly inventory to reconcile

The earlier list proposed a main switch, XT60/wire harness, Robot Cable-X4P
cables, BMI088 headers, flexible hammer wiring, strain relief, mounting hardware,
fan mesh, damping and field spares. It did not establish final quantities or
receipts. Reconcile them against the actual chassis and **current board revision**
as part of [HW-01](../05_한계와_로드맵.md#hw-01); update this inventory as evidence arrives.
Do not carry the old board's fuse, switch or connector assumptions into a new order.

The same physical inventory should identify available charging equipment, bench
supply, meter/scope, wiring tools, controller and router power/support equipment.
The Jetson installation already succeeded from Windows; an Ubuntu host is not
an outstanding purchase requirement for that completed setup.
